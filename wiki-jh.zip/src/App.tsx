import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  type User,
} from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  onSnapshot,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import {
  auth,
  db,
  googleProvider,
  handleFirestoreError,
  OperationType,
  SUPER_ADMIN_EMAILS,
} from './firebase';
import type {
  AdminRecord,
  AppNotification,
  AuctionListing,
  Campus,
  CardId,
  DuelMove,
  DuelRoom,
  DuelRoundResult,
  Friendship,
  MatchmakingEntry,
  NavTab,
  PlayerProfile,
  ProfileSubTab,
  Stance,
  ToastMessage,
  TradeOffer,
} from './types/game';
import {
  CARD_BY_ID,
  computeCardDuelPower,
  computeStanceOutcome,
  EMPTY_STATS,
  pickBestDeck,
  rollPackCards,
  STARTER_CARD_IDS,
  STARTER_INVENTORY,
} from './data/cards';
import { ACHIEVEMENTS, COSMETIC_BY_ID } from './data/cosmeticsAndAchievements';
import { soundFx } from './utils/sound';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Navbar } from './components/Navbar';
import { OnboardingScreen, WelcomeScreen } from './components/AuthAndOnboarding';
import { PacksPage } from './components/PacksPage';
import { CollectionPage } from './components/CollectionPage';
import { TradesPage } from './components/TradesPage';
import { MarketPage } from './components/MarketPage';
import { ArenaPage } from './components/ArenaPage';
import { FriendsPage } from './components/FriendsPage';
import { LeaderboardPage, PlayerProfileModal } from './components/LeaderboardPage';
import { ProfilePage } from './components/ProfilePage';
import { AdminPage } from './components/AdminPage';

const REGEN_INTERVAL_MS = 10 * 60 * 1000;
const MAX_FREE_REGEN_PACKS = 10;

function makeId(prefix: string): string {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

function WikiJHApp() {
  const [authReady, setAuthReady] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  const [player, setPlayer] = useState<PlayerProfile | null>(null);
  const [playerLoaded, setPlayerLoaded] = useState(false);

  const [allPlayers, setAllPlayers] = useState<PlayerProfile[]>([]);
  const [promotedAdmins, setPromotedAdmins] = useState<AdminRecord[]>([]);
  const [isPromotedAdmin, setIsPromotedAdmin] = useState(false);
  const [friendships, setFriendships] = useState<Friendship[]>([]);
  const [trades, setTrades] = useState<TradeOffer[]>([]);
  const [auctions, setAuctions] = useState<AuctionListing[]>([]);
  const [openDuels, setOpenDuels] = useState<DuelRoom[]>([]);
  const [myDuels, setMyDuels] = useState<DuelRoom[]>([]);
  const [activeDuelMoves, setActiveDuelMoves] = useState<DuelMove[]>([]);
  const [matchmakingList, setMatchmakingList] = useState<MatchmakingEntry[]>([]);

  const [activeTab, setActiveTab] = useState<NavTab>('paquets');
  const [profileSubTab, setProfileSubTab] = useState<ProfileSubTab>('personnalisation');
  const [tradeFriendUid, setTradeFriendUid] = useState<string | null>(null);
  const [inspectedPlayer, setInspectedPlayer] = useState<PlayerProfile | null>(null);

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('wikijh_theme');
      return saved ? saved === 'dark' : true;
    } catch {
      return true;
    }
  });
  const [muted, setMuted] = useState<boolean>(() => soundFx.isMuted());
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const claimingRef = useRef<Set<string>>(new Set());

  const showToast = (text: string, tone: ToastMessage['tone'] = 'default') => {
    const id = makeId('toast');
    setToasts((prev) => [...prev.slice(-2), { id, text, tone }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3400);
  };

  // Sync theme to <html>
  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) root.classList.add('dark');
    else root.classList.remove('dark');
    try {
      localStorage.setItem('wikijh_theme', darkMode ? 'dark' : 'light');
    } catch {
      // ignore
    }
  }, [darkMode]);

  // Auth listener
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setAuthReady(true);
      if (!u) {
        setPlayer(null);
        setPlayerLoaded(true);
      } else {
        setPlayerLoaded(false);
      }
    });
    return () => unsub();
  }, []);

  const normalizedEmail = user?.email?.trim().toLowerCase() || '';
  const isSuperAdmin = Boolean(
    normalizedEmail && user?.emailVerified && SUPER_ADMIN_EMAILS.includes(normalizedEmail)
  );
  const isAdmin = isSuperAdmin || isPromotedAdmin;

  // Player doc & Admin check listeners
  useEffect(() => {
    if (!authReady || !user) return;

    const playerRef = doc(db, 'players', user.uid);
    const unsubPlayer = onSnapshot(
      playerRef,
      (snap) => {
        setPlayer(snap.exists() ? (snap.data() as PlayerProfile) : null);
        setPlayerLoaded(true);
      },
      (err) => handleFirestoreError(err, OperationType.GET, `players/${user.uid}`)
    );

    const adminRef = doc(db, 'admins', user.uid);
    const unsubAdmin = onSnapshot(
      adminRef,
      (snap) => {
        setIsPromotedAdmin(snap.exists());
      },
      () => {
        setIsPromotedAdmin(false);
      }
    );

    return () => {
      unsubPlayer();
      unsubAdmin();
    };
  }, [authReady, user?.uid]);

  // Shared game collections listeners (only when player profile exists)
  useEffect(() => {
    if (!authReady || !user || !player) return;

    const unsubs: (() => void)[] = [];

    unsubs.push(
      onSnapshot(
        query(collection(db, 'players'), where('campus', 'in', ['Labbé', 'Marceau'])),
        (snap) => {
          setAllPlayers(snap.docs.map((d) => d.data() as PlayerProfile));
        },
        (err) => handleFirestoreError(err, OperationType.LIST, 'players')
      )
    );

    unsubs.push(
      onSnapshot(
        query(collection(db, 'friendships'), where('users', 'array-contains', user.uid)),
        (snap) => {
          setFriendships(
            snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<Friendship, 'id'>) }))
          );
        },
        (err) => handleFirestoreError(err, OperationType.LIST, 'friendships')
      )
    );

    unsubs.push(
      onSnapshot(
        query(collection(db, 'trades'), where('participants', 'array-contains', user.uid)),
        (snap) => {
          setTrades(
            snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<TradeOffer, 'id'>) }))
          );
        },
        (err) => handleFirestoreError(err, OperationType.LIST, 'trades')
      )
    );

    unsubs.push(
      onSnapshot(
        query(
          collection(db, 'auctions'),
          where('status', 'in', ['active', 'sold', 'ended', 'cancelled'])
        ),
        (snap) => {
          setAuctions(
            snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<AuctionListing, 'id'>) }))
          );
        },
        (err) => handleFirestoreError(err, OperationType.LIST, 'auctions')
      )
    );

    unsubs.push(
      onSnapshot(
        query(collection(db, 'duels'), where('status', '==', 'open')),
        (snap) => {
          setOpenDuels(
            snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<DuelRoom, 'id'>) }))
          );
        },
        (err) => handleFirestoreError(err, OperationType.LIST, 'duels')
      )
    );

    unsubs.push(
      onSnapshot(
        query(collection(db, 'duels'), where('participants', 'array-contains', user.uid)),
        (snap) => {
          setMyDuels(
            snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<DuelRoom, 'id'>) }))
          );
        },
        (err) => handleFirestoreError(err, OperationType.LIST, 'duels')
      )
    );

    unsubs.push(
      onSnapshot(
        query(collection(db, 'matchmaking'), where('status', 'in', ['waiting', 'matched'])),
        (snap) => {
          setMatchmakingList(snap.docs.map((d) => d.data() as MatchmakingEntry));
        },
        (err) => handleFirestoreError(err, OperationType.LIST, 'matchmaking')
      )
    );

    if (isAdmin) {
      unsubs.push(
        onSnapshot(
          query(collection(db, 'admins'), where('uid', '!=', '')),
          (snap) => {
            setPromotedAdmins(snap.docs.map((d) => d.data() as AdminRecord));
          },
          (err) => handleFirestoreError(err, OperationType.LIST, 'admins')
        )
      );
    }

    return () => unsubs.forEach((u) => u());
  }, [authReady, user?.uid, Boolean(player), isAdmin]);

  // Active PvP Duel & its moves listener
  const activeDuel = useMemo(() => {
    const active = myDuels.find((d) => d.status === 'active');
    if (active) return active;
    const unclaimed = myDuels.find(
      (d) =>
        d.status === 'finished' &&
        ((d.hostId === user?.uid && !d.hostClaimed) ||
          (d.guestId === user?.uid && !d.guestClaimed))
    );
    return unclaimed || null;
  }, [myDuels, user?.uid]);

  useEffect(() => {
    if (!activeDuel || !user) {
      setActiveDuelMoves([]);
      return;
    }
    const unsub = onSnapshot(
      collection(db, 'duels', activeDuel.id, 'moves'),
      (snap) => {
        setActiveDuelMoves(snap.docs.map((d) => d.data() as DuelMove));
      },
      (err) =>
        handleFirestoreError(err, OperationType.LIST, `duels/${activeDuel.id}/moves`)
    );
    return () => unsub();
  }, [activeDuel?.id, user?.uid]);

  // Pack Regeneration Timer (+1 every 10 min up to 10)
  useEffect(() => {
    if (!player || !user) return;
    const checkRegen = async () => {
      if (player.packs >= MAX_FREE_REGEN_PACKS) return;
      const lastMs = player.lastPackRegenAt?.toMillis?.() || Date.now();
      const elapsed = Date.now() - lastMs;
      const gained = Math.floor(elapsed / REGEN_INTERVAL_MS);
      if (gained <= 0) return;

      const nextPacks = Math.min(MAX_FREE_REGEN_PACKS, player.packs + gained);
      const remainderMs = elapsed % REGEN_INTERVAL_MS;
      const nextRegenTs = Timestamp.fromMillis(Date.now() - remainderMs);

      try {
        await updateDoc(doc(db, 'players', user.uid), {
          packs: nextPacks,
          lastPackRegenAt: nextRegenTs,
          updatedAt: serverTimestamp(),
        });
      } catch {
        // silent background regen retry
      }
    };

    checkRegen();
    const id = setInterval(checkRegen, 15000);
    return () => clearInterval(id);
  }, [player?.packs, player?.lastPackRegenAt, user?.uid]);

  // Matchmaking Auto-Pairing
  const myMatchmaking = matchmakingList.find((m) => m.uid === user?.uid) || null;
  useEffect(() => {
    if (!player || !user || !myMatchmaking || myMatchmaking.status !== 'waiting') return;
    const others = matchmakingList.filter(
      (m) => m.status === 'waiting' && m.uid !== user.uid
    );
    if (others.length === 0) return;
    const target = others[0];
    // Deterministic initiator: larger UID creates the duel room as host
    if (user.uid < target.uid) return;

    const pairPlayers = async () => {
      const duelId = makeId('duel');
      const myDeck =
        player.deck?.length === 3 ? player.deck : pickBestDeck(player.inventory);
      try {
        await runTransaction(db, async (tx) => {
          const targetRef = doc(db, 'matchmaking', target.uid);
          const myRef = doc(db, 'matchmaking', user.uid);
          const targetSnap = await tx.get(targetRef);
          const mySnap = await tx.get(myRef);
          if (
            !targetSnap.exists() ||
            !mySnap.exists() ||
            targetSnap.data().status !== 'waiting' ||
            mySnap.data().status !== 'waiting'
          ) {
            return;
          }

          tx.set(doc(db, 'duels', duelId), {
            mode: 'ranked',
            hostId: user.uid,
            hostPseudo: player.pseudo,
            hostCampus: player.campus,
            hostElo: player.elo,
            hostDeck: myDeck,
            guestId: target.uid,
            guestPseudo: target.pseudo,
            guestCampus: target.campus,
            guestElo: target.elo,
            guestDeck: target.deck,
            participants: [user.uid, target.uid],
            status: 'active',
            currentRound: 1,
            roundStartedAt: serverTimestamp(),
            hostScore: 0,
            guestScore: 0,
            roundHistory: [],
            winnerId: '',
            forfeitedBy: '',
            hostClaimed: false,
            guestClaimed: false,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });

          tx.update(targetRef, {
            status: 'matched',
            duelId,
            matchedWith: user.uid,
            updatedAt: serverTimestamp(),
          });
          tx.update(myRef, {
            status: 'matched',
            duelId,
            matchedWith: target.uid,
            updatedAt: serverTimestamp(),
          });
        });
      } catch {
        // race handled gracefully
      }
    };

    pairPlayers();
  }, [matchmakingList, myMatchmaking?.status, player?.uid]);

  // Clean up matched matchmaking doc once duel starts
  useEffect(() => {
    if (!user || !myMatchmaking || myMatchmaking.status !== 'matched') return;
    deleteDoc(doc(db, 'matchmaking', user.uid)).catch(() => {});
  }, [myMatchmaking?.status, user?.uid]);

  // Auto-claim completed trades & auction refunds/proceeds in background
  useEffect(() => {
    if (!player || !user) return;
    trades.forEach((t) => {
      if (
        t.senderId === user.uid &&
        (t.status === 'accepted' || t.status === 'rejected') &&
        !t.senderClaimed &&
        !claimingRef.current.has(`trade_${t.id}`)
      ) {
        claimingRef.current.add(`trade_${t.id}`);
        handleClaimTrade(t).finally(() => claimingRef.current.delete(`trade_${t.id}`));
      }
    });

    auctions.forEach((a) => {
      const refund = a.pendingRefunds?.[user.uid] || 0;
      if (refund > 0 && !claimingRef.current.has(`refund_${a.id}`)) {
        claimingRef.current.add(`refund_${a.id}`);
        handleClaimRefund(a).finally(() => claimingRef.current.delete(`refund_${a.id}`));
      }
      if (
        (a.status === 'sold' || a.status === 'ended') &&
        a.sellerId === user.uid &&
        !a.sellerClaimed &&
        !claimingRef.current.has(`seller_${a.id}`)
      ) {
        claimingRef.current.add(`seller_${a.id}`);
        handleClaimSeller(a).finally(() => claimingRef.current.delete(`seller_${a.id}`));
      }
      if (
        a.status === 'ended' &&
        a.highestBidderId === user.uid &&
        !a.winnerClaimed &&
        !claimingRef.current.has(`winner_${a.id}`)
      ) {
        claimingRef.current.add(`winner_${a.id}`);
        handleClaimWinner(a).finally(() => claimingRef.current.delete(`winner_${a.id}`));
      }
    });
  }, [trades, auctions, player?.uid]);

  // Derived lists & notifications
  const acceptedFriends = useMemo(() => {
    if (!user) return [];
    const friendUids = new Set(
      friendships
        .filter((f) => f.status === 'accepted')
        .map((f) => f.users.find((u) => u !== user.uid) || '')
    );
    return allPlayers.filter((p) => friendUids.has(p.uid));
  }, [friendships, allPlayers, user?.uid]);

  const pendingTradesCount = trades.filter(
    (t) => t.recipientId === user?.uid && t.status === 'pending'
  ).length;
  const pendingFriendsCount = friendships.filter(
    (f) => f.recipientId === user?.uid && f.status === 'pending'
  ).length;

  const notifications = useMemo<AppNotification[]>(() => {
    if (!player || !user) return [];
    const list: AppNotification[] = [];

    // Returned cards / expired auctions
    auctions.forEach((a) => {
      if (
        a.status === 'ended' &&
        a.sellerId === user.uid &&
        !a.sellerClaimed &&
        a.highestBidderId === ''
      ) {
        list.push({
          id: `auc_ret_${a.id}`,
          title: 'Carte rendue après enchère expirée',
          detail: `${CARD_BY_ID[a.cardId].name} prête à être récupérée.`,
          targetTab: 'marche',
          kind: 'auction',
        });
      }
    });

    // Friend requests
    if (pendingFriendsCount > 0) {
      list.push({
        id: 'notif_friends',
        title: `${pendingFriendsCount} demande(s) d’ami en attente`,
        detail: 'Acceptez ou refusez dans l’onglet Amis.',
        targetTab: 'amis',
        kind: 'friend',
      });
    }

    // Pending trades
    if (pendingTradesCount > 0) {
      list.push({
        id: 'notif_trades',
        title: `${pendingTradesCount} proposition(s) d’échange reçue(s)`,
        detail: 'Consultez vos échanges en attente.',
        targetTab: 'echanges',
        kind: 'trade',
      });
    }

    // Ready achievements
    const readyAchs = ACHIEVEMENTS.filter(
      (ach) =>
        !player.claimedAchievements.includes(ach.id) &&
        ach.getProgress(player, acceptedFriends.length) >= ach.target
    );
    if (readyAchs.length > 0) {
      list.push({
        id: 'notif_ach',
        title: `${readyAchs.length} succès prêt(s) à être réclamé(s)`,
        detail: readyAchs.map((a) => a.title).join(', '),
        targetTab: 'profil',
        kind: 'achievement',
      });
    }

    return list;
  }, [auctions, pendingFriendsCount, pendingTradesCount, player, acceptedFriends.length, user?.uid]);

  // ---------------------------------------------------------------------------
  // Action Handlers
  // ---------------------------------------------------------------------------
  const handleSignIn = async () => {
    setAuthLoading(true);
    setAuthError(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      setAuthError(
        err instanceof Error ? err.message : 'La connexion avec Google a échoué.'
      );
    } finally {
      setAuthLoading(false);
    }
  };

  const handleSignOut = async () => {
    await signOut(auth);
    setActiveTab('paquets');
  };

  const handleOnboardingComplete = async (data: {
    pseudo: string;
    campus: Campus;
    classe: string;
  }) => {
    if (!user) return;
    const batch = writeBatch(db);
    const pRef = doc(db, 'players', user.uid);
    const privRef = doc(db, 'playerPrivate', user.uid);

    batch.set(pRef, {
      uid: user.uid,
      pseudo: data.pseudo,
      campus: data.campus,
      classe: data.classe,
      bio: '',
      elo: 1000,
      wins: 0,
      losses: 0,
      coins: 0,
      packs: 10,
      lastPackRegenAt: serverTimestamp(),
      inventory: { ...STARTER_INVENTORY },
      discoveredCards: [...STARTER_CARD_IDS],
      deck: [...STARTER_CARD_IDS],
      showcase: [],
      equippedEmblem: 'emblem_default',
      equippedFrame: 'frame_default',
      equippedBanner: 'banner_default',
      equippedTitle: 'title_novice',
      unlockedCosmetics: [
        'emblem_default',
        'frame_default',
        'banner_default',
        'title_novice',
      ],
      claimedAchievements: [],
      lastPackPull: [],
      stats: { ...EMPTY_STATS },
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    batch.set(privRef, {
      uid: user.uid,
      email: user.email || '',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    try {
      await batch.commit();
      soundFx.playVictory();
      showToast('Bienvenue dans Wiki JH ! 10 paquets crédités.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `players/${user.uid}`);
    }
  };

  const handleOpenPack = async (): Promise<{
    pull: CardId[];
    newlyDiscovered: CardId[];
  }> => {
    if (!user || !player) throw new Error('Non connecté');
    const pull = rollPackCards();
    let newlyDiscovered: CardId[] = [];

    try {
      await runTransaction(db, async (tx) => {
        const ref = doc(db, 'players', user.uid);
        const snap = await tx.get(ref);
        if (!snap.exists()) throw new Error('Profil introuvable');
        const cur = snap.data() as PlayerProfile;
        if (cur.packs <= 0) throw new Error('Aucun paquet disponible');

        const nextInv = { ...cur.inventory };
        const discSet = new Set(cur.discoveredCards);
        newlyDiscovered = [];
        for (const cid of pull) {
          nextInv[cid] = (nextInv[cid] || 0) + 1;
          if (!discSet.has(cid)) {
            discSet.add(cid);
            newlyDiscovered.push(cid);
          }
        }

        const wasAtCap = cur.packs >= MAX_FREE_REGEN_PACKS;
        const nextPacks = cur.packs - 1;
        tx.update(ref, {
          packs: nextPacks,
          lastPackRegenAt:
            wasAtCap && nextPacks < MAX_FREE_REGEN_PACKS
              ? serverTimestamp()
              : cur.lastPackRegenAt,
          inventory: nextInv,
          discoveredCards: Array.from(discSet),
          lastPackPull: pull,
          stats: {
            ...cur.stats,
            packsOpened: (cur.stats.packsOpened || 0) + 1,
          },
          updatedAt: serverTimestamp(),
        });
      });
      showToast('Booster ouvert et sauvegardé !', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `players/${user.uid}`);
    }

    return { pull, newlyDiscovered };
  };

  const handleBuyPack = async () => {
    if (!user) return;
    try {
      await runTransaction(db, async (tx) => {
        const ref = doc(db, 'players', user.uid);
        const snap = await tx.get(ref);
        if (!snap.exists()) return;
        const cur = snap.data() as PlayerProfile;
        if (cur.coins < 120) throw new Error('Solde insuffisant');
        tx.update(ref, {
          coins: cur.coins - 120,
          packs: cur.packs + 1,
          updatedAt: serverTimestamp(),
        });
      });
      soundFx.playClick();
      showToast('Booster acheté pour 120 ● !', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `players/${user.uid}`);
    }
  };

  const handleDiscardOne = async (cardId: CardId) => {
    if (!user) return;
    try {
      await runTransaction(db, async (tx) => {
        const ref = doc(db, 'players', user.uid);
        const snap = await tx.get(ref);
        if (!snap.exists()) return;
        const cur = snap.data() as PlayerProfile;
        if ((cur.inventory[cardId] || 0) <= 0) return;

        const nextInv = { ...cur.inventory, [cardId]: cur.inventory[cardId] - 1 };
        const nextDeck =
          nextInv[cardId] === 0 ? cur.deck.filter((id) => id !== cardId) : cur.deck;
        const nextShowcase =
          nextInv[cardId] === 0
            ? cur.showcase.filter((id) => id !== cardId)
            : cur.showcase;

        tx.update(ref, {
          inventory: nextInv,
          deck: nextDeck,
          showcase: nextShowcase,
          coins: cur.coins + 1,
          stats: {
            ...cur.stats,
            cardsDiscarded: (cur.stats.cardsDiscarded || 0) + 1,
          },
          updatedAt: serverTimestamp(),
        });
      });
      soundFx.playCoinGain();
      showToast(`${CARD_BY_ID[cardId].name} défaussée (+1 ●)`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `players/${user.uid}`);
    }
  };

  const handleBatchDiscard = async (items: Record<CardId, number>) => {
    if (!user) return;
    let totalGained = 0;
    try {
      await runTransaction(db, async (tx) => {
        const ref = doc(db, 'players', user.uid);
        const snap = await tx.get(ref);
        if (!snap.exists()) return;
        const cur = snap.data() as PlayerProfile;
        const nextInv = { ...cur.inventory };

        for (const [cid, qty] of Object.entries(items)) {
          const id = cid as CardId;
          const discardQty = Math.min(nextInv[id] || 0, qty || 0);
          if (discardQty > 0) {
            nextInv[id] -= discardQty;
            totalGained += discardQty;
          }
        }
        if (totalGained <= 0) return;

        tx.update(ref, {
          inventory: nextInv,
          deck: cur.deck.filter((id) => (nextInv[id] || 0) > 0),
          showcase: cur.showcase.filter((id) => (nextInv[id] || 0) > 0),
          coins: cur.coins + totalGained,
          stats: {
            ...cur.stats,
            cardsDiscarded: (cur.stats.cardsDiscarded || 0) + totalGained,
          },
          updatedAt: serverTimestamp(),
        });
      });
      soundFx.playCoinGain();
      showToast(`${totalGained} carte(s) défaussée(s) (+${totalGained} ●)`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `players/${user.uid}`);
    }
  };

  // Friendships
  const handleSendFriendRequest = async (target: PlayerProfile) => {
    if (!user || !player) return;
    const fid =
      user.uid < target.uid ? `${user.uid}_${target.uid}` : `${target.uid}_${user.uid}`;
    try {
      await setDoc(doc(db, 'friendships', fid), {
        users: [user.uid, target.uid],
        requesterId: user.uid,
        recipientId: target.uid,
        status: 'pending',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      soundFx.playClick();
      showToast(`Invitation envoyée à ${target.pseudo}`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `friendships/${fid}`);
    }
  };

  const handleAcceptFriendRequest = async (friendship: Friendship) => {
    try {
      await updateDoc(doc(db, 'friendships', friendship.id), {
        status: 'accepted',
        updatedAt: serverTimestamp(),
      });
      soundFx.playCoinGain();
      showToast('Ami ajouté à votre liste !', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `friendships/${friendship.id}`);
    }
  };

  const handleRemoveFriendship = async (friendship: Friendship) => {
    try {
      await deleteDoc(doc(db, 'friendships', friendship.id));
      showToast('Relation supprimée.');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `friendships/${friendship.id}`);
    }
  };

  // Trades
  const handleCreateTrade = async (
    recipient: PlayerProfile,
    offered: CardId[],
    requested: CardId[]
  ) => {
    if (!user || !player) return;
    const tradeId = makeId('trade');
    try {
      await runTransaction(db, async (tx) => {
        const pRef = doc(db, 'players', user.uid);
        const snap = await tx.get(pRef);
        if (!snap.exists()) return;
        const cur = snap.data() as PlayerProfile;
        const nextInv = { ...cur.inventory };
        for (const cid of offered) {
          if ((nextInv[cid] || 0) <= 0) {
            throw new Error(`Carte manquante : ${CARD_BY_ID[cid].name}`);
          }
          nextInv[cid] -= 1;
        }

        tx.update(pRef, {
          inventory: nextInv,
          deck: cur.deck.filter((id) => (nextInv[id] || 0) > 0),
          showcase: cur.showcase.filter((id) => (nextInv[id] || 0) > 0),
          updatedAt: serverTimestamp(),
        });

        tx.set(doc(db, 'trades', tradeId), {
          senderId: user.uid,
          senderPseudo: cur.pseudo,
          recipientId: recipient.uid,
          recipientPseudo: recipient.pseudo,
          participants: [user.uid, recipient.uid],
          offeredCards: offered,
          requestedCards: requested,
          status: 'pending',
          senderClaimed: false,
          recipientClaimed: false,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      });
      soundFx.playClick();
      showToast(`Offre d’échange envoyée à ${recipient.pseudo}`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `trades/${tradeId}`);
    }
  };

  const handleAcceptTrade = async (trade: TradeOffer) => {
    if (!user) return;
    try {
      await runTransaction(db, async (tx) => {
        const tRef = doc(db, 'trades', trade.id);
        const pRef = doc(db, 'players', user.uid);
        const tSnap = await tx.get(tRef);
        const pSnap = await tx.get(pRef);
        if (!tSnap.exists() || !pSnap.exists()) return;
        const tData = tSnap.data() as TradeOffer;
        if (tData.status !== 'pending') return;
        const cur = pSnap.data() as PlayerProfile;
        const nextInv = { ...cur.inventory };

        for (const cid of tData.requestedCards) {
          if ((nextInv[cid] || 0) <= 0) {
            throw new Error(`Vous ne possédez plus ${CARD_BY_ID[cid].name}`);
          }
          nextInv[cid] -= 1;
        }

        const discSet = new Set(cur.discoveredCards);
        for (const cid of tData.offeredCards) {
          nextInv[cid] = (nextInv[cid] || 0) + 1;
          discSet.add(cid);
        }

        tx.update(pRef, {
          inventory: nextInv,
          discoveredCards: Array.from(discSet),
          deck: cur.deck.filter((id) => (nextInv[id] || 0) > 0),
          showcase: cur.showcase.filter((id) => (nextInv[id] || 0) > 0),
          stats: {
            ...cur.stats,
            tradesCompleted: (cur.stats.tradesCompleted || 0) + 1,
          },
          updatedAt: serverTimestamp(),
        });

        tx.update(tRef, {
          status: 'accepted',
          recipientClaimed: true,
          updatedAt: serverTimestamp(),
        });
      });
      soundFx.playVictory();
      showToast('Échange accepté ! Cartes transférées.', 'success');
    } catch (err) {
      if (err instanceof Error && err.message.includes('possédez plus')) {
        showToast(err.message, 'error');
        return;
      }
      handleFirestoreError(err, OperationType.UPDATE, `trades/${trade.id}`);
    }
  };

  const handleRejectTrade = async (trade: TradeOffer) => {
    try {
      await updateDoc(doc(db, 'trades', trade.id), {
        status: 'rejected',
        recipientClaimed: true,
        updatedAt: serverTimestamp(),
      });
      showToast('Offre refusée.');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `trades/${trade.id}`);
    }
  };

  const handleCancelTrade = async (trade: TradeOffer) => {
    if (!user) return;
    try {
      await runTransaction(db, async (tx) => {
        const tRef = doc(db, 'trades', trade.id);
        const pRef = doc(db, 'players', user.uid);
        const tSnap = await tx.get(tRef);
        const pSnap = await tx.get(pRef);
        if (!tSnap.exists() || !pSnap.exists()) return;
        const tData = tSnap.data() as TradeOffer;
        if (tData.status !== 'pending') return;
        const cur = pSnap.data() as PlayerProfile;
        const nextInv = { ...cur.inventory };
        for (const cid of tData.offeredCards) {
          nextInv[cid] = (nextInv[cid] || 0) + 1;
        }

        tx.update(pRef, {
          inventory: nextInv,
          updatedAt: serverTimestamp(),
        });
        tx.update(tRef, {
          status: 'cancelled',
          senderClaimed: true,
          updatedAt: serverTimestamp(),
        });
      });
      showToast('Offre annulée, vos cartes ont été restituées.');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `trades/${trade.id}`);
    }
  };

  const handleClaimTrade = async (trade: TradeOffer) => {
    if (!user) return;
    try {
      await runTransaction(db, async (tx) => {
        const tRef = doc(db, 'trades', trade.id);
        const pRef = doc(db, 'players', user.uid);
        const tSnap = await tx.get(tRef);
        const pSnap = await tx.get(pRef);
        if (!tSnap.exists() || !pSnap.exists()) return;
        const tData = tSnap.data() as TradeOffer;
        if (tData.senderClaimed || (tData.status !== 'accepted' && tData.status !== 'rejected')) {
          return;
        }
        const cur = pSnap.data() as PlayerProfile;
        const nextInv = { ...cur.inventory };
        const discSet = new Set(cur.discoveredCards);
        const cardsToGrant =
          tData.status === 'accepted' ? tData.requestedCards : tData.offeredCards;

        for (const cid of cardsToGrant) {
          nextInv[cid] = (nextInv[cid] || 0) + 1;
          discSet.add(cid);
        }

        tx.update(pRef, {
          inventory: nextInv,
          discoveredCards: Array.from(discSet),
          stats: {
            ...cur.stats,
            tradesCompleted:
              tData.status === 'accepted'
                ? (cur.stats.tradesCompleted || 0) + 1
                : cur.stats.tradesCompleted || 0,
          },
          updatedAt: serverTimestamp(),
        });

        tx.update(tRef, {
          senderClaimed: true,
          updatedAt: serverTimestamp(),
        });
      });
      if (trade.status === 'accepted') {
        soundFx.playCoinGain();
        showToast('Échange finalisé : cartes ajoutées à votre collection !', 'success');
      } else {
        showToast('Vos cartes d’échange refusé ont été restituées.');
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `trades/${trade.id}`);
    }
  };

  // Auctions
  const handleCreateAuction = async ({
    cardId,
    startingPrice,
    buyoutPrice,
    durationMinutes,
  }: {
    cardId: CardId;
    startingPrice: number;
    buyoutPrice: number;
    durationMinutes: number;
  }) => {
    if (!user || !player) return;
    const auctionId = makeId('auc');
    const endsAt = Timestamp.fromMillis(Date.now() + durationMinutes * 60 * 1000);

    try {
      await runTransaction(db, async (tx) => {
        const pRef = doc(db, 'players', user.uid);
        const snap = await tx.get(pRef);
        if (!snap.exists()) return;
        const cur = snap.data() as PlayerProfile;
        if ((cur.inventory[cardId] || 0) <= 0) throw new Error('Carte introuvable');
        const nextInv = { ...cur.inventory, [cardId]: cur.inventory[cardId] - 1 };

        tx.update(pRef, {
          inventory: nextInv,
          deck: cur.deck.filter((id) => (nextInv[id] || 0) > 0),
          showcase: cur.showcase.filter((id) => (nextInv[id] || 0) > 0),
          updatedAt: serverTimestamp(),
        });

        tx.set(doc(db, 'auctions', auctionId), {
          sellerId: user.uid,
          sellerPseudo: cur.pseudo,
          cardId,
          startingPrice,
          buyoutPrice,
          currentBid: 0,
          highestBidderId: '',
          highestBidderPseudo: '',
          bidHistory: [],
          pendingRefunds: {},
          status: 'active',
          sellerClaimed: false,
          winnerClaimed: false,
          endsAt,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      });
      soundFx.playClick();
      showToast(`${CARD_BY_ID[cardId].name} mise aux enchères !`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `auctions/${auctionId}`);
    }
  };

  const handlePlaceBid = async (auction: AuctionListing, amount: number) => {
    if (!user || !player) return;
    try {
      await runTransaction(db, async (tx) => {
        const aRef = doc(db, 'auctions', auction.id);
        const pRef = doc(db, 'players', user.uid);
        const aSnap = await tx.get(aRef);
        const pSnap = await tx.get(pRef);
        if (!aSnap.exists() || !pSnap.exists()) return;
        const aData = aSnap.data() as AuctionListing;
        const cur = pSnap.data() as PlayerProfile;

        if (aData.status !== 'active') throw new Error('Enchère terminée');
        if (aData.highestBidderId === user.uid) throw new Error('Vous menez déjà');
        const minBid =
          aData.currentBid === 0 ? aData.startingPrice : aData.currentBid + 1;
        if (amount < minBid) throw new Error(`Mise minimale : ${minBid} ●`);
        if (cur.coins < amount) throw new Error('Solde insuffisant');

        const nextPending = { ...(aData.pendingRefunds || {}) };
        if (aData.highestBidderId && aData.currentBid > 0) {
          nextPending[aData.highestBidderId] =
            (nextPending[aData.highestBidderId] || 0) + aData.currentBid;
        }

        const nowMs = Date.now();
        const currentEndsMs = aData.endsAt?.toMillis?.() || nowMs;
        // Anti-snipe: within last 30s adds +1 minute
        const nextEndsAt =
          currentEndsMs - nowMs <= 30000
            ? Timestamp.fromMillis(nowMs + 60000)
            : aData.endsAt;

        const nextHistory = [
          ...(aData.bidHistory || []),
          { uid: user.uid, pseudo: cur.pseudo, amount, at: nowMs },
        ].slice(-30);

        tx.update(pRef, {
          coins: cur.coins - amount,
          updatedAt: serverTimestamp(),
        });

        tx.update(aRef, {
          currentBid: amount,
          highestBidderId: user.uid,
          highestBidderPseudo: cur.pseudo,
          bidHistory: nextHistory,
          pendingRefunds: nextPending,
          endsAt: nextEndsAt,
          updatedAt: serverTimestamp(),
        });
      });
      soundFx.playClick();
      showToast(`Enchère placée : ${amount} ●`, 'success');
    } catch (err) {
      if (err instanceof Error && !err.message.includes('permission')) {
        showToast(err.message, 'error');
        return;
      }
      handleFirestoreError(err, OperationType.UPDATE, `auctions/${auction.id}`);
    }
  };

  const handleBuyout = async (auction: AuctionListing) => {
    if (!user || !player || auction.buyoutPrice <= 0) return;
    try {
      await runTransaction(db, async (tx) => {
        const aRef = doc(db, 'auctions', auction.id);
        const pRef = doc(db, 'players', user.uid);
        const aSnap = await tx.get(aRef);
        const pSnap = await tx.get(pRef);
        if (!aSnap.exists() || !pSnap.exists()) return;
        const aData = aSnap.data() as AuctionListing;
        const cur = pSnap.data() as PlayerProfile;

        if (aData.status !== 'active' || aData.buyoutPrice <= 0) return;
        if (cur.coins < aData.buyoutPrice) throw new Error('Solde insuffisant');

        const nextPending = { ...(aData.pendingRefunds || {}) };
        if (aData.highestBidderId && aData.currentBid > 0) {
          nextPending[aData.highestBidderId] =
            (nextPending[aData.highestBidderId] || 0) + aData.currentBid;
        }

        const nextInv = {
          ...cur.inventory,
          [aData.cardId]: (cur.inventory[aData.cardId] || 0) + 1,
        };
        const discSet = new Set(cur.discoveredCards);
        discSet.add(aData.cardId);

        const nextHistory = [
          ...(aData.bidHistory || []),
          { uid: user.uid, pseudo: cur.pseudo, amount: aData.buyoutPrice, at: Date.now() },
        ].slice(-30);

        tx.update(pRef, {
          coins: cur.coins - aData.buyoutPrice,
          inventory: nextInv,
          discoveredCards: Array.from(discSet),
          stats: {
            ...cur.stats,
            auctionsWon: (cur.stats.auctionsWon || 0) + 1,
          },
          updatedAt: serverTimestamp(),
        });

        tx.update(aRef, {
          status: 'sold',
          currentBid: aData.buyoutPrice,
          highestBidderId: user.uid,
          highestBidderPseudo: cur.pseudo,
          bidHistory: nextHistory,
          pendingRefunds: nextPending,
          winnerClaimed: true,
          updatedAt: serverTimestamp(),
        });
      });
      soundFx.playVictory();
      showToast(`Achat immédiat réussi : ${CARD_BY_ID[auction.cardId].name} !`, 'success');
    } catch (err) {
      if (err instanceof Error && err.message.includes('Solde insuffisant')) {
        showToast(err.message, 'error');
        return;
      }
      handleFirestoreError(err, OperationType.UPDATE, `auctions/${auction.id}`);
    }
  };

  const handleCancelAuction = async (auction: AuctionListing) => {
    if (!user) return;
    try {
      await runTransaction(db, async (tx) => {
        const aRef = doc(db, 'auctions', auction.id);
        const pRef = doc(db, 'players', user.uid);
        const aSnap = await tx.get(aRef);
        const pSnap = await tx.get(pRef);
        if (!aSnap.exists() || !pSnap.exists()) return;
        const aData = aSnap.data() as AuctionListing;
        if (aData.status !== 'active' || aData.highestBidderId !== '') return;
        const cur = pSnap.data() as PlayerProfile;

        tx.update(pRef, {
          inventory: {
            ...cur.inventory,
            [aData.cardId]: (cur.inventory[aData.cardId] || 0) + 1,
          },
          updatedAt: serverTimestamp(),
        });
        tx.update(aRef, {
          status: 'cancelled',
          sellerClaimed: true,
          updatedAt: serverTimestamp(),
        });
      });
      showToast('Enchère annulée, carte restituée.');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `auctions/${auction.id}`);
    }
  };

  const handleFinalizeAuction = async (auction: AuctionListing) => {
    try {
      await updateDoc(doc(db, 'auctions', auction.id), {
        status: 'ended',
        updatedAt: serverTimestamp(),
      });
      showToast('Enchère clôturée.');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `auctions/${auction.id}`);
    }
  };

  const handleClaimSeller = async (auction: AuctionListing) => {
    if (!user) return;
    try {
      await runTransaction(db, async (tx) => {
        const aRef = doc(db, 'auctions', auction.id);
        const pRef = doc(db, 'players', user.uid);
        const aSnap = await tx.get(aRef);
        const pSnap = await tx.get(pRef);
        if (!aSnap.exists() || !pSnap.exists()) return;
        const aData = aSnap.data() as AuctionListing;
        if (aData.sellerClaimed || (aData.status !== 'sold' && aData.status !== 'ended')) return;
        const cur = pSnap.data() as PlayerProfile;

        if (aData.highestBidderId === '') {
          // No bids -> return card
          tx.update(pRef, {
            inventory: {
              ...cur.inventory,
              [aData.cardId]: (cur.inventory[aData.cardId] || 0) + 1,
            },
            updatedAt: serverTimestamp(),
          });
        } else {
          // Sold -> credit coins
          tx.update(pRef, {
            coins: cur.coins + aData.currentBid,
            stats: {
              ...cur.stats,
              auctionsSold: (cur.stats.auctionsSold || 0) + 1,
            },
            updatedAt: serverTimestamp(),
          });
        }

        tx.update(aRef, {
          sellerClaimed: true,
          updatedAt: serverTimestamp(),
        });
      });
      soundFx.playCoinGain();
      showToast(
        auction.highestBidderId === ''
          ? `${CARD_BY_ID[auction.cardId].name} restituée dans votre collection.`
          : `Vente encaissée (+${auction.currentBid} ●) !`,
        'success'
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `auctions/${auction.id}`);
    }
  };

  const handleClaimWinner = async (auction: AuctionListing) => {
    if (!user) return;
    try {
      await runTransaction(db, async (tx) => {
        const aRef = doc(db, 'auctions', auction.id);
        const pRef = doc(db, 'players', user.uid);
        const aSnap = await tx.get(aRef);
        const pSnap = await tx.get(pRef);
        if (!aSnap.exists() || !pSnap.exists()) return;
        const aData = aSnap.data() as AuctionListing;
        if (aData.winnerClaimed || aData.status !== 'ended') return;
        const cur = pSnap.data() as PlayerProfile;
        const discSet = new Set(cur.discoveredCards);
        discSet.add(aData.cardId);

        tx.update(pRef, {
          inventory: {
            ...cur.inventory,
            [aData.cardId]: (cur.inventory[aData.cardId] || 0) + 1,
          },
          discoveredCards: Array.from(discSet),
          stats: {
            ...cur.stats,
            auctionsWon: (cur.stats.auctionsWon || 0) + 1,
          },
          updatedAt: serverTimestamp(),
        });
        tx.update(aRef, {
          winnerClaimed: true,
          updatedAt: serverTimestamp(),
        });
      });
      soundFx.playVictory();
      showToast(`Enchère remportée : ${CARD_BY_ID[auction.cardId].name} !`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `auctions/${auction.id}`);
    }
  };

  const handleClaimRefund = async (auction: AuctionListing) => {
    if (!user) return;
    try {
      let amount = 0;
      await runTransaction(db, async (tx) => {
        const aRef = doc(db, 'auctions', auction.id);
        const pRef = doc(db, 'players', user.uid);
        const aSnap = await tx.get(aRef);
        const pSnap = await tx.get(pRef);
        if (!aSnap.exists() || !pSnap.exists()) return;
        const aData = aSnap.data() as AuctionListing;
        amount = aData.pendingRefunds?.[user.uid] || 0;
        if (amount <= 0) return;
        const cur = pSnap.data() as PlayerProfile;

        tx.update(pRef, {
          coins: cur.coins + amount,
          updatedAt: serverTimestamp(),
        });
        tx.update(aRef, {
          pendingRefunds: { ...aData.pendingRefunds, [user.uid]: 0 },
          updatedAt: serverTimestamp(),
        });
      });
      if (amount > 0) {
        soundFx.playCoinGain();
        showToast(`Surenchère détectée : +${amount} ● remboursés.`);
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `auctions/${auction.id}`);
    }
  };

  // Arena / PvP & Solo
  const handleSaveDeck = async (deck: CardId[]) => {
    if (!user) return;
    try {
      await updateDoc(doc(db, 'players', user.uid), {
        deck: deck.slice(0, 3),
        updatedAt: serverTimestamp(),
      });
      soundFx.playClick();
      showToast('Deck de 3 cartes sauvegardé !', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `players/${user.uid}`);
    }
  };

  const handleJoinMatchmaking = async () => {
    if (!user || !player) return;
    const deck = player.deck?.length === 3 ? player.deck : pickBestDeck(player.inventory);
    try {
      await setDoc(doc(db, 'matchmaking', user.uid), {
        uid: user.uid,
        pseudo: player.pseudo,
        campus: player.campus,
        elo: player.elo,
        deck,
        status: 'waiting',
        duelId: '',
        matchedWith: '',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      soundFx.playClick();
      showToast('Recherche d’adversaire lancée…');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `matchmaking/${user.uid}`);
    }
  };

  const handleLeaveMatchmaking = async () => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, 'matchmaking', user.uid));
      showToast('File d’attente quittée.');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `matchmaking/${user.uid}`);
    }
  };

  const handleCreateLobby = async (mode: 'ranked' | 'friendly') => {
    if (!user || !player) return;
    const duelId = makeId('duel');
    const deck = player.deck?.length === 3 ? player.deck : pickBestDeck(player.inventory);
    try {
      await setDoc(doc(db, 'duels', duelId), {
        mode,
        hostId: user.uid,
        hostPseudo: player.pseudo,
        hostCampus: player.campus,
        hostElo: player.elo,
        hostDeck: deck,
        guestId: '',
        guestPseudo: '',
        guestCampus: '',
        guestElo: 1000,
        guestDeck: [],
        participants: [user.uid],
        status: 'open',
        currentRound: 1,
        roundStartedAt: serverTimestamp(),
        hostScore: 0,
        guestScore: 0,
        roundHistory: [],
        winnerId: '',
        forfeitedBy: '',
        hostClaimed: false,
        guestClaimed: false,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      soundFx.playClick();
      showToast('Salon de duel créé !', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `duels/${duelId}`);
    }
  };

  const handleJoinLobby = async (duel: DuelRoom) => {
    if (!user || !player) return;
    const deck = player.deck?.length === 3 ? player.deck : pickBestDeck(player.inventory);
    try {
      await updateDoc(doc(db, 'duels', duel.id), {
        guestId: user.uid,
        guestPseudo: player.pseudo,
        guestCampus: player.campus,
        guestElo: player.elo,
        guestDeck: deck,
        participants: [duel.hostId, user.uid],
        status: 'active',
        roundStartedAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      soundFx.playDuelHit();
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `duels/${duel.id}`);
    }
  };

  const handleCancelLobby = async (duel: DuelRoom) => {
    try {
      await updateDoc(doc(db, 'duels', duel.id), {
        status: 'cancelled',
        updatedAt: serverTimestamp(),
      });
      showToast('Salon fermé.');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `duels/${duel.id}`);
    }
  };

  const handleSubmitPvpMove = async (duel: DuelRoom, cardId: CardId, stance: Stance) => {
    if (!user) return;
    const moveId = `${duel.currentRound}_${user.uid}`;
    try {
      await setDoc(doc(db, 'duels', duel.id, 'moves', moveId), {
        uid: user.uid,
        round: duel.currentRound,
        cardId,
        stance,
        createdAt: serverTimestamp(),
      });
      soundFx.playClick();
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `duels/${duel.id}/moves/${moveId}`);
    }
  };

  const handleResolvePvpRound = async (duel: DuelRoom, moves: DuelMove[]) => {
    try {
      await runTransaction(db, async (tx) => {
        const dRef = doc(db, 'duels', duel.id);
        const snap = await tx.get(dRef);
        if (!snap.exists()) return;
        const d = snap.data() as DuelRoom;
        if (d.status !== 'active' || d.roundHistory.length >= d.currentRound) return;

        const hostMove = moves.find((m) => m.uid === d.hostId);
        const guestMove = moves.find((m) => m.uid === d.guestId);
        const usedHost = d.roundHistory.map((r) => r.hostCard);
        const usedGuest = d.roundHistory.map((r) => r.guestCard);

        const hCard =
          hostMove?.cardId || d.hostDeck.find((c) => !usedHost.includes(c)) || d.hostDeck[0];
        const gCard =
          guestMove?.cardId ||
          d.guestDeck.find((c) => !usedGuest.includes(c)) ||
          d.guestDeck[0];
        const hStance: Stance = hostMove?.stance || 'assaut';
        const gStance: Stance = guestMove?.stance || 'assaut';

        const stanceOutcome = computeStanceOutcome(hStance, gStance);
        const hPow = hostMove
          ? computeCardDuelPower(hCard, hStance, d.hostCampus, stanceOutcome === 'host')
          : 0;
        const gPow = guestMove
          ? computeCardDuelPower(
              gCard,
              gStance,
              (d.guestCampus || 'Marceau') as Campus,
              stanceOutcome === 'guest'
            )
          : 0;

        const roundWin: 'host' | 'guest' | 'draw' =
          hPow > gPow ? 'host' : gPow > hPow ? 'guest' : 'draw';
        const nextHostScore = d.hostScore + (roundWin === 'host' ? 1 : 0);
        const nextGuestScore = d.guestScore + (roundWin === 'guest' ? 1 : 0);
        const entry: DuelRoundResult = {
          round: d.currentRound,
          hostCard: hCard,
          hostStance: hStance,
          hostPower: hPow,
          guestCard: gCard,
          guestStance: gStance,
          guestPower: gPow,
          winner: roundWin,
        };
        const nextHistory = [...d.roundHistory, entry];
        const finished =
          nextHostScore >= 2 || nextGuestScore >= 2 || d.currentRound >= 3;
        const winnerId = !finished
          ? ''
          : nextHostScore > nextGuestScore
          ? d.hostId
          : nextGuestScore > nextHostScore
          ? d.guestId
          : '';

        tx.update(dRef, {
          hostScore: nextHostScore,
          guestScore: nextGuestScore,
          roundHistory: nextHistory,
          currentRound: finished ? d.currentRound : d.currentRound + 1,
          roundStartedAt: serverTimestamp(),
          status: finished ? 'finished' : 'active',
          winnerId,
          updatedAt: serverTimestamp(),
        });
      });
      soundFx.playDuelHit();
    } catch {
      // concurrent resolution guarded by transaction
    }
  };

  const handleForfeitDuel = async (duel: DuelRoom) => {
    if (!user) return;
    const oppId = duel.hostId === user.uid ? duel.guestId : duel.hostId;
    try {
      await updateDoc(doc(db, 'duels', duel.id), {
        status: 'finished',
        forfeitedBy: user.uid,
        winnerId: oppId,
        updatedAt: serverTimestamp(),
      });
      showToast('Vous avez abandonné le duel.');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `duels/${duel.id}`);
    }
  };

  const handleClaimDuelReward = async (duel: DuelRoom) => {
    if (!user) return;
    const isHost = duel.hostId === user.uid;
    const isWin = duel.winnerId === user.uid;
    const isDraw = duel.winnerId === '';
    const coinReward = isWin ? 65 : 20;
    const eloDelta =
      duel.mode === 'ranked' ? (isWin ? 24 : isDraw ? 0 : -16) : 0;

    try {
      await runTransaction(db, async (tx) => {
        const dRef = doc(db, 'duels', duel.id);
        const pRef = doc(db, 'players', user.uid);
        const dSnap = await tx.get(dRef);
        const pSnap = await tx.get(pRef);
        if (!dSnap.exists() || !pSnap.exists()) return;
        const dData = dSnap.data() as DuelRoom;
        if ((isHost && dData.hostClaimed) || (!isHost && dData.guestClaimed)) return;
        const cur = pSnap.data() as PlayerProfile;

        tx.update(pRef, {
          coins: cur.coins + coinReward,
          elo: Math.max(100, cur.elo + eloDelta),
          wins: cur.wins + (isWin ? 1 : 0),
          losses: cur.losses + (!isWin && !isDraw ? 1 : 0),
          stats: {
            ...cur.stats,
            pvpWins: (cur.stats.pvpWins || 0) + (isWin ? 1 : 0),
          },
          updatedAt: serverTimestamp(),
        });

        tx.update(dRef, {
          ...(isHost ? { hostClaimed: true } : { guestClaimed: true }),
          updatedAt: serverTimestamp(),
        });
      });
      if (isWin) soundFx.playVictory();
      else soundFx.playCoinGain();
      showToast(
        `Récompense récupérée : +${coinReward} ●${
          eloDelta !== 0 ? ` (${eloDelta > 0 ? '+' : ''}${eloDelta} ELO)` : ''
        }`,
        'success'
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `duels/${duel.id}`);
    }
  };

  const handleSoloWin = async () => {
    if (!user) return;
    try {
      await runTransaction(db, async (tx) => {
        const pRef = doc(db, 'players', user.uid);
        const snap = await tx.get(pRef);
        if (!snap.exists()) return;
        const cur = snap.data() as PlayerProfile;
        const lastMs = cur.lastSoloWinAt?.toMillis?.() || 0;
        if (Date.now() - lastMs < 35000) return;

        tx.update(pRef, {
          coins: cur.coins + 15,
          lastSoloWinAt: serverTimestamp(),
          stats: {
            ...cur.stats,
            soloWins: (cur.stats.soloWins || 0) + 1,
          },
          updatedAt: serverTimestamp(),
        });
      });
      soundFx.playCoinGain();
      showToast('Victoire en Solo ! +15 ● créditées.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `players/${user.uid}`);
    }
  };

  // Profile, Achievements & Shop
  const handleUpdateProfile = async (updates: {
    pseudo: string;
    campus: Campus;
    classe: string;
    bio: string;
    equippedEmblem: string;
    equippedFrame: string;
    equippedBanner: string;
    equippedTitle: string;
    showcase: CardId[];
  }) => {
    if (!user) return;
    try {
      await updateDoc(doc(db, 'players', user.uid), {
        ...updates,
        updatedAt: serverTimestamp(),
      });
      soundFx.playClick();
      showToast('Profil mis à jour !', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `players/${user.uid}`);
    }
  };

  const handleClaimAchievement = async (achId: string) => {
    if (!user) return;
    const ach = ACHIEVEMENTS.find((a) => a.id === achId);
    if (!ach) return;

    try {
      await runTransaction(db, async (tx) => {
        const pRef = doc(db, 'players', user.uid);
        const snap = await tx.get(pRef);
        if (!snap.exists()) return;
        const cur = snap.data() as PlayerProfile;
        if (cur.claimedAchievements.includes(achId)) return;
        if (ach.getProgress(cur, acceptedFriends.length) < ach.target) return;

        const nextUnlocked = new Set(cur.unlockedCosmetics);
        if (ach.rewardCosmeticId) nextUnlocked.add(ach.rewardCosmeticId);

        tx.update(pRef, {
          coins: cur.coins + ach.rewardCoins,
          claimedAchievements: [...cur.claimedAchievements, achId],
          unlockedCosmetics: Array.from(nextUnlocked),
          updatedAt: serverTimestamp(),
        });
      });
      soundFx.playVictory();
      showToast(`Succès débloqué : +${ach.rewardCoins} ● !`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `players/${user.uid}`);
    }
  };

  const handleBuyCosmetic = async (cosmeticId: string) => {
    if (!user) return;
    const item = COSMETIC_BY_ID[cosmeticId];
    if (!item || item.price <= 0) return;

    try {
      await runTransaction(db, async (tx) => {
        const pRef = doc(db, 'players', user.uid);
        const snap = await tx.get(pRef);
        if (!snap.exists()) return;
        const cur = snap.data() as PlayerProfile;
        if (cur.unlockedCosmetics.includes(cosmeticId)) return;
        if (cur.coins < item.price) throw new Error('Solde insuffisant');

        tx.update(pRef, {
          coins: cur.coins - item.price,
          unlockedCosmetics: [...cur.unlockedCosmetics, cosmeticId],
          updatedAt: serverTimestamp(),
        });
      });
      soundFx.playCoinGain();
      showToast(`${item.name} débloqué !`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `players/${user.uid}`);
    }
  };

  // Admin Operations
  const handleAdminUpdatePlayer = async (
    targetUid: string,
    patch: Partial<PlayerProfile>
  ) => {
    try {
      await updateDoc(doc(db, 'players', targetUid), {
        ...patch,
        updatedAt: serverTimestamp(),
      });
      soundFx.playClick();
      showToast('Fiche joueur synchronisée.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `players/${targetUid}`);
    }
  };

  const handleAdminDeletePlayer = async (targetUid: string) => {
    try {
      await deleteDoc(doc(db, 'players', targetUid));
      await deleteDoc(doc(db, 'playerPrivate', targetUid)).catch(() => {});
      showToast('Compte joueur supprimé.', 'warning');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `players/${targetUid}`);
    }
  };

  const handlePromoteAdmin = async (target: PlayerProfile) => {
    if (!user) return;
    try {
      await setDoc(doc(db, 'admins', target.uid), {
        uid: target.uid,
        pseudo: target.pseudo,
        promotedBy: user.uid,
        createdAt: serverTimestamp(),
      });
      showToast(`${target.pseudo} promu Administrateur.`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `admins/${target.uid}`);
    }
  };

  const handleRevokeAdmin = async (targetUid: string) => {
    try {
      await deleteDoc(doc(db, 'admins', targetUid));
      showToast('Rôle Administrateur retiré.');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `admins/${targetUid}`);
    }
  };

  // ---------------------------------------------------------------------------
  // Render States
  // ---------------------------------------------------------------------------
  if (!authReady || (user && !playerLoaded)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#f6f8fa] dark:bg-[#111315] text-slate-600 dark:text-slate-300">
        <div className="text-center space-y-2">
          <div className="text-3xl text-[#c8952d] dark:text-[#e2bb6b]">◆</div>
          <div className="font-display text-lg font-semibold">Chargement de Wiki JH…</div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <WelcomeScreen
        onSignIn={handleSignIn}
        loading={authLoading}
        authError={authError}
      />
    );
  }

  if (!player) {
    return (
      <OnboardingScreen
        defaultPseudo={user.displayName || user.email?.split('@')[0] || 'ÉlèveJH'}
        onComplete={handleOnboardingComplete}
        onSignOut={handleSignOut}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#f6f8fa] dark:bg-[#111315] text-[#0f172a] dark:text-[#f1f5f9] transition-colors">
      <Navbar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onSelectProfileSubTab={setProfileSubTab}
        coins={player.coins}
        pendingTradesCount={pendingTradesCount}
        pendingFriendsCount={pendingFriendsCount}
        notifications={notifications}
        isAdmin={isAdmin}
      />

      <main>
        {activeTab === 'paquets' && (
          <PacksPage
            player={player}
            onOpenPack={handleOpenPack}
            onBuyPack={handleBuyPack}
            onDiscardOne={handleDiscardOne}
          />
        )}

        {activeTab === 'collection' && (
          <CollectionPage
            player={player}
            onDiscardOne={handleDiscardOne}
            onBatchDiscard={handleBatchDiscard}
          />
        )}

        {activeTab === 'echanges' && (
          <TradesPage
            player={player}
            friends={acceptedFriends}
            trades={trades}
            preselectedFriendUid={tradeFriendUid}
            onCreateTrade={handleCreateTrade}
            onAcceptTrade={handleAcceptTrade}
            onRejectTrade={handleRejectTrade}
            onCancelTrade={handleCancelTrade}
            onClaimTrade={handleClaimTrade}
          />
        )}

        {activeTab === 'marche' && (
          <MarketPage
            player={player}
            auctions={auctions}
            onCreateAuction={handleCreateAuction}
            onPlaceBid={handlePlaceBid}
            onBuyout={handleBuyout}
            onCancelAuction={handleCancelAuction}
            onFinalizeAuction={handleFinalizeAuction}
            onClaimSeller={handleClaimSeller}
            onClaimWinner={handleClaimWinner}
            onClaimRefund={handleClaimRefund}
          />
        )}

        {activeTab === 'bataille' && (
          <ArenaPage
            player={player}
            openDuels={openDuels}
            activeDuel={activeDuel}
            activeDuelMoves={activeDuelMoves}
            inMatchmaking={Boolean(myMatchmaking && myMatchmaking.status === 'waiting')}
            onSaveDeck={handleSaveDeck}
            onJoinMatchmaking={handleJoinMatchmaking}
            onLeaveMatchmaking={handleLeaveMatchmaking}
            onCreateLobby={handleCreateLobby}
            onJoinLobby={handleJoinLobby}
            onCancelLobby={handleCancelLobby}
            onSubmitPvpMove={handleSubmitPvpMove}
            onResolvePvpRound={handleResolvePvpRound}
            onForfeitDuel={handleForfeitDuel}
            onClaimDuelReward={handleClaimDuelReward}
            onSoloWin={handleSoloWin}
          />
        )}

        {activeTab === 'amis' && (
          <FriendsPage
            player={player}
            allPlayers={allPlayers}
            friendships={friendships}
            onSendRequest={handleSendFriendRequest}
            onAcceptRequest={handleAcceptFriendRequest}
            onRemoveFriendship={handleRemoveFriendship}
            onStartTradeWith={(friendUid) => {
              setTradeFriendUid(friendUid);
              setActiveTab('echanges');
            }}
            onInspectPlayer={(target) => setInspectedPlayer(target)}
          />
        )}

        {activeTab === 'classement' && (
          <LeaderboardPage allPlayers={allPlayers} currentUid={player.uid} />
        )}

        {activeTab === 'profil' && (
          <ProfilePage
            player={player}
            friendsCount={acceptedFriends.length}
            subTab={profileSubTab}
            onChangeSubTab={setProfileSubTab}
            darkMode={darkMode}
            muted={muted}
            onToggleTheme={() => setDarkMode((d) => !d)}
            onToggleMute={() => {
              const next = !muted;
              soundFx.setMuted(next);
              setMuted(next);
            }}
            onSignOut={handleSignOut}
            onUpdateProfile={handleUpdateProfile}
            onClaimAchievement={handleClaimAchievement}
            onBuyCosmetic={handleBuyCosmetic}
          />
        )}

        {activeTab === 'admin' && isAdmin && (
          <AdminPage
            currentUid={player.uid}
            isSuperAdmin={isSuperAdmin}
            allPlayers={allPlayers}
            promotedAdmins={promotedAdmins}
            onAdminUpdatePlayer={handleAdminUpdatePlayer}
            onAdminDeletePlayer={handleAdminDeletePlayer}
            onPromoteAdmin={handlePromoteAdmin}
            onRevokeAdmin={handleRevokeAdmin}
          />
        )}
      </main>

      <PlayerProfileModal
        player={inspectedPlayer}
        onClose={() => setInspectedPlayer(null)}
      />

      {/* Ephemeral Toasts */}
      <div className="fixed bottom-20 md:bottom-6 left-1/2 -translate-x-1/2 z-50 flex flex-col items-center gap-2 pointer-events-none px-4 w-full max-w-md">
        {toasts.map((t) => (
          <div
            key={t.id}
            className="px-4 py-2.5 rounded-xl bg-[#181b1f] text-[#f1f5f9] border border-white/15 shadow-2xl text-xs font-medium text-center backdrop-blur-md"
          >
            {t.text}
          </div>
        ))}
      </div>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <WikiJHApp />
    </ErrorBoundary>
  );
}
