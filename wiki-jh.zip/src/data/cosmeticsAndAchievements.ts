import type { PlayerProfile } from '../types/game';
import { getUniqueOwnedCards } from './cards';

export interface CosmeticItem {
  id: string;
  kind: 'emblem' | 'frame' | 'banner' | 'title';
  name: string;
  description: string;
  price: number; // 0 if achievement-only
  previewClass?: string;
  symbol?: string;
  exclusive?: boolean;
}

export const COSMETICS: CosmeticItem[] = [
  // Emblems (120 - 320 coins)
  {
    id: 'emblem_default',
    kind: 'emblem',
    name: 'Compas Jules Haag',
    description: 'Emblème fondateur de la communauté JH.',
    price: 0,
    symbol: '◆',
  },
  {
    id: 'emblem_labbe',
    kind: 'emblem',
    name: 'Blason Labbé',
    description: 'Écusson royal bleu des filières Labbé.',
    price: 120,
    symbol: '❖',
  },
  {
    id: 'emblem_marceau',
    kind: 'emblem',
    name: 'Rouage Marceau',
    description: 'Engrenage émeraude des ateliers Marceau.',
    price: 120,
    symbol: '⚙',
  },
  {
    id: 'emblem_horloger',
    kind: 'emblem',
    name: 'Échappement Bisontin',
    description: 'Symbole de précision chronométrique.',
    price: 220,
    symbol: '◷',
  },
  {
    id: 'emblem_couronne',
    kind: 'emblem',
    name: 'Sceau Impérial JH',
    description: 'Blason doré réservé aux stratèges avertis.',
    price: 320,
    symbol: '♛',
  },
  {
    id: 'emblem_exotique',
    kind: 'emblem',
    name: 'Prisme Exotique',
    description: 'Débloqué uniquement via le succès Maître Collectionneur.',
    price: 0,
    symbol: '✦',
    exclusive: true,
  },

  // Frames (140 - 650 coins)
  {
    id: 'frame_default',
    kind: 'frame',
    name: 'Cadre Ardoise',
    description: 'Bordure sobre standard.',
    price: 0,
    previewClass: 'ring-2 ring-slate-400/50',
  },
  {
    id: 'frame_labbe',
    kind: 'frame',
    name: 'Contour Bleu Labbé',
    description: 'Anneau bleu royal lumineux.',
    price: 140,
    previewClass: 'ring-2 ring-blue-500 shadow-[0_0_14px_rgba(37,99,235,0.45)]',
  },
  {
    id: 'frame_marceau',
    kind: 'frame',
    name: 'Contour Émeraude Marceau',
    description: 'Anneau vert émeraude vibrant.',
    price: 140,
    previewClass: 'ring-2 ring-emerald-500 shadow-[0_0_14px_rgba(5,150,105,0.45)]',
  },
  {
    id: 'frame_artdeco',
    kind: 'frame',
    name: 'Cadre Or Art Déco',
    description: 'Cerclage doré inspiré du Beffroi.',
    price: 360,
    previewClass: 'ring-2 ring-[#e2bb6b] shadow-[0_0_18px_rgba(200,149,45,0.55)]',
  },
  {
    id: 'frame_prisme',
    kind: 'frame',
    name: 'Auréole Exotique',
    description: 'Aura cyan et sarcelle haute prestige.',
    price: 650,
    previewClass: 'ring-2 ring-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.65)]',
  },

  // Banners (180 - 420 coins)
  {
    id: 'banner_default',
    kind: 'banner',
    name: 'Anthracite Classique',
    description: 'Bannière sobre du lycée.',
    price: 0,
    previewClass: 'bg-gradient-to-r from-slate-800 via-slate-900 to-slate-800',
  },
  {
    id: 'banner_labbe',
    kind: 'banner',
    name: 'Esplanade Labbé',
    description: 'Dégradé architectural bleu royal & pierre.',
    price: 180,
    previewClass: 'bg-gradient-to-r from-blue-950 via-blue-800 to-slate-900',
  },
  {
    id: 'banner_marceau',
    kind: 'banner',
    name: 'Verrière Marceau',
    description: 'Dégradé acier et émeraude lumineux.',
    price: 180,
    previewClass: 'bg-gradient-to-r from-emerald-950 via-emerald-800 to-slate-900',
  },
  {
    id: 'banner_beffroi',
    kind: 'banner',
    name: 'Crépuscule sur le Beffroi',
    description: 'Bleu nuit profond relevé d’or chaud.',
    price: 300,
    previewClass: 'bg-gradient-to-r from-[#12192c] via-[#3d2e14] to-[#111315]',
  },
  {
    id: 'banner_legende',
    kind: 'banner',
    name: 'Observatoire Doré',
    description: 'Prestige absolu aux reflets dorés.',
    price: 420,
    previewClass: 'bg-gradient-to-r from-[#5a3f11] via-[#c8952d] to-[#3b290a]',
  },
  {
    id: 'banner_champion',
    kind: 'banner',
    name: 'Bannière Inter-Sites',
    description: 'Débloquée par le succès Champion de l’Arène.',
    price: 0,
    previewClass: 'bg-gradient-to-r from-blue-700 via-teal-600 to-emerald-700',
    exclusive: true,
  },

  // Titles (unlocked at start + via achievements)
  {
    id: 'title_novice',
    kind: 'title',
    name: 'Élève de Jules Haag',
    description: 'Titre de départ.',
    price: 0,
  },
  {
    id: 'title_archiviste',
    kind: 'title',
    name: 'Archiviste des Sites',
    description: 'Succès Collection.',
    price: 0,
    exclusive: true,
  },
  {
    id: 'title_maitre_jh',
    kind: 'title',
    name: 'Maître Chronométreur',
    description: 'Succès Collection complète.',
    price: 0,
    exclusive: true,
  },
  {
    id: 'title_duelliste',
    kind: 'title',
    name: 'Duelliste Tactique',
    description: 'Succès Arène.',
    price: 0,
    exclusive: true,
  },
  {
    id: 'title_courtier',
    kind: 'title',
    name: 'Courtier de Besançon',
    description: 'Succès Commerce.',
    price: 0,
    exclusive: true,
  },
  {
    id: 'title_ambassadeur',
    kind: 'title',
    name: 'Pilier Inter-Sites',
    description: 'Succès Campus.',
    price: 0,
    exclusive: true,
  },
];

export const COSMETIC_BY_ID: Record<string, CosmeticItem> = COSMETICS.reduce(
  (acc, c) => {
    acc[c.id] = c;
    return acc;
  },
  {} as Record<string, CosmeticItem>
);

export interface AchievementDef {
  id: string;
  category: 'Collection' | 'Arène' | 'Campus' | 'Commerce';
  title: string;
  description: string;
  target: number;
  rewardCoins: number;
  rewardCosmeticId?: string;
  getProgress: (player: PlayerProfile, friendsCount: number) => number;
}

export const ACHIEVEMENTS: AchievementDef[] = [
  {
    id: 'ach_packs_3',
    category: 'Collection',
    title: 'Premiers Tirages',
    description: 'Ouvrir 3 paquets de cartes.',
    target: 3,
    rewardCoins: 45,
    getProgress: (p) => p.stats.packsOpened,
  },
  {
    id: 'ach_packs_15',
    category: 'Collection',
    title: 'Chasseur de Boosters',
    description: 'Ouvrir 15 paquets de cartes.',
    target: 15,
    rewardCoins: 140,
    rewardCosmeticId: 'title_archiviste',
    getProgress: (p) => p.stats.packsOpened,
  },
  {
    id: 'ach_unique_8',
    category: 'Collection',
    title: 'Explorateur du Lycée',
    description: 'Découvrir 8 cartes différentes dans votre index.',
    target: 8,
    rewardCoins: 90,
    getProgress: (p) => Math.max(p.discoveredCards.length, getUniqueOwnedCards(p.inventory)),
  },
  {
    id: 'ach_unique_15',
    category: 'Collection',
    title: 'Maître Collectionneur',
    description: 'Découvrir les 15 cartes de la collection Wiki JH.',
    target: 15,
    rewardCoins: 350,
    rewardCosmeticId: 'emblem_exotique',
    getProgress: (p) => Math.max(p.discoveredCards.length, getUniqueOwnedCards(p.inventory)),
  },
  {
    id: 'ach_solo_3',
    category: 'Arène',
    title: 'Entraînement Validé',
    description: 'Remporter 3 duels en Entraînement Solo.',
    target: 3,
    rewardCoins: 60,
    getProgress: (p) => p.stats.soloWins,
  },
  {
    id: 'ach_pvp_1',
    category: 'Arène',
    title: 'Baptême de l’Arène',
    description: 'Remporter 1 duel PvP contre un autre joueur.',
    target: 1,
    rewardCoins: 80,
    rewardCosmeticId: 'title_duelliste',
    getProgress: (p) => p.stats.pvpWins,
  },
  {
    id: 'ach_pvp_10',
    category: 'Arène',
    title: 'Champion de l’Arène',
    description: 'Remporter 10 duels PvP.',
    target: 10,
    rewardCoins: 280,
    rewardCosmeticId: 'banner_champion',
    getProgress: (p) => p.stats.pvpWins,
  },
  {
    id: 'ach_elo_1150',
    category: 'Campus',
    title: 'Fierté du Campus',
    description: 'Atteindre 1150 points ELO pour votre site.',
    target: 1150,
    rewardCoins: 160,
    rewardCosmeticId: 'title_ambassadeur',
    getProgress: (p) => p.elo,
  },
  {
    id: 'ach_friends_3',
    category: 'Campus',
    title: 'Cercle Inter-Sites',
    description: 'Compter au moins 3 amis dans votre liste.',
    target: 3,
    rewardCoins: 75,
    getProgress: (_p, friendsCount) => friendsCount,
  },
  {
    id: 'ach_trade_2',
    category: 'Commerce',
    title: 'Échangeur Fiable',
    description: 'Finaliser 2 échanges entre amis.',
    target: 2,
    rewardCoins: 85,
    getProgress: (p) => p.stats.tradesCompleted,
  },
  {
    id: 'ach_market_3',
    category: 'Commerce',
    title: 'Courtier du Marché',
    description: 'Remporter ou vendre 3 cartes à l’hôtel des ventes.',
    target: 3,
    rewardCoins: 150,
    rewardCosmeticId: 'title_courtier',
    getProgress: (p) => p.stats.auctionsWon + p.stats.auctionsSold,
  },
];
