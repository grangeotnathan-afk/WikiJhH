import type { Campus, CardDef, CardId, PlayerStats, Rarity, Stance } from '../types/game';

export const RARITY_ORDER: Rarity[] = ['EX', 'L', 'UR', 'SR', 'R', 'PC', 'C'];

export const RARITY_META: Record<
  Rarity,
  {
    code: Rarity;
    label: string;
    shortLabel: string;
    dropWeight: number;
    color: string;
    badgeClass: string;
    cardBgClass: string;
    borderClass: string;
    glowColor: string;
  }
> = {
  C: {
    code: 'C',
    label: 'Commune',
    shortLabel: 'Commune',
    dropWeight: 38,
    color: '#64748b',
    badgeClass: 'bg-slate-600/90 text-white border-slate-400/40',
    cardBgClass: 'bg-gradient-to-b from-slate-100 to-slate-200 dark:from-[#1f242b] dark:to-[#181b1f]',
    borderClass: 'border-slate-300 dark:border-slate-700',
    glowColor: 'rgba(148, 163, 184, 0.45)',
  },
  PC: {
    code: 'PC',
    label: 'Peu commune',
    shortLabel: 'Peu commune',
    dropWeight: 26,
    color: '#3b82f6',
    badgeClass: 'bg-blue-600/95 text-white border-blue-400/50',
    cardBgClass: 'bg-gradient-to-b from-blue-50 via-sky-50 to-blue-100/80 dark:from-[#172336] dark:to-[#131b29]',
    borderClass: 'border-blue-400/70 dark:border-blue-500/50',
    glowColor: 'rgba(59, 130, 246, 0.55)',
  },
  R: {
    code: 'R',
    label: 'Rare',
    shortLabel: 'Rare',
    dropWeight: 17,
    color: '#8b5cf6',
    badgeClass: 'bg-violet-600/95 text-white border-violet-400/50',
    cardBgClass: 'bg-gradient-to-b from-violet-50 via-purple-50 to-violet-100/80 dark:from-[#231a38] dark:to-[#171324]',
    borderClass: 'border-violet-400/80 dark:border-violet-500/60',
    glowColor: 'rgba(139, 92, 246, 0.65)',
  },
  SR: {
    code: 'SR',
    label: 'Super rare',
    shortLabel: 'Super rare',
    dropWeight: 10,
    color: '#ec4899',
    badgeClass: 'bg-pink-600/95 text-white border-pink-300/60',
    cardBgClass: 'bg-gradient-to-b from-pink-50 via-rose-50 to-pink-100/80 dark:from-[#33182a] dark:to-[#1f121b]',
    borderClass: 'border-pink-400/90 dark:border-pink-500/75',
    glowColor: 'rgba(236, 72, 153, 0.72)',
  },
  UR: {
    code: 'UR',
    label: 'Ultra rare',
    shortLabel: 'Ultra rare',
    dropWeight: 5.5,
    color: '#f97316',
    badgeClass: 'bg-orange-600/95 text-white border-amber-300/60',
    cardBgClass: 'bg-gradient-to-b from-orange-50 via-amber-50 to-orange-100/80 dark:from-[#362013] dark:to-[#21140d]',
    borderClass: 'border-orange-400 dark:border-orange-500/85',
    glowColor: 'rgba(249, 115, 22, 0.78)',
  },
  L: {
    code: 'L',
    label: 'Légendaire',
    shortLabel: 'Légendaire',
    dropWeight: 2.5,
    color: '#eab308',
    badgeClass: 'bg-gradient-to-r from-[#b8821f] to-[#e2bb6b] text-slate-950 font-bold border-amber-200/80',
    cardBgClass: 'bg-gradient-to-b from-amber-50 via-yellow-50 to-amber-100/90 dark:from-[#332711] dark:to-[#1c160b]',
    borderClass: 'border-[#c8952d] dark:border-[#e2bb6b]',
    glowColor: 'rgba(226, 187, 107, 0.85)',
  },
  EX: {
    code: 'EX',
    label: 'Exotique',
    shortLabel: 'Exotique',
    dropWeight: 1,
    color: '#06b6d4',
    badgeClass: 'bg-gradient-to-r from-cyan-500 to-teal-400 text-slate-950 font-bold border-cyan-200/90',
    cardBgClass: 'bg-gradient-to-b from-cyan-50 via-teal-50 to-cyan-100/80 dark:from-[#0e2a33] dark:to-[#0c1c22]',
    borderClass: 'border-cyan-400 dark:border-cyan-400',
    glowColor: 'rgba(6, 182, 212, 0.9)',
  },
};

export const CARDS: CardDef[] = [
  {
    id: 'site_labbe',
    number: 1,
    name: 'Site Labbé',
    rarity: 'C',
    campus: 'Labbé',
    image: '/assets/aistudio/image_d17a5889.jpg',
    atk: 42,
    def: 48,
    vit: 38,
    suggestedPrice: 15,
    lore: "Façade historique de pierre calcaire ouverte sur les filières générales, STI2D, BTS et CPGE TSI au cœur de Besançon.",
  },
  {
    id: 'site_marceau',
    number: 2,
    name: 'Site Marceau',
    rarity: 'PC',
    campus: 'Marceau',
    image: '/assets/aistudio/image-1_9d47ae5e.jpg',
    atk: 52,
    def: 50,
    vit: 48,
    suggestedPrice: 30,
    lore: "Pôle d'excellence professionnelle dédié aux métiers de l'horlogerie, de la bijouterie, de l'électricité et de la microtechnique.",
  },
  {
    id: 'cour_labbe',
    number: 3,
    name: 'Cour Intérieure Labbé',
    rarity: 'R',
    campus: 'Labbé',
    image: '/assets/aistudio/images_28d4c789.jpeg',
    atk: 58,
    def: 66,
    vit: 54,
    suggestedPrice: 60,
    lore: "Sous les arcades de pierre blonde, les générations d'élèves révisent leurs formules entre deux sonneries.",
  },
  {
    id: 'atelier_marceau',
    number: 4,
    name: 'Atelier Pro Marceau',
    rarity: 'SR',
    campus: 'Marceau',
    image: '/assets/aistudio/images-5_536a8b68.jpeg',
    atk: 76,
    def: 64,
    vit: 72,
    suggestedPrice: 130,
    lore: "Là où la précision au micron règne : établis d'horlogerie, tours numériques et montages industriels haute tension.",
  },
  {
    id: 'lycee_jules_haag',
    number: 5,
    name: 'Lycée Jules Haag',
    rarity: 'UR',
    campus: 'Jules Haag',
    image: '/src/assets/images/card_lycee_jules_haag_1795198381827.jpg',
    atk: 84,
    def: 82,
    vit: 78,
    suggestedPrice: 240,
    lore: "L'union des deux sites Labbé et Marceau sous le nom du grand mathématicien et horloger bisontin Jules Haag.",
  },
  {
    id: 'jh_legende',
    number: 6,
    name: 'Jules Haag Légende',
    rarity: 'L',
    campus: 'Jules Haag',
    image: '/src/assets/images/card_jh_legende_1795198382024.jpg',
    atk: 92,
    def: 90,
    vit: 86,
    suggestedPrice: 480,
    lore: "Hommage doré aux travaux sur le chronomètre et l'isochronisme qui ont fait rayonner l'École d'Horlogerie de Besançon.",
  },
  {
    id: 'jh_exotique',
    number: 7,
    name: 'JH Exotique',
    rarity: 'EX',
    campus: 'Jules Haag',
    image: '/src/assets/images/card_jh_exotique_1795198382020.jpg',
    atk: 98,
    def: 96,
    vit: 99,
    suggestedPrice: 900,
    lore: "Artefact prismatique ultime : un tourbillon perpétuel accordé sur la fréquence exacte des deux campus réunis.",
  },
  {
    id: 'cour_marceau',
    number: 8,
    name: 'Cour de Marceau',
    rarity: 'C',
    campus: 'Marceau',
    image: '/assets/aistudio/images-4_d3acd662.jpeg',
    atk: 40,
    def: 46,
    vit: 44,
    suggestedPrice: 15,
    lore: "Espace arboré et lumineux où les apprentis échangent plans de câblage et anecdotes d'atelier.",
  },
  {
    id: 'horloge_labbe',
    number: 9,
    name: 'Horloge de Labbé',
    rarity: 'PC',
    campus: 'Labbé',
    image: '/assets/aistudio/images-3_79d7815b.jpeg',
    atk: 49,
    def: 55,
    vit: 56,
    suggestedPrice: 32,
    lore: "Cadran Art Déco en bronze patiné qui rythme depuis les années 1930 l'entrée des cours et des devoirs surveillés.",
  },
  {
    id: 'verriere_marceau',
    number: 10,
    name: 'Verrière Marceau',
    rarity: 'R',
    campus: 'Marceau',
    image: '/src/assets/images/card_verriere_marceau_1795198381092.jpg',
    atk: 62,
    def: 60,
    vit: 65,
    suggestedPrice: 65,
    lore: "Grande nef d'acier et de verre baignant les halls techniques d'une lumière zénithale géométrique.",
  },
  {
    id: 'escalier_art_deco',
    number: 11,
    name: 'Escalier Art Déco',
    rarity: 'SR',
    campus: 'Labbé',
    image: '/assets/aistudio/images-2_948d2426.jpeg',
    atk: 70,
    def: 78,
    vit: 68,
    suggestedPrice: 135,
    lore: "Volée de terrazzo et garde-corps en fer forgé géométrique, joyau architectural de l'aile historique Labbé.",
  },
  {
    id: 'beffroi_art_deco',
    number: 12,
    name: 'Beffroi Art Déco',
    rarity: 'UR',
    campus: 'Labbé',
    image: '/src/assets/images/card_beffroi_art_deco_1795198381407.jpg',
    atk: 86,
    def: 84,
    vit: 74,
    suggestedPrice: 250,
    lore: "Tour signal élancée veillant sur le quartier Labbé, illuminée d'ambre dès la tombée du soir.",
  },
  {
    id: 'agora_stendhal',
    number: 13,
    name: 'Agora Stendhal-Marceau',
    rarity: 'UR',
    campus: 'Marceau',
    image: '/src/assets/images/card_agora_stendhal_1795198380907.jpg',
    atk: 80,
    def: 86,
    vit: 82,
    suggestedPrice: 245,
    lore: "Gradins de bois clair et verrière panoramique dédiés aux projets transversaux et aux rencontres étudiantes.",
  },
  {
    id: 'couronne_jh',
    number: 14,
    name: 'Couronne Jules Haag',
    rarity: 'L',
    campus: 'Jules Haag',
    image: '/src/assets/images/card_couronne_jh_1795198381430.jpg',
    atk: 90,
    def: 94,
    vit: 88,
    suggestedPrice: 500,
    lore: "Insigne ciselé de rouages dorés récompensant les maîtres stratèges de la Coupe Inter-Sites.",
  },
  {
    id: 'amphitheatre_labbe',
    number: 15,
    name: 'Amphithéâtre Labbé',
    rarity: 'R',
    campus: 'Labbé',
    image: '/assets/aistudio/images-1_7f26794d.jpeg',
    atk: 64,
    def: 62,
    vit: 58,
    suggestedPrice: 62,
    lore: "Gradins de chêne et tableaux noirs monumentaux où s'affrontent équations différentielles et soutenances de BTS.",
  },
];

export const CARD_BY_ID: Record<CardId, CardDef> = CARDS.reduce(
  (acc, card) => {
    acc[card.id] = card;
    return acc;
  },
  {} as Record<CardId, CardDef>
);

export const ALL_CARD_IDS: CardId[] = CARDS.map((c) => c.id);

export const EMPTY_INVENTORY: Record<CardId, number> = CARDS.reduce(
  (acc, card) => {
    acc[card.id] = 0;
    return acc;
  },
  {} as Record<CardId, number>
);

export const STARTER_CARD_IDS: CardId[] = ['site_labbe', 'site_marceau', 'cour_marceau'];

export const STARTER_INVENTORY: Record<CardId, number> = {
  ...EMPTY_INVENTORY,
  site_labbe: 1,
  site_marceau: 1,
  cour_marceau: 1,
};

export const EMPTY_STATS: PlayerStats = {
  packsOpened: 0,
  tradesCompleted: 0,
  auctionsWon: 0,
  auctionsSold: 0,
  cardsDiscarded: 0,
  soloWins: 0,
  pvpWins: 0,
};

export const CLASSES_BY_CAMPUS: { campus: Campus; label: string; items: string[] }[] = [
  {
    campus: 'Labbé',
    label: 'Voie Générale & Technologique',
    items: [
      '2nde Générale',
      '1ère Générale',
      'Term. Générale',
      '1ère STI2D',
      'Term. STI2D',
    ],
  },
  {
    campus: 'Labbé',
    label: 'Enseignement Supérieur (BTS & CPGE)',
    items: [
      'BTS CIEL',
      'BTS CIM',
      'BTS Électrotechnique',
      'BTS Optique',
      'BTS CPRP',
      'CPGE TSI',
      'Équipe JH',
    ],
  },
  {
    campus: 'Marceau',
    label: 'CAP & Métiers d’Art',
    items: [
      'CAP Horlogerie',
      'CAP Bijouterie',
      'CAP Électricien',
      'BMA Horlogerie',
      'BMA Bijouterie',
    ],
  },
  {
    campus: 'Marceau',
    label: 'Bac Pro & Équipe',
    items: [
      'Bac Pro PMIA',
      'Bac Pro TNE',
      'Bac Pro Microtechniques',
      'Bac Pro MELEC',
      'Bac Pro CIEL',
      'Bac Pro TRPM',
      'Bac Pro MSPC',
      'Équipe JH',
    ],
  },
];

export function rollPackCards(): CardId[] {
  const totalWeight = RARITY_ORDER.reduce((sum, r) => sum + RARITY_META[r].dropWeight, 0);
  const pickRarity = (minRarePlus = false): Rarity => {
    const pool = minRarePlus ? (['EX', 'L', 'UR', 'SR', 'R'] as Rarity[]) : RARITY_ORDER;
    const poolWeight = pool.reduce((sum, r) => sum + RARITY_META[r].dropWeight, 0);
    let roll = Math.random() * (minRarePlus ? poolWeight : totalWeight);
    for (const r of pool) {
      roll -= RARITY_META[r].dropWeight;
      if (roll <= 0) return r;
    }
    return pool[pool.length - 1];
  };

  const results: CardId[] = [];
  for (let i = 0; i < 5; i++) {
    // Slot 5 guarantees at least Rare (R) or better for exciting booster pulls
    const rarity = pickRarity(i === 4);
    const candidates = CARDS.filter((c) => c.rarity === rarity);
    const chosen = candidates[Math.floor(Math.random() * candidates.length)];
    results.push(chosen.id);
  }
  return results;
}

export function getBestRarityInPull(cardIds: CardId[]): Rarity {
  for (const r of RARITY_ORDER) {
    if (cardIds.some((id) => CARD_BY_ID[id]?.rarity === r)) {
      return r;
    }
  }
  return 'C';
}

export function getTotalOwnedCards(inventory: Record<CardId, number>): number {
  return ALL_CARD_IDS.reduce((sum, id) => sum + (inventory[id] || 0), 0);
}

export function getUniqueOwnedCards(inventory: Record<CardId, number>): number {
  return ALL_CARD_IDS.filter((id) => (inventory[id] || 0) > 0).length;
}

export function pickBestDeck(inventory: Record<CardId, number>): CardId[] {
  const owned = CARDS.filter((c) => (inventory[c.id] || 0) > 0).sort(
    (a, b) => b.atk + b.def + b.vit - (a.atk + a.def + a.vit)
  );
  return owned.slice(0, 3).map((c) => c.id);
}

export function computeStanceOutcome(
  hostStance: Stance,
  guestStance: Stance
): 'host' | 'guest' | 'draw' {
  if (hostStance === guestStance) return 'draw';
  if (
    (hostStance === 'assaut' && guestStance === 'contre') ||
    (hostStance === 'defense' && guestStance === 'assaut') ||
    (hostStance === 'contre' && guestStance === 'defense')
  ) {
    return 'host';
  }
  return 'guest';
}

export function computeCardDuelPower(
  cardId: CardId,
  stance: Stance,
  playerCampus: Campus,
  hasTacticalAdvantage: boolean
): number {
  const card = CARD_BY_ID[cardId];
  const base =
    stance === 'assaut'
      ? card.atk * 1.15 + card.vit * 0.25 + card.def * 0.15
      : stance === 'defense'
      ? card.def * 1.15 + card.atk * 0.2 + card.vit * 0.2
      : card.vit * 1.15 + card.atk * 0.25 + card.def * 0.15;

  const campusBonus =
    card.campus === playerCampus || card.campus === 'Jules Haag' ? 1.1 : 1.0;
  const tacticalBonus = hasTacticalAdvantage ? 1.18 : 1.0;
  return Math.round(base * campusBonus * tacticalBonus);
}
