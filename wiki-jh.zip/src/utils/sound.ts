class SoundEngine {
  private ctx: AudioContext | null = null;
  private muted: boolean = false;

  constructor() {
    try {
      this.muted = localStorage.getItem('wikijh_muted') === 'true';
    } catch {
      this.muted = false;
    }
  }

  private getCtx(): AudioContext | null {
    if (this.muted) return null;
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public isMuted(): boolean {
    return this.muted;
  }

  public setMuted(val: boolean): void {
    this.muted = val;
    try {
      localStorage.setItem('wikijh_muted', String(val));
    } catch {
      // ignore storage errors
    }
  }

  private tone(
    freq: number,
    duration: number,
    type: OscillatorType = 'sine',
    gainVal = 0.08,
    delay = 0,
    endFreq?: number
  ) {
    const ctx = this.getCtx();
    if (!ctx) return;
    const now = ctx.currentTime + delay;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    if (endFreq) {
      osc.frequency.exponentialRampToValueAtTime(endFreq, now + duration);
    }
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(gainVal, now + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + duration + 0.02);
  }

  public playClick() {
    this.tone(520, 0.055, 'triangle', 0.04, 0, 380);
  }

  public playPackTear() {
    const ctx = this.getCtx();
    if (!ctx) return;
    // Crisp tearing whoosh + shimmer
    this.tone(180, 0.28, 'sawtooth', 0.06, 0, 620);
    this.tone(360, 0.22, 'triangle', 0.05, 0.06, 880);
  }

  public playCardFlip() {
    this.tone(440, 0.09, 'sine', 0.05, 0, 680);
  }

  public playRareReveal() {
    this.tone(523.25, 0.18, 'triangle', 0.07, 0);
    this.tone(659.25, 0.18, 'triangle', 0.07, 0.08);
    this.tone(783.99, 0.3, 'sine', 0.08, 0.16);
  }

  public playExoticReveal() {
    const notes = [523.25, 659.25, 783.99, 1046.5, 1318.5];
    notes.forEach((n, idx) => {
      this.tone(n, 0.35, 'triangle', 0.075, idx * 0.065);
    });
  }

  public playDuelHit() {
    this.tone(150, 0.14, 'square', 0.065, 0, 65);
    this.tone(240, 0.1, 'sawtooth', 0.04, 0.02, 110);
  }

  public playVictory() {
    this.tone(440, 0.16, 'triangle', 0.07, 0);
    this.tone(554.37, 0.16, 'triangle', 0.07, 0.11);
    this.tone(659.25, 0.22, 'triangle', 0.08, 0.22);
    this.tone(880, 0.4, 'sine', 0.09, 0.34);
  }

  public playCoinGain() {
    this.tone(987.77, 0.09, 'sine', 0.06, 0);
    this.tone(1318.51, 0.18, 'sine', 0.07, 0.07);
  }
}

export const soundFx = new SoundEngine();
