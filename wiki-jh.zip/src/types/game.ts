import type { Timestamp } from 'firebase/firestore';

export type Campus = 'Labbé' | 'Marceau';
export type CardCampus = Campus | 'Jules Haag';
export type Rarity = 'C' | 'PC' | 'R' | 'SR' | 'UR' | 'L' | 'EX';
export type Stance = 'assaut' | 'defense' | 'contre';

export type CardId =
  | 'site_labbe'
  | 'site_marceau'
  | 'cour_labbe'
  | 'atelier_marceau'
  | 'lycee_jules_haag'
  | 'jh_legende'
  | 'jh_exotique'
  | 'cour_marceau'
  | 'horloge_labbe'
  | 'verriere_marceau'
  | 'escalier_art_deco'
  | 'beffroi_art_deco'
  | 'agora_stendhal'
  | 'couronne_jh'
  | 'amphitheatre_labbe';

export interface CardDef {
  id: CardId;
  number: number;
  name: string;
  rarity: Rarity;
  campus: CardCampus;
  image: string;
  atk: number;
  def: number;
  vit: number;
  suggestedPrice: number;
  lore: string;
}

export interface PlayerStats {
  packsOpened: number;
  tradesCompleted: number;
  auctionsWon: number;
  auctionsSold: number;
  cardsDiscarded: number;
  soloWins: number;
  pvpWins: number;
}

export interface PlayerProfile {
  uid: string;
  pseudo: string;
  campus: Campus;
  classe: string;
  bio: string;
  elo: number;
  wins: number;
  losses: number;
  coins: number;
  packs: number;
  lastPackRegenAt: Timestamp;
  lastSoloWinAt?: Timestamp;
  inventory: Record<CardId, number>;
  discoveredCards: CardId[];
  deck: CardId[];
  showcase: CardId[];
  equippedEmblem: string;
  equippedFrame: string;
  equippedBanner: string;
  equippedTitle: string;
  unlockedCosmetics: string[];
  claimedAchievements: string[];
  lastPackPull: CardId[];
  stats: PlayerStats;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface AdminRecord {
  uid: string;
  pseudo: string;
  promotedBy: string;
  createdAt: Timestamp;
}

export interface Friendship {
  id: string;
  users: string[];
  requesterId: string;
  recipientId: string;
  status: 'pending' | 'accepted';
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface TradeOffer {
  id: string;
  senderId: string;
  senderPseudo: string;
  recipientId: string;
  recipientPseudo: string;
  participants: string[];
  offeredCards: CardId[];
  requestedCards: CardId[];
  status: 'pending' | 'accepted' | 'rejected' | 'cancelled';
  senderClaimed: boolean;
  recipientClaimed: boolean;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface BidHistoryItem {
  uid: string;
  pseudo: string;
  amount: number;
  at: number;
}

export interface AuctionListing {
  id: string;
  sellerId: string;
  sellerPseudo: string;
  cardId: CardId;
  startingPrice: number;
  buyoutPrice: number;
  currentBid: number;
  highestBidderId: string;
  highestBidderPseudo: string;
  bidHistory: BidHistoryItem[];
  pendingRefunds: Record<string, number>;
  status: 'active' | 'sold' | 'ended' | 'cancelled';
  sellerClaimed: boolean;
  winnerClaimed: boolean;
  endsAt: Timestamp;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface DuelRoundResult {
  round: number;
  hostCard: CardId;
  hostStance: Stance;
  hostPower: number;
  guestCard: CardId;
  guestStance: Stance;
  guestPower: number;
  winner: 'host' | 'guest' | 'draw';
}

export interface DuelRoom {
  id: string;
  mode: 'ranked' | 'friendly';
  hostId: string;
  hostPseudo: string;
  hostCampus: Campus;
  hostElo: number;
  hostDeck: CardId[];
  guestId: string;
  guestPseudo: string;
  guestCampus: Campus | '';
  guestElo: number;
  guestDeck: CardId[];
  participants: string[];
  status: 'open' | 'active' | 'finished' | 'cancelled';
  currentRound: number;
  roundStartedAt: Timestamp;
  hostScore: number;
  guestScore: number;
  roundHistory: DuelRoundResult[];
  winnerId: string;
  forfeitedBy: string;
  hostClaimed: boolean;
  guestClaimed: boolean;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface DuelMove {
  uid: string;
  round: number;
  cardId: CardId;
  stance: Stance;
  createdAt: Timestamp;
}

export interface MatchmakingEntry {
  uid: string;
  pseudo: string;
  campus: Campus;
  elo: number;
  deck: CardId[];
  status: 'waiting' | 'matched';
  duelId: string;
  matchedWith: string;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export type NavTab =
  | 'paquets'
  | 'collection'
  | 'echanges'
  | 'marche'
  | 'bataille'
  | 'amis'
  | 'classement'
  | 'profil'
  | 'admin';

export type ProfileSubTab = 'personnalisation' | 'succes' | 'boutique' | 'parametres';

export interface ToastMessage {
  id: string;
  text: string;
  tone?: 'default' | 'success' | 'warning' | 'error';
}

export interface AppNotification {
  id: string;
  title: string;
  detail: string;
  targetTab: NavTab;
  kind: 'auction' | 'friend' | 'trade' | 'achievement';
}
