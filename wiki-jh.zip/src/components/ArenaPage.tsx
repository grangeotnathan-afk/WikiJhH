import React, { useState, useEffect } from 'react';
import {
  Swords,
  Shield,
  Zap,
  Cpu,
  Users,
  Wand2,
  Clock,
  Flag,
  Check,
  Search,
  Trophy,
} from 'lucide-react';
import type {
  Campus,
  CardId,
  DuelMove,
  DuelRoom,
  DuelRoundResult,
  PlayerProfile,
  Stance,
} from '../types/game';
import {
  CARDS,
  CARD_BY_ID,
  RARITY_META,
  computeCardDuelPower,
  computeStanceOutcome,
  pickBestDeck,
} from '../data/cards';
import { soundFx } from '../utils/sound';
import { CardVisual } from './CardVisual';

interface ArenaPageProps {
  player: PlayerProfile;
  openDuels: DuelRoom[];
  activeDuel: DuelRoom | null;
  activeDuelMoves: DuelMove[];
  inMatchmaking: boolean;
  onSaveDeck: (deck: CardId[]) => Promise<void>;
  onJoinMatchmaking: () => Promise<void>;
  onLeaveMatchmaking: () => Promise<void>;
  onCreateLobby: (mode: 'ranked' | 'friendly') => Promise<void>;
  onJoinLobby: (duel: DuelRoom) => Promise<void>;
  onCancelLobby: (duel: DuelRoom) => Promise<void>;
  onSubmitPvpMove: (duel: DuelRoom, cardId: CardId, stance: Stance) => Promise<void>;
  onResolvePvpRound: (duel: DuelRoom, moves: DuelMove[]) => Promise<void>;
  onForfeitDuel: (duel: DuelRoom) => Promise<void>;
  onClaimDuelReward: (duel: DuelRoom) => Promise<void>;
  onSoloWin: () => Promise<void>;
}

const STANCE_INFO: {
  id: Stance;
  label: string;
  bonus: string;
  beats: string;
  icon: React.ReactNode;
}[] = [
  {
    id: 'assaut',
    label: 'Assaut',
    bonus: '+ATK',
    beats: 'Bat Contre',
    icon: <Swords className="w-4 h-4 text-rose-500" />,
  },
  {
    id: 'defense',
    label: 'Défense',
    bonus: '+DEF',
    beats: 'Bat Assaut',
    icon: <Shield className="w-4 h-4 text-blue-500" />,
  },
  {
    id: 'contre',
    label: 'Contre',
    bonus: '+VIT',
    beats: 'Bat Défense',
    icon: <Zap className="w-4 h-4 text-amber-500" />,
  },
];

export function ArenaPage({
  player,
  openDuels,
  activeDuel,
  activeDuelMoves,
  inMatchmaking,
  onSaveDeck,
  onJoinMatchmaking,
  onLeaveMatchmaking,
  onCreateLobby,
  onJoinLobby,
  onCancelLobby,
  onSubmitPvpMove,
  onResolvePvpRound,
  onForfeitDuel,
  onClaimDuelReward,
  onSoloWin,
}: ArenaPageProps) {
  const [subTab, setSubTab] = useState<'matchmaking' | 'defier' | 'deck' | 'solo'>(
    'matchmaking'
  );
  const [nowMs, setNowMs] = useState(Date.now());
  const [lobbyMode, setLobbyMode] = useState<'ranked' | 'friendly'>('ranked');
  const [savingDeck, setSavingDeck] = useState(false);

  // PvP Duel local round pick
  const [pvpSelectedCard, setPvpSelectedCard] = useState<CardId | null>(null);
  const [pvpSelectedStance, setPvpSelectedStance] = useState<Stance>('assaut');
  const [submittingMove, setSubmittingMove] = useState(false);

  // Solo Training State
  const [soloActive, setSoloActive] = useState(false);
  const [soloRound, setSoloRound] = useState(1);
  const [soloPlayerScore, setSoloPlayerScore] = useState(0);
  const [soloBotScore, setSoloBotScore] = useState(0);
  const [soloBotDeck, setSoloBotDeck] = useState<CardId[]>([]);
  const [soloUsedPlayerCards, setSoloUsedPlayerCards] = useState<CardId[]>([]);
  const [soloUsedBotCards, setSoloUsedBotCards] = useState<CardId[]>([]);
  const [soloHistory, setSoloHistory] = useState<DuelRoundResult[]>([]);
  const [soloSelectedCard, setSoloSelectedCard] = useState<CardId | null>(null);
  const [soloSelectedStance, setSoloSelectedStance] = useState<Stance>('assaut');
  const [soloFinished, setSoloFinished] = useState<'win' | 'loss' | 'draw' | null>(null);

  useEffect(() => {
    const id = setInterval(() => setNowMs(Date.now()), 500);
    return () => clearInterval(id);
  }, []);

  const effectiveDeck: CardId[] =
    player.deck && player.deck.length === 3
      ? player.deck
      : pickBestDeck(player.inventory);

  const botCampus: Campus = player.campus === 'Labbé' ? 'Marceau' : 'Labbé';
  const lastSoloMs = player.lastSoloWinAt?.toMillis?.() || 0;
  const soloCooldownRemaining = Math.max(0, 35 - Math.floor((nowMs - lastSoloMs) / 1000));

  // Auto-resolve PvP round if both moves arrived or 25s expired
  useEffect(() => {
    if (!activeDuel || activeDuel.status !== 'active') return;
    const roundMoves = activeDuelMoves.filter((m) => m.round === activeDuel.currentRound);
    const hasHost = roundMoves.some((m) => m.uid === activeDuel.hostId);
    const hasGuest = roundMoves.some((m) => m.uid === activeDuel.guestId);
    const elapsedSec =
      (nowMs - (activeDuel.roundStartedAt?.toMillis?.() || nowMs)) / 1000;

    if ((hasHost && hasGuest) || elapsedSec >= 27) {
      if (activeDuel.hostId === player.uid || elapsedSec >= 28) {
        onResolvePvpRound(activeDuel, roundMoves);
      }
    }
  }, [activeDuel, activeDuelMoves, nowMs]);

  const startSoloDuel = () => {
    if (effectiveDeck.length < 3) return;
    const botPool = CARDS.filter((c) => c.campus === botCampus || c.campus === 'Jules Haag')
      .sort(() => Math.random() - 0.5)
      .slice(0, 3)
      .map((c) => c.id);
    setSoloBotDeck(botPool);
    setSoloRound(1);
    setSoloPlayerScore(0);
    setSoloBotScore(0);
    setSoloUsedPlayerCards([]);
    setSoloUsedBotCards([]);
    setSoloHistory([]);
    setSoloSelectedCard(effectiveDeck[0]);
    setSoloSelectedStance('assaut');
    setSoloFinished(null);
    setSoloActive(true);
    soundFx.playClick();
  };

  const playSoloRound = async () => {
    if (!soloSelectedCard || soloFinished) return;
    const botChoices = soloBotDeck.filter((id) => !soloUsedBotCards.includes(id));
    const botCard = botChoices[Math.floor(Math.random() * botChoices.length)] || soloBotDeck[0];
    const stances: Stance[] = ['assaut', 'defense', 'contre'];
    const botStance = stances[Math.floor(Math.random() * stances.length)];

    const stanceOutcome = computeStanceOutcome(soloSelectedStance, botStance);
    const pPower = computeCardDuelPower(
      soloSelectedCard,
      soloSelectedStance,
      player.campus,
      stanceOutcome === 'host'
    );
    const bPower = computeCardDuelPower(
      botCard,
      botStance,
      botCampus,
      stanceOutcome === 'guest'
    );

    soundFx.playDuelHit();

    const roundWinner: 'host' | 'guest' | 'draw' =
      pPower > bPower ? 'host' : bPower > pPower ? 'guest' : 'draw';

    const nextPlayerScore = soloPlayerScore + (roundWinner === 'host' ? 1 : 0);
    const nextBotScore = soloBotScore + (roundWinner === 'guest' ? 1 : 0);
    const nextUsedPlayer = [...soloUsedPlayerCards, soloSelectedCard];
    const nextUsedBot = [...soloUsedBotCards, botCard];
    const entry: DuelRoundResult = {
      round: soloRound,
      hostCard: soloSelectedCard,
      hostStance: soloSelectedStance,
      hostPower: pPower,
      guestCard: botCard,
      guestStance: botStance,
      guestPower: bPower,
      winner: roundWinner,
    };

    setSoloHistory((prev) => [...prev, entry]);
    setSoloPlayerScore(nextPlayerScore);
    setSoloBotScore(nextBotScore);
    setSoloUsedPlayerCards(nextUsedPlayer);
    setSoloUsedBotCards(nextUsedBot);

    const remaining = effectiveDeck.filter((id) => !nextUsedPlayer.includes(id));
    setSoloSelectedCard(remaining[0] || null);

    if (nextPlayerScore >= 2 || nextBotScore >= 2 || soloRound >= 3) {
      const outcome =
        nextPlayerScore > nextBotScore
          ? 'win'
          : nextBotScore > nextPlayerScore
          ? 'loss'
          : 'draw';
      setSoloFinished(outcome);
      if (outcome === 'win') {
        soundFx.playVictory();
        await onSoloWin();
      }
    } else {
      setSoloRound((r) => r + 1);
    }
  };

  // Active PvP Duel View
  if (activeDuel) {
    const isHost = activeDuel.hostId === player.uid;
    const myDeck = isHost ? activeDuel.hostDeck : activeDuel.guestDeck;
    const usedMyCards = activeDuel.roundHistory.map((r) => (isHost ? r.hostCard : r.guestCard));
    const availableMyCards = myDeck.filter((c) => !usedMyCards.includes(c));
    const myCurrentMove = activeDuelMoves.find(
      (m) => m.round === activeDuel.currentRound && m.uid === player.uid
    );
    const opponentCurrentMove = activeDuelMoves.find(
      (m) => m.round === activeDuel.currentRound && m.uid !== player.uid
    );
    const roundElapsed = Math.floor(
      (nowMs - (activeDuel.roundStartedAt?.toMillis?.() || nowMs)) / 1000
    );
    const roundRemaining = Math.max(0, 25 - roundElapsed);
    const myScore = isHost ? activeDuel.hostScore : activeDuel.guestScore;
    const oppScore = isHost ? activeDuel.guestScore : activeDuel.hostScore;
    const oppPseudo = isHost ? activeDuel.guestPseudo : activeDuel.hostPseudo;
    const oppCampus = isHost ? activeDuel.guestCampus : activeDuel.hostCampus;
    const myClaimed = isHost ? activeDuel.hostClaimed : activeDuel.guestClaimed;

    return (
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 space-y-6 pb-24 md:pb-10">
        {/* Duel Scoreboard */}
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              {activeDuel.mode === 'ranked' ? 'Duel Classé PvP' : 'Duel Amical PvP'} · Manche{' '}
              {activeDuel.currentRound}/3
            </div>
            <div className="text-lg font-display font-bold text-slate-900 dark:text-white mt-0.5">
              {player.pseudo} ({player.campus}) vs {oppPseudo} ({oppCampus})
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-[#22262c] font-mono-num text-xl font-bold">
              <span className="text-emerald-500">{myScore}</span>
              <span className="mx-2 text-slate-400">-</span>
              <span className="text-rose-500">{oppScore}</span>
            </div>

            {activeDuel.status === 'active' && (
              <>
                <div className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-amber-500/30 bg-amber-500/10 font-mono-num text-sm font-bold text-amber-600 dark:text-amber-400">
                  <Clock className="w-4 h-4" />
                  <span>{roundRemaining}s</span>
                </div>
                <button
                  type="button"
                  onClick={() => onForfeitDuel(activeDuel)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-rose-500/30 bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 text-xs font-semibold cursor-pointer"
                >
                  <Flag className="w-3.5 h-3.5" />
                  <span>Abandonner</span>
                </button>
              </>
            )}
          </div>
        </div>

        {/* Finished Summary */}
        {activeDuel.status === 'finished' ? (
          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-6 text-center space-y-4">
            <Trophy
              className={`w-12 h-12 mx-auto ${
                activeDuel.winnerId === player.uid ? 'text-[#e2bb6b]' : 'text-slate-400'
              }`}
            />
            <h2 className="text-2xl font-display font-bold text-slate-900 dark:text-white">
              {activeDuel.winnerId === player.uid
                ? 'Victoire dans l’Arène !'
                : activeDuel.winnerId === ''
                ? 'Match nul !'
                : 'Défaite'}
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-300">
              {activeDuel.forfeitedBy
                ? activeDuel.forfeitedBy === player.uid
                  ? 'Vous avez abandonné le duel.'
                  : `${oppPseudo} a abandonné le duel.`
                : `Score final : ${myScore} - ${oppScore}`}
            </p>
            {!myClaimed && (
              <button
                type="button"
                onClick={() => onClaimDuelReward(activeDuel)}
                className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold cursor-pointer"
              >
                Récupérer ma récompense ({activeDuel.winnerId === player.uid ? '+65 ●' : '+20 ●'})
              </button>
            )}
          </div>
        ) : (
          /* Active Round Controls */
          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 space-y-5">
            {myCurrentMove ? (
              <div className="py-8 text-center space-y-2">
                <div className="text-base font-semibold text-emerald-600 dark:text-emerald-400">
                  Coup verrouillé : {CARD_BY_ID[myCurrentMove.cardId].name} ({myCurrentMove.stance})
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {opponentCurrentMove
                    ? 'Résolution de la manche en cours…'
                    : `En attente du choix de ${oppPseudo}…`}
                </p>
              </div>
            ) : (
              <>
                <div>
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-3">
                    1. Choisissez une carte non encore jouée de votre deck
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {availableMyCards.map((cid) => (
                      <CardVisual
                        key={cid}
                        cardId={cid}
                        compact
                        selected={pvpSelectedCard === cid}
                        onClick={() => setPvpSelectedCard(cid)}
                      />
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-3">
                    2. Choisissez votre posture tactique (+18 % si posture gagnante, +10 % bonus campus)
                  </h3>
                  <div className="grid grid-cols-3 gap-3">
                    {STANCE_INFO.map((s) => (
                      <button
                        key={s.id}
                        type="button"
                        onClick={() => setPvpSelectedStance(s.id)}
                        className={`p-3 rounded-xl border text-left transition-colors cursor-pointer ${
                          pvpSelectedStance === s.id
                            ? 'border-emerald-500 bg-emerald-500/10'
                            : 'border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c]'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-semibold text-slate-900 dark:text-white">
                            {s.label}
                          </span>
                          {s.icon}
                        </div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                          {s.bonus} · {s.beats}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex justify-end">
                  <button
                    type="button"
                    disabled={!pvpSelectedCard || submittingMove}
                    onClick={async () => {
                      if (!pvpSelectedCard) return;
                      setSubmittingMove(true);
                      try {
                        await onSubmitPvpMove(activeDuel, pvpSelectedCard, pvpSelectedStance);
                        setPvpSelectedCard(null);
                      } finally {
                        setSubmittingMove(false);
                      }
                    }}
                    className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-45 text-white text-sm font-semibold cursor-pointer"
                  >
                    Valider la manche {activeDuel.currentRound}
                  </button>
                </div>
              </>
            )}
          </div>
        )}

        {/* Round-by-Round Log */}
        {activeDuel.roundHistory.length > 0 && (
          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 space-y-2.5">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
              Historique des manches
            </h3>
            {activeDuel.roundHistory.map((r) => {
              const minePow = isHost ? r.hostPower : r.guestPower;
              const oppPow = isHost ? r.guestPower : r.hostPower;
              const mineCard = isHost ? r.hostCard : r.guestCard;
              const oppCard = isHost ? r.guestCard : r.hostCard;
              const mineWin =
                (isHost && r.winner === 'host') || (!isHost && r.winner === 'guest');
              return (
                <div
                  key={r.round}
                  className="flex flex-wrap items-center justify-between gap-2 px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-[#22262c] text-xs"
                >
                  <span className="font-mono-num font-bold">Manche {r.round}</span>
                  <span>
                    {CARD_BY_ID[mineCard].name} ({minePow}) vs {CARD_BY_ID[oppCard].name} ({oppPow})
                  </span>
                  <span
                    className={`font-semibold ${
                      r.winner === 'draw'
                        ? 'text-slate-500'
                        : mineWin
                        ? 'text-emerald-500'
                        : 'text-rose-500'
                    }`}
                  >
                    {r.winner === 'draw' ? 'Égalité' : mineWin ? 'Gagnée' : 'Perdue'}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6 pb-24 md:pb-10">
      {/* Header ELO & Record */}
      <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-display font-bold text-slate-900 dark:text-white">
            Arène de Bataille
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Duels tactiques en 3 manches · Bonus Campus (+10 %) & Posture (+18 %) · +65 ● par victoire PvP
          </p>
        </div>

        <div className="flex items-center gap-4">
          <div className="px-4 py-2 rounded-xl bg-slate-50 dark:bg-[#22262c] border border-slate-200 dark:border-white/10 text-center">
            <div className="text-[11px] text-slate-500 dark:text-slate-400">ELO Classé</div>
            <div className="font-mono-num text-lg font-bold text-[#c8952d] dark:text-[#e2bb6b]">
              {player.elo}
            </div>
          </div>
          <div className="px-4 py-2 rounded-xl bg-slate-50 dark:bg-[#22262c] border border-slate-200 dark:border-white/10 text-center">
            <div className="text-[11px] text-slate-500 dark:text-slate-400">Bilan (V / D)</div>
            <div className="font-mono-num text-lg font-bold text-slate-900 dark:text-white">
              <span className="text-emerald-500">{player.wins}</span>
              <span className="mx-1 text-slate-400">/</span>
              <span className="text-rose-500">{player.losses}</span>
            </div>
          </div>
        </div>
      </div>

      {/* 4 Sub-tabs */}
      <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-200/70 dark:bg-[#181b1f] border border-slate-200 dark:border-white/10 overflow-x-auto">
        {(
          [
            { id: 'matchmaking', label: 'Matchmaking PvP' },
            { id: 'defier', label: `Défier des joueurs (${openDuels.length})` },
            { id: 'deck', label: `Mon Deck (${effectiveDeck.length}/3)` },
            { id: 'solo', label: 'Entraînement Solo' },
          ] as const
        ).map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setSubTab(t.id)}
            className={`px-4 py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              subTab === t.id
                ? 'bg-white dark:bg-[#22262c] text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Sub-tab 1: Matchmaking PvP */}
      {subTab === 'matchmaking' && (
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-6 sm:p-8 text-center space-y-5">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-500">
            <Search className="w-7 h-7" />
          </div>
          <div className="max-w-md mx-auto space-y-2">
            <h2 className="text-xl font-display font-bold text-slate-900 dark:text-white">
              Matchmaking Classé en temps réel
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-300">
              Rejoignez la file d’attente pour affronter automatiquement le prochain joueur disponible avec votre deck de 3 cartes.
            </p>
          </div>

          {effectiveDeck.length < 3 ? (
            <div className="text-xs text-rose-500">
              Vous devez posséder au moins 3 cartes différentes dans votre deck pour combattre.
            </div>
          ) : inMatchmaking ? (
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-xs font-semibold">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>Recherche d’un adversaire en cours…</span>
              </div>
              <div>
                <button
                  type="button"
                  onClick={onLeaveMatchmaking}
                  className="px-5 py-2.5 rounded-xl border border-slate-300 dark:border-white/15 text-xs font-semibold text-slate-700 dark:text-slate-200 cursor-pointer"
                >
                  Quitter la file
                </button>
              </div>
            </div>
          ) : (
            <button
              type="button"
              onClick={onJoinMatchmaking}
              className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold shadow-lg shadow-emerald-900/20 cursor-pointer"
            >
              Lancer la recherche classée
            </button>
          )}
        </div>
      )}

      {/* Sub-tab 2: Public Duel Lobbies */}
      {subTab === 'defier' && (
        <div className="space-y-4">
          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-base font-display font-bold text-slate-900 dark:text-white">
                Créer un salon public
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Choisissez un défi Classé (modifie l’ELO) ou Amical (sans enjeu ELO).
              </p>
            </div>
            <div className="flex items-center gap-2">
              <select
                value={lobbyMode}
                onChange={(e) => setLobbyMode(e.target.value as 'ranked' | 'friendly')}
                className="px-3 py-2 rounded-xl text-xs font-semibold border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] text-slate-900 dark:text-white"
              >
                <option value="ranked">Défi Classé</option>
                <option value="friendly">Défi Amical</option>
              </select>
              <button
                type="button"
                disabled={effectiveDeck.length < 3}
                onClick={() => onCreateLobby(lobbyMode)}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-45 text-white text-xs font-semibold cursor-pointer whitespace-nowrap"
              >
                <Users className="w-3.5 h-3.5" />
                <span>Ouvrir un salon</span>
              </button>
            </div>
          </div>

          {openDuels.length === 0 ? (
            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-10 text-center text-sm text-slate-500 dark:text-slate-400">
              Aucun salon de duel ouvert en ce moment. Créez-en un ci-dessus !
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {openDuels.map((d) => {
                const isMine = d.hostId === player.uid;
                return (
                  <div
                    key={d.id}
                    className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-4 flex items-center justify-between gap-3"
                  >
                    <div>
                      <div className="text-sm font-semibold text-slate-900 dark:text-white">
                        {d.hostPseudo}{' '}
                        <span
                          className={
                            d.hostCampus === 'Labbé' ? 'text-blue-500' : 'text-emerald-500'
                          }
                        >
                          · {d.hostCampus}
                        </span>
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400 font-mono-num mt-0.5">
                        {d.mode === 'ranked' ? 'Défi Classé' : 'Défi Amical'} · {d.hostElo} ELO
                      </div>
                    </div>
                    {isMine ? (
                      <button
                        type="button"
                        onClick={() => onCancelLobby(d)}
                        className="px-3.5 py-2 rounded-xl border border-rose-500/30 text-rose-500 text-xs font-semibold cursor-pointer"
                      >
                        Fermer
                      </button>
                    ) : (
                      <button
                        type="button"
                        disabled={effectiveDeck.length < 3}
                        onClick={() => onJoinLobby(d)}
                        className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold cursor-pointer"
                      >
                        Rejoindre
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Sub-tab 3: Deck Builder (3 unique cards) */}
      {subTab === 'deck' && (
        <div className="space-y-5">
          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-display font-bold text-slate-900 dark:text-white">
                Mon Deck de Combat (3 cartes uniques)
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Cliquez sur vos cartes possédées ci-dessous pour composer votre trio.
              </p>
            </div>
            <button
              type="button"
              disabled={savingDeck}
              onClick={async () => {
                setSavingDeck(true);
                try {
                  await onSaveDeck(pickBestDeck(player.inventory));
                } finally {
                  setSavingDeck(false);
                }
              }}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#c8952d] hover:bg-[#b58422] text-slate-950 text-xs font-bold cursor-pointer whitespace-nowrap"
            >
              <Wand2 className="w-4 h-4" />
              <span>Meilleur deck auto</span>
            </button>
          </div>

          {/* Current 3 Slots */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[0, 1, 2].map((slot) => {
              const cid = effectiveDeck[slot];
              return cid ? (
                <CardVisual
                  key={`slot-${cid}`}
                  cardId={cid}
                  selected
                  onClick={() => {
                    // Replace/remove logic handled when clicking owned list
                  }}
                />
              ) : (
                <div
                  key={`empty-${slot}`}
                  className="h-64 rounded-2xl border-2 border-dashed border-slate-300 dark:border-white/15 flex items-center justify-center text-xs text-slate-400"
                >
                  Emplacement {slot + 1}
                </div>
              );
            })}
          </div>

          {/* All Owned Cards Picker */}
          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 space-y-3">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
              Cartes disponibles dans votre collection
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
              {CARDS.filter((c) => (player.inventory[c.id] || 0) > 0).map((c) => {
                const inDeck = effectiveDeck.includes(c.id);
                return (
                  <button
                    key={c.id}
                    type="button"
                    disabled={savingDeck}
                    onClick={async () => {
                      if (inDeck) return;
                      const nextDeck = [...effectiveDeck.slice(1), c.id];
                      setSavingDeck(true);
                      try {
                        await onSaveDeck(nextDeck);
                      } finally {
                        setSavingDeck(false);
                      }
                    }}
                    className={`p-3 rounded-xl border text-left transition-colors cursor-pointer ${
                      inDeck
                        ? 'border-emerald-500 bg-emerald-500/10'
                        : 'border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] hover:border-emerald-500/50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span
                        className="font-mono-num text-[11px] font-bold"
                        style={{ color: RARITY_META[c.rarity].color }}
                      >
                        {c.rarity}
                      </span>
                      {inDeck && <Check className="w-3.5 h-3.5 text-emerald-500" />}
                    </div>
                    <div className="text-xs font-semibold text-slate-900 dark:text-white truncate mt-1">
                      {c.name}
                    </div>
                    <div className="text-[10px] font-mono-num text-slate-500 dark:text-slate-400 mt-1">
                      {c.atk}/{c.def}/{c.vit}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Sub-tab 4: Solo Training */}
      {subTab === 'solo' && (
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 sm:p-6 space-y-5">
          {!soloActive ? (
            <div className="text-center py-6 space-y-4 max-w-lg mx-auto">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-500">
                <Cpu className="w-7 h-7" />
              </div>
              <h2 className="text-xl font-display font-bold text-slate-900 dark:text-white">
                Entraînement contre l’Automate {botCampus}
              </h2>
              <p className="text-sm text-slate-600 dark:text-slate-300">
                Affrontez un automate du campus opposé en 3 manches pour tester votre deck et remporter +15 ● par victoire (délai anti-spam de 35s).
              </p>
              <button
                type="button"
                disabled={effectiveDeck.length < 3 || soloCooldownRemaining > 0}
                onClick={startSoloDuel}
                className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-45 text-white text-sm font-semibold cursor-pointer"
              >
                {soloCooldownRemaining > 0
                  ? `Disponible dans ${soloCooldownRemaining}s`
                  : 'Démarrer le duel solo'}
              </button>
            </div>
          ) : (
            <div className="space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-white/10">
                <div className="text-sm font-semibold text-slate-900 dark:text-white">
                  {player.pseudo} vs Automate {botCampus} · Manche {soloRound}/3
                </div>
                <div className="font-mono-num text-lg font-bold">
                  <span className="text-emerald-500">{soloPlayerScore}</span>
                  <span className="mx-2 text-slate-400">-</span>
                  <span className="text-rose-500">{soloBotScore}</span>
                </div>
              </div>

              {soloFinished ? (
                <div className="text-center py-6 space-y-3">
                  <h3 className="text-2xl font-display font-bold text-slate-900 dark:text-white">
                    {soloFinished === 'win'
                      ? 'Victoire ! (+15 ●)'
                      : soloFinished === 'draw'
                      ? 'Match nul'
                      : 'Défaite'}
                  </h3>
                  <button
                    type="button"
                    onClick={() => setSoloActive(false)}
                    className="px-5 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-semibold cursor-pointer"
                  >
                    Retour
                  </button>
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {effectiveDeck
                      .filter((c) => !soloUsedPlayerCards.includes(c))
                      .map((cid) => (
                        <CardVisual
                          key={cid}
                          cardId={cid}
                          compact
                          selected={soloSelectedCard === cid}
                          onClick={() => setSoloSelectedCard(cid)}
                        />
                      ))}
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    {STANCE_INFO.map((s) => (
                      <button
                        key={s.id}
                        type="button"
                        onClick={() => setSoloSelectedStance(s.id)}
                        className={`p-3 rounded-xl border text-left cursor-pointer ${
                          soloSelectedStance === s.id
                            ? 'border-emerald-500 bg-emerald-500/10'
                            : 'border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c]'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-semibold">{s.label}</span>
                          {s.icon}
                        </div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                          {s.bonus} · {s.beats}
                        </div>
                      </button>
                    ))}
                  </div>

                  <div className="flex justify-end">
                    <button
                      type="button"
                      disabled={!soloSelectedCard}
                      onClick={playSoloRound}
                      className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold cursor-pointer"
                    >
                      Jouer la manche {soloRound}
                    </button>
                  </div>
                </>
              )}

              {soloHistory.length > 0 && (
                <div className="space-y-2 pt-3 border-t border-slate-200 dark:border-white/10">
                  {soloHistory.map((h) => (
                    <div
                      key={h.round}
                      className="flex flex-wrap items-center justify-between gap-2 px-3 py-2 rounded-xl bg-slate-50 dark:bg-[#22262c] text-xs"
                    >
                      <span className="font-mono-num font-bold">M{h.round}</span>
                      <span>
                        {CARD_BY_ID[h.hostCard].name} ({h.hostStance}, {h.hostPower}) vs{' '}
                        {CARD_BY_ID[h.guestCard].name} ({h.guestStance}, {h.guestPower})
                      </span>
                      <span
                        className={
                          h.winner === 'host'
                            ? 'text-emerald-500 font-semibold'
                            : h.winner === 'guest'
                            ? 'text-rose-500 font-semibold'
                            : 'text-slate-500'
                        }
                      >
                        {h.winner === 'host' ? 'Gagnée' : h.winner === 'guest' ? 'Perdue' : 'Nul'}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
