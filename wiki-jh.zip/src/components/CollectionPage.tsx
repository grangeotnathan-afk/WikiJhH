import React, { useState, useMemo } from 'react';
import { Search, CheckSquare, Trash2, X, Minus, Plus } from 'lucide-react';
import type { CardCampus, CardId, PlayerProfile, Rarity } from '../types/game';
import {
  CARDS,
  CARD_BY_ID,
  RARITY_ORDER,
  getTotalOwnedCards,
  getUniqueOwnedCards,
} from '../data/cards';
import { CardInspectModal, CardVisual } from './CardVisual';

interface CollectionPageProps {
  player: PlayerProfile;
  onDiscardOne: (cardId: CardId) => Promise<void>;
  onBatchDiscard: (items: Record<CardId, number>) => Promise<void>;
}

export function CollectionPage({
  player,
  onDiscardOne,
  onBatchDiscard,
}: CollectionPageProps) {
  const [search, setSearch] = useState('');
  const [campusFilter, setCampusFilter] = useState<'Tous' | CardCampus>('Tous');
  const [rarityFilter, setRarityFilter] = useState<'Toutes' | Rarity>('Toutes');
  const [showMissing, setShowMissing] = useState(true);
  const [inspectCard, setInspectCard] = useState<CardId | null>(null);
  const [selectMode, setSelectMode] = useState(false);
  const [discardSelection, setDiscardSelection] = useState<Partial<Record<CardId, number>>>({});
  const [confirmBatchOpen, setConfirmBatchOpen] = useState(false);
  const [batchBusy, setBatchBusy] = useState(false);

  const uniqueCount = getUniqueOwnedCards(player.inventory);
  const totalCount = getTotalOwnedCards(player.inventory);

  const filteredCards = useMemo(() => {
    const q = search.trim().toLowerCase();
    return CARDS.filter((c) => {
      const owned = player.inventory[c.id] || 0;
      if (!showMissing && owned === 0) return false;
      if (selectMode && owned === 0) return false;
      if (campusFilter !== 'Tous' && c.campus !== campusFilter) return false;
      if (rarityFilter !== 'Toutes' && c.rarity !== rarityFilter) return false;
      if (q) {
        const hay = `${c.name} ${c.rarity} ${c.campus}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    }).sort(
      (a, b) => RARITY_ORDER.indexOf(a.rarity) - RARITY_ORDER.indexOf(b.rarity)
    );
  }, [player.inventory, showMissing, selectMode, campusFilter, rarityFilter, search]);

  const selectedEntries = Object.entries(discardSelection).filter(
    ([, qty]) => (qty || 0) > 0
  ) as [CardId, number][];
  const totalBatchDiscard = selectedEntries.reduce((sum, [, qty]) => sum + qty, 0);

  const toggleCardSelection = (cardId: CardId) => {
    const owned = player.inventory[cardId] || 0;
    if (owned <= 0) return;
    setDiscardSelection((prev) => {
      const current = prev[cardId] || 0;
      const next = { ...prev };
      if (current > 0) {
        delete next[cardId];
      } else {
        next[cardId] = 1;
      }
      return next;
    });
  };

  const adjustSelectionQty = (cardId: CardId, delta: number) => {
    const owned = player.inventory[cardId] || 0;
    setDiscardSelection((prev) => {
      const current = prev[cardId] || 0;
      const nextQty = Math.max(0, Math.min(owned, current + delta));
      const next = { ...prev };
      if (nextQty === 0) {
        delete next[cardId];
      } else {
        next[cardId] = nextQty;
      }
      return next;
    });
  };

  const handleConfirmBatch = async () => {
    if (totalBatchDiscard <= 0 || batchBusy) return;
    setBatchBusy(true);
    try {
      await onBatchDiscard(discardSelection as Record<CardId, number>);
      setDiscardSelection({});
      setConfirmBatchOpen(false);
      setSelectMode(false);
    } finally {
      setBatchBusy(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6 pb-24 md:pb-10">
      {/* Header & Metrics */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-display font-bold text-slate-900 dark:text-white">
            Collection
          </h1>
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-1">
            <span>
              <strong className="font-mono-num text-slate-900 dark:text-white">
                {uniqueCount}/15
              </strong>{' '}
              cartes découvertes
            </span>
            <span aria-hidden="true">·</span>
            <span>
              <strong className="font-mono-num text-slate-900 dark:text-white">
                {totalCount}
              </strong>{' '}
              exemplaires au total
            </span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setShowMissing((v) => !v)}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold border transition-colors cursor-pointer ${
              showMissing
                ? 'border-slate-300 dark:border-white/15 bg-white dark:bg-[#181b1f] text-slate-800 dark:text-slate-200'
                : 'border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
            }`}
          >
            {showMissing ? 'Index complet (15)' : 'Possédées uniquement'}
          </button>

          <button
            type="button"
            onClick={() => {
              setSelectMode((v) => !v);
              setDiscardSelection({});
            }}
            className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold border transition-colors cursor-pointer ${
              selectMode
                ? 'border-rose-500 bg-rose-500/15 text-rose-600 dark:text-rose-400'
                : 'border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-[#22262c]'
            }`}
          >
            <CheckSquare className="w-3.5 h-3.5" />
            <span>{selectMode ? 'Quitter la sélection' : 'Sélectionner des cartes'}</span>
          </button>
        </div>
      </div>

      {/* Toolbar */}
      <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-4 space-y-3">
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Rechercher par nom, rareté ou campus…"
              className="w-full pl-9 pr-3 py-2 rounded-xl text-sm border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-100 dark:bg-[#22262c] overflow-x-auto">
            {(['Tous', 'Labbé', 'Marceau', 'Jules Haag'] as const).map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setCampusFilter(c)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                  campusFilter === c
                    ? 'bg-white dark:bg-[#181b1f] text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        {/* Rarity filter */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            type="button"
            onClick={() => setRarityFilter('Toutes')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              rarityFilter === 'Toutes'
                ? 'bg-emerald-600 text-white'
                : 'bg-slate-100 dark:bg-[#22262c] text-slate-600 dark:text-slate-300'
            }`}
          >
            Toutes
          </button>
          {RARITY_ORDER.map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setRarityFilter(r)}
              className={`px-3 py-1 rounded-lg text-xs font-mono-num font-bold transition-colors cursor-pointer ${
                rarityFilter === r
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-100 dark:bg-[#22262c] text-slate-600 dark:text-slate-300'
              }`}
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      {/* Batch Discard Action Bar */}
      {selectMode && (
        <div className="rounded-2xl border border-rose-500/30 bg-rose-500/10 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="text-sm text-slate-800 dark:text-slate-100">
            <strong>Mode défausse groupée :</strong>{' '}
            <span className="font-mono-num">{totalBatchDiscard}</span> carte(s) sélectionnée(s) →{' '}
            <strong className="font-mono-num text-[#c8952d] dark:text-[#e2bb6b]">
              +{totalBatchDiscard} ●
            </strong>
          </div>
          <button
            type="button"
            disabled={totalBatchDiscard === 0}
            onClick={() => setConfirmBatchOpen(true)}
            className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 disabled:opacity-40 text-white text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Défausser la sélection</span>
          </button>
        </div>
      )}

      {/* Responsive 2 to 5 Column Grid */}
      {filteredCards.length === 0 ? (
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-12 text-center text-sm text-slate-500 dark:text-slate-400">
          Aucune carte ne correspond à vos filtres.
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 sm:gap-4">
          {filteredCards.map((card) => {
            const owned = player.inventory[card.id] || 0;
            const locked = owned === 0 && !player.discoveredCards.includes(card.id);
            const selectedQty = discardSelection[card.id] || 0;

            return (
              <div key={card.id} className="space-y-2">
                <CardVisual
                  cardId={card.id}
                  count={owned}
                  locked={locked}
                  selected={selectedQty > 0}
                  onClick={() => {
                    if (selectMode) {
                      toggleCardSelection(card.id);
                    } else if (!locked) {
                      setInspectCard(card.id);
                    }
                  }}
                />
                {selectMode && owned > 0 && (
                  <div className="flex items-center justify-between px-2 py-1 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f]">
                    <button
                      type="button"
                      onClick={() => adjustSelectionQty(card.id, -1)}
                      className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-white/10 cursor-pointer"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="font-mono-num text-xs font-bold">
                      {selectedQty} / {owned}
                    </span>
                    <button
                      type="button"
                      onClick={() => adjustSelectionQty(card.id, 1)}
                      className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-white/10 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Batch Discard Summary Modal */}
      {confirmBatchOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm"
          onClick={() => setConfirmBatchOpen(false)}
        >
          <div
            className="w-full max-w-md rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-6 shadow-2xl space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-display font-bold text-slate-900 dark:text-white">
                Confirmer la défausse groupée
              </h2>
              <button
                type="button"
                onClick={() => setConfirmBatchOpen(false)}
                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-white/5 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="max-h-60 overflow-y-auto space-y-2">
              {selectedEntries.map(([cid, qty]) => (
                <div
                  key={cid}
                  className="flex items-center justify-between px-3 py-2 rounded-xl bg-slate-50 dark:bg-[#22262c] text-sm"
                >
                  <span className="font-medium text-slate-900 dark:text-white">
                    {CARD_BY_ID[cid].name}
                  </span>
                  <span className="font-mono-num font-bold text-slate-600 dark:text-slate-300">
                    ×{qty} (+{qty} ●)
                  </span>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-200 dark:border-white/10 text-sm">
              <span className="text-slate-600 dark:text-slate-300">Gain total</span>
              <span className="font-mono-num font-bold text-lg text-[#c8952d] dark:text-[#e2bb6b]">
                +{totalBatchDiscard} ●
              </span>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setConfirmBatchOpen(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-white/10 text-sm font-semibold text-slate-700 dark:text-slate-200 cursor-pointer"
              >
                Annuler
              </button>
              <button
                type="button"
                disabled={batchBusy}
                onClick={handleConfirmBatch}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white text-sm font-semibold cursor-pointer"
              >
                {batchBusy ? 'Défausse…' : 'Confirmer'}
              </button>
            </div>
          </div>
        </div>
      )}

      <CardInspectModal
        cardId={inspectCard}
        ownedCount={inspectCard ? player.inventory[inspectCard] || 0 : 0}
        onClose={() => setInspectCard(null)}
        onDiscardOne={async (cid) => {
          await onDiscardOne(cid);
          setInspectCard(null);
        }}
      />
    </div>
  );
}
