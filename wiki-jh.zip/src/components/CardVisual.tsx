import React, { useState, useRef } from 'react';
import { HelpCircle, Sparkles, Swords, Shield, Zap, X, Trash2 } from 'lucide-react';
import type { CardDef, CardId } from '../types/game';
import { CARD_BY_ID, RARITY_META } from '../data/cards';

interface CardImageProps {
  src: string;
  alt: string;
  className?: string;
  locked?: boolean;
}

export function CardImage({ src, alt, className = '', locked = false }: CardImageProps) {
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-slate-800 via-slate-900 to-slate-950 text-slate-400 ${className}`}
      >
        <span className="text-2xl font-display text-[#e2bb6b]">◆</span>
        <span className="text-[11px] mt-1 px-2 text-center truncate max-w-full">{alt}</span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={`${className} ${locked ? 'grayscale contrast-75 brightness-50' : ''}`}
      loading="lazy"
    />
  );
}

export function CardBack({ className = '' }: { className?: string }) {
  return (
    <div
      className={`relative w-full h-full rounded-2xl overflow-hidden border-2 border-[#c8952d] bg-gradient-to-br from-[#0e1930] via-[#142547] to-[#0a1120] flex flex-col items-center justify-center p-4 shadow-xl select-none ${className}`}
    >
      <div className="absolute inset-2 rounded-xl border border-[#e2bb6b]/35 pointer-events-none" />
      <div className="absolute inset-4 rounded-lg border border-[#e2bb6b]/15 pointer-events-none" />
      <div className="w-12 h-12 rounded-full border-2 border-[#e2bb6b]/70 bg-[#1a2e56]/80 flex items-center justify-center shadow-inner mb-2">
        <span className="text-xl text-[#e2bb6b]">◆</span>
      </div>
      <span className="font-display text-base font-bold text-[#e2bb6b] tracking-wide">
        Wiki JH
      </span>
      <span className="text-[10px] text-amber-200/60 mt-1 tracking-widest uppercase">
        Jules Haag
      </span>
    </div>
  );
}

interface CardVisualProps {
  cardId: CardId;
  count?: number;
  isNew?: boolean;
  locked?: boolean;
  showStats?: boolean;
  selected?: boolean;
  compact?: boolean;
  onClick?: () => void;
  className?: string;
}

export function CardVisual({
  cardId,
  count,
  isNew = false,
  locked = false,
  showStats = true,
  selected = false,
  compact = false,
  onClick,
  className = '',
}: CardVisualProps) {
  const card: CardDef = CARD_BY_ID[cardId];
  const meta = RARITY_META[card.rarity];
  const hasSheen = !locked && (card.rarity === 'SR' || card.rarity === 'UR' || card.rarity === 'L');
  const isExotic = !locked && card.rarity === 'EX';

  const campusColor =
    card.campus === 'Labbé'
      ? 'text-blue-600 dark:text-blue-400'
      : card.campus === 'Marceau'
      ? 'text-emerald-600 dark:text-emerald-400'
      : 'text-amber-600 dark:text-[#e2bb6b]';

  return (
    <div
      onClick={onClick}
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={
        onClick
          ? (e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onClick();
              }
            }
          : undefined
      }
      className={`group relative rounded-2xl border-2 transition-all duration-200 overflow-hidden select-none ${
        locked
          ? 'bg-slate-200/70 dark:bg-[#1a1d22] border-slate-300 dark:border-white/10'
          : `${meta.cardBgClass} ${meta.borderClass}`
      } ${isExotic ? 'animate-exotic-pulse' : ''} ${
        selected ? 'ring-2 ring-emerald-500 ring-offset-2 ring-offset-[#111315] scale-[0.98]' : ''
      } ${onClick ? 'cursor-pointer hover:-translate-y-1 hover:shadow-lg' : ''} ${className}`}
    >
      {/* Sheen effect for SR, UR, L */}
      {hasSheen && (
        <div className="pointer-events-none absolute inset-0 z-10 overflow-hidden">
          <div className="animate-card-sheen absolute inset-y-0 w-1/2 bg-gradient-to-r from-transparent via-white/30 to-transparent" />
        </div>
      )}

      {/* Twinkling stars for EX */}
      {isExotic && (
        <div className="pointer-events-none absolute inset-0 z-10 overflow-hidden">
          <span
            className="animate-twinkle absolute top-4 left-6 text-cyan-200 text-xs"
            style={{ animationDelay: '0s' }}
          >
            ✦
          </span>
          <span
            className="animate-twinkle absolute top-10 right-6 text-teal-200 text-[10px]"
            style={{ animationDelay: '0.6s' }}
          >
            ✦
          </span>
          <span
            className="animate-twinkle absolute bottom-16 left-10 text-cyan-300 text-[11px]"
            style={{ animationDelay: '1.1s' }}
          >
            ✦
          </span>
        </div>
      )}

      {/* Top Artwork */}
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-slate-900">
        <CardImage
          src={card.image}
          alt={locked ? 'Carte non découverte' : card.name}
          locked={locked}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-black/25 pointer-events-none" />

        {/* Top-left rarity badge */}
        <span
          className={`absolute top-2 left-2 z-20 px-2 py-0.5 rounded-md text-[11px] font-mono-num font-bold border shadow-sm ${
            locked
              ? 'bg-slate-700/90 text-slate-300 border-slate-500/40'
              : meta.badgeClass
          }`}
        >
          {card.rarity}
        </span>

        {/* Top-right Nouvelle or ×N */}
        {!locked && isNew && (
          <span className="absolute top-2 right-2 z-20 px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-500 text-slate-950 shadow-sm">
            Nouvelle
          </span>
        )}
        {!locked && !isNew && typeof count === 'number' && count > 0 && (
          <span className="absolute top-2 right-2 z-20 px-2 py-0.5 rounded-md text-[11px] font-mono-num font-bold bg-black/75 text-white border border-white/15 backdrop-blur-sm">
            ×{count}
          </span>
        )}

        {/* Locked Question Mark */}
        {locked && (
          <div className="absolute inset-0 z-20 flex items-center justify-center">
            <div className="w-11 h-11 rounded-full bg-slate-900/80 border border-white/15 flex items-center justify-center text-slate-300">
              <HelpCircle className="w-6 h-6" />
            </div>
          </div>
        )}
      </div>

      {/* Card Body */}
      <div className={compact ? 'p-2.5 space-y-1.5' : 'p-3 space-y-2'}>
        <div>
          <h3
            className={`font-display font-bold truncate leading-snug ${
              compact ? 'text-xs' : 'text-sm'
            } ${locked ? 'text-slate-500 dark:text-slate-400' : 'text-slate-900 dark:text-slate-100'}`}
          >
            {locked ? `Carte #${card.number.toString().padStart(2, '0')}` : card.name}
          </h3>
          <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 truncate">
            <span>{meta.shortLabel}</span>
            <span aria-hidden="true">·</span>
            <span className={`font-medium truncate ${locked ? '' : campusColor}`}>
              {card.campus}
            </span>
          </div>
        </div>

        {showStats && (
          <div
            className={`grid grid-cols-3 gap-1 pt-1.5 border-t border-black/10 dark:border-white/10 font-mono-num ${
              compact ? 'text-[10px]' : 'text-[11px]'
            } ${locked ? 'opacity-40' : ''}`}
          >
            <div className="flex items-center justify-between px-1.5 py-0.5 rounded bg-black/5 dark:bg-white/5">
              <span className="text-slate-500 dark:text-slate-400">ATQ</span>
              <span className="font-bold text-slate-800 dark:text-slate-100">
                {locked ? '?' : card.atk}
              </span>
            </div>
            <div className="flex items-center justify-between px-1.5 py-0.5 rounded bg-black/5 dark:bg-white/5">
              <span className="text-slate-500 dark:text-slate-400">DEF</span>
              <span className="font-bold text-slate-800 dark:text-slate-100">
                {locked ? '?' : card.def}
              </span>
            </div>
            <div className="flex items-center justify-between px-1.5 py-0.5 rounded bg-black/5 dark:bg-white/5">
              <span className="text-slate-500 dark:text-slate-400">VIT</span>
              <span className="font-bold text-slate-800 dark:text-slate-100">
                {locked ? '?' : card.vit}
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

interface CardInspectModalProps {
  cardId: CardId | null;
  ownedCount?: number;
  onClose: () => void;
  onDiscardOne?: (cardId: CardId) => void;
  discardLoading?: boolean;
}

export function CardInspectModal({
  cardId,
  ownedCount = 0,
  onClose,
  onDiscardOne,
  discardLoading = false,
}: CardInspectModalProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState({ rx: 0, ry: 0, gx: 50, gy: 50 });

  if (!cardId) return null;
  const card = CARD_BY_ID[cardId];
  const meta = RARITY_META[card.rarity];

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const el = cardRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width;
    const py = (e.clientY - rect.top) / rect.height;
    const ry = (px - 0.5) * 22;
    const rx = (0.5 - py) * 22;
    setTilt({ rx, ry, gx: px * 100, gy: py * 100 });
  };

  const handlePointerLeave = () => {
    setTilt({ rx: 0, ry: 0, gx: 50, gy: 50 });
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-2xl rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 md:p-6 shadow-2xl grid grid-cols-1 md:grid-cols-2 gap-6 items-center"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={onClose}
          aria-label="Fermer l’inspection"
          className="absolute top-3.5 right-3.5 p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/5 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Interactive 3D Tilt Card */}
        <div
          ref={cardRef}
          onPointerMove={handlePointerMove}
          onPointerLeave={handlePointerLeave}
          className="perspective-1000 flex justify-center py-2 touch-none"
        >
          <div
            style={{
              transform: `rotateX(${tilt.rx}deg) rotateY(${tilt.ry}deg)`,
              transition: tilt.rx === 0 && tilt.ry === 0 ? 'transform 300ms ease-out' : 'none',
            }}
            className="relative w-full max-w-[260px] rounded-2xl shadow-2xl"
          >
            <CardVisual cardId={cardId} count={ownedCount > 0 ? ownedCount : undefined} />
            {/* Dynamic Holographic Glare */}
            <div
              className="pointer-events-none absolute inset-0 rounded-2xl mix-blend-overlay opacity-70"
              style={{
                background: `radial-gradient(circle at ${tilt.gx}% ${tilt.gy}%, rgba(255,255,255,0.65), rgba(255,255,255,0.12) 40%, transparent 75%)`,
              }}
            />
          </div>
        </div>

        {/* Lore & Actions */}
        <div className="space-y-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
              <span>Carte #{card.number.toString().padStart(2, '0')}/15</span>
              <span aria-hidden="true">·</span>
              <span className="font-semibold" style={{ color: meta.color }}>
                {meta.label} ({card.rarity})
              </span>
              <span aria-hidden="true">·</span>
              <span>{card.campus}</span>
            </div>
            <h2 className="text-2xl font-display font-bold text-slate-900 dark:text-white mt-1">
              {card.name}
            </h2>
          </div>

          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            {card.lore}
          </p>

          <div className="grid grid-cols-3 gap-2.5">
            <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] p-2.5 text-center">
              <div className="flex items-center justify-center gap-1 text-[11px] text-slate-500 dark:text-slate-400">
                <Swords className="w-3.5 h-3.5 text-rose-500" />
                <span>ATQ</span>
              </div>
              <div className="font-mono-num font-bold text-lg text-slate-900 dark:text-white mt-0.5">
                {card.atk}
              </div>
            </div>
            <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] p-2.5 text-center">
              <div className="flex items-center justify-center gap-1 text-[11px] text-slate-500 dark:text-slate-400">
                <Shield className="w-3.5 h-3.5 text-blue-500" />
                <span>DEF</span>
              </div>
              <div className="font-mono-num font-bold text-lg text-slate-900 dark:text-white mt-0.5">
                {card.def}
              </div>
            </div>
            <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] p-2.5 text-center">
              <div className="flex items-center justify-center gap-1 text-[11px] text-slate-500 dark:text-slate-400">
                <Zap className="w-3.5 h-3.5 text-amber-500" />
                <span>VIT</span>
              </div>
              <div className="font-mono-num font-bold text-lg text-slate-900 dark:text-white mt-0.5">
                {card.vit}
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pt-1">
            <span>Valeur conseillée au marché</span>
            <span className="font-mono-num font-semibold text-slate-900 dark:text-slate-100">
              {card.suggestedPrice} ●
            </span>
          </div>

          {onDiscardOne && ownedCount > 0 && (
            <div className="pt-2 border-t border-slate-200 dark:border-white/10 flex items-center justify-between gap-3">
              <span className="text-xs text-slate-500 dark:text-slate-400">
                Exemplaires possédés :{' '}
                <strong className="font-mono-num text-slate-900 dark:text-white">
                  {ownedCount}
                </strong>
              </span>
              <button
                type="button"
                disabled={discardLoading}
                onClick={() => onDiscardOne(cardId)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold border border-rose-500/30 bg-rose-500/10 text-rose-600 dark:text-rose-400 hover:bg-rose-500/20 disabled:opacity-50 transition-colors cursor-pointer whitespace-nowrap"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Défausser (+1 ●)</span>
              </button>
            </div>
          )}

          {card.rarity === 'EX' && (
            <div className="flex items-center gap-2 text-xs text-cyan-600 dark:text-cyan-400">
              <Sparkles className="w-4 h-4 shrink-0" />
              <span>Carte Exotique rarissime (1 % de chance par tirage).</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
