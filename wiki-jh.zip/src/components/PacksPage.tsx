import React, { useState, useEffect, useRef } from 'react';
import { HelpCircle, Scissors, ShoppingBag, Sparkles, X, ArrowRight, Eye } from 'lucide-react';
import type { CardId, PlayerProfile } from '../types/game';
import { CARD_BY_ID, RARITY_META, RARITY_ORDER, getBestRarityInPull } from '../data/cards';
import { soundFx } from '../utils/sound';
import { CardBack, CardImage, CardInspectModal, CardVisual } from './CardVisual';

const REGEN_INTERVAL_MS = 10 * 60 * 1000; // 10 minutes
const MAX_FREE_REGEN_PACKS = 10;
const BOOSTER_PRICE = 120;

interface PacksPageProps {
  player: PlayerProfile;
  onOpenPack: () => Promise<{ pull: CardId[]; newlyDiscovered: CardId[] }>;
  onBuyPack: () => Promise<void>;
  onDiscardOne: (cardId: CardId) => Promise<void>;
}

type OpeningStep = 'idle' | 'tear' | 'burst' | 'reveal' | 'summary';

export function PacksPage({
  player,
  onOpenPack,
  onBuyPack,
  onDiscardOne,
}: PacksPageProps) {
  const [packTilt, setPackTilt] = useState({ rx: 0, ry: 0 });
  const [nowMs, setNowMs] = useState(Date.now());
  const [howItWorksOpen, setHowItWorksOpen] = useState(false);
  const [buying, setBuying] = useState(false);
  const [openingStep, setOpeningStep] = useState<OpeningStep>('idle');
  const [pulledCards, setPulledCards] = useState<CardId[]>([]);
  const [newCards, setNewCards] = useState<CardId[]>([]);
  const [revealedFlags, setRevealedFlags] = useState<boolean[]>([false, false, false, false, false]);
  const [activeIndex, setActiveIndex] = useState(0);
  const [tearProgress, setTearProgress] = useState(0);
  const [isDraggingTear, setIsDraggingTear] = useState(false);
  const [inspectCard, setInspectCard] = useState<CardId | null>(null);
  const [openingBusy, setOpeningBusy] = useState(false);
  const tearTrackRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const id = setInterval(() => setNowMs(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  const lastRegenMs = player.lastPackRegenAt?.toMillis?.() || nowMs;
  const elapsed = Math.max(0, nowMs - lastRegenMs);
  const isAtRegenCap = player.packs >= MAX_FREE_REGEN_PACKS;
  const msRemaining = isAtRegenCap
    ? 0
    : Math.max(0, REGEN_INTERVAL_MS - (elapsed % REGEN_INTERVAL_MS));
  const regenPct = isAtRegenCap
    ? 100
    : Math.min(100, Math.round(((REGEN_INTERVAL_MS - msRemaining) / REGEN_INTERVAL_MS) * 100));

  const formatCountdown = (ms: number) => {
    const totalSec = Math.ceil(ms / 1000);
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const handlePackMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width;
    const py = (e.clientY - rect.top) / rect.height;
    setPackTilt({ rx: (0.5 - py) * 18, ry: (px - 0.5) * 18 });
  };

  const startOpening = async () => {
    if (player.packs <= 0 || openingBusy) return;
    setOpeningBusy(true);
    try {
      const { pull, newlyDiscovered } = await onOpenPack();
      setPulledCards(pull);
      setNewCards(newlyDiscovered);
      setRevealedFlags([false, false, false, false, false]);
      setActiveIndex(0);
      setTearProgress(0);
      setOpeningStep('tear');
    } finally {
      setOpeningBusy(false);
    }
  };

  const completeTear = () => {
    if (openingStep !== 'tear') return;
    soundFx.playPackTear();
    setTearProgress(100);
    setOpeningStep('burst');
    setTimeout(() => {
      setOpeningStep('reveal');
    }, 750);
  };

  const handleTearPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDraggingTear || openingStep !== 'tear') return;
    const el = tearTrackRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const pct = Math.max(0, Math.min(100, ((e.clientX - rect.left) / rect.width) * 100));
    setTearProgress(pct);
    if (pct >= 82) {
      setIsDraggingTear(false);
      completeTear();
    }
  };

  const revealSingleCard = (index: number) => {
    if (revealedFlags[index]) {
      // Advance to next unrevealed or summary
      const next = revealedFlags.findIndex((v, i) => i > index && !v);
      if (next !== -1) {
        setActiveIndex(next);
      } else if (revealedFlags.every(Boolean)) {
        setOpeningStep('summary');
      }
      return;
    }
    const cardId = pulledCards[index];
    const rarity = CARD_BY_ID[cardId].rarity;
    if (rarity === 'EX' || rarity === 'L') {
      soundFx.playExoticReveal();
    } else if (rarity === 'UR' || rarity === 'SR' || rarity === 'R') {
      soundFx.playRareReveal();
    } else {
      soundFx.playCardFlip();
    }

    const updated = [...revealedFlags];
    updated[index] = true;
    setRevealedFlags(updated);
  };

  const revealAllCards = () => {
    const best = getBestRarityInPull(pulledCards);
    if (best === 'EX' || best === 'L') {
      soundFx.playExoticReveal();
    } else {
      soundFx.playRareReveal();
    }
    setRevealedFlags([true, true, true, true, true]);
    setOpeningStep('summary');
  };

  const bestPullRarity = pulledCards.length > 0 ? getBestRarityInPull(pulledCards) : 'C';
  const bestPullMeta = RARITY_META[bestPullRarity];

  const handleBuy = async () => {
    if (buying || player.coins < BOOSTER_PRICE) return;
    setBuying(true);
    try {
      await onBuyPack();
    } finally {
      setBuying(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-8">
      {/* Main Hero Booster Stage */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-center">
        {/* Left: Interactive 3D Booster */}
        <div className="lg:col-span-6 flex flex-col items-center justify-center py-6">
          <div
            onMouseMove={handlePackMouseMove}
            onMouseLeave={() => setPackTilt({ rx: 0, ry: 0 })}
            onClick={player.packs > 0 ? startOpening : undefined}
            role={player.packs > 0 ? 'button' : undefined}
            tabIndex={player.packs > 0 ? 0 : undefined}
            onKeyDown={(e) => {
              if ((e.key === 'Enter' || e.key === ' ') && player.packs > 0) {
                e.preventDefault();
                startOpening();
              }
            }}
            className={`relative perspective-1000 select-none ${
              player.packs > 0 ? 'cursor-pointer' : 'opacity-65 cursor-not-allowed'
            }`}
          >
            {/* Visual Stack Behind when packs > 1 */}
            {player.packs > 2 && (
              <div
                aria-hidden="true"
                className="absolute inset-0 translate-x-4 translate-y-3 rotate-3 rounded-2xl bg-[#0b1324] border border-[#c8952d]/40 shadow-xl"
              />
            )}
            {player.packs > 1 && (
              <div
                aria-hidden="true"
                className="absolute inset-0 translate-x-2 translate-y-1.5 -rotate-2 rounded-2xl bg-[#101c34] border border-[#c8952d]/60 shadow-xl"
              />
            )}

            {/* Main 3D Booster Pouch */}
            <div
              style={{
                transform: `rotateX(${packTilt.rx}deg) rotateY(${packTilt.ry}deg)`,
                transition:
                  packTilt.rx === 0 && packTilt.ry === 0 ? 'transform 320ms ease-out' : 'none',
              }}
              className="animate-float-slow relative w-64 sm:w-72 h-[400px] sm:h-[430px] rounded-2xl overflow-hidden bg-gradient-to-b from-[#132240] via-[#0e1a33] to-[#0a1224] border-2 border-[#c8952d] shadow-[0_24px_60px_rgba(0,0,0,0.45)] flex flex-col justify-between"
            >
              {/* Top Notched Gold Crimp */}
              <div
                className="h-6 w-full bg-gradient-to-r from-[#b8821f] via-[#e2bb6b] to-[#b8821f] border-b border-amber-200/40 flex items-center justify-around px-2"
                style={{
                  backgroundImage:
                    'repeating-linear-gradient(90deg, rgba(0,0,0,0.2) 0px, rgba(0,0,0,0.2) 3px, transparent 3px, transparent 8px), linear-gradient(90deg, #b8821f, #e2bb6b, #b8821f)',
                }}
              />

              {/* Pouch Content */}
              <div className="flex-1 px-5 py-4 flex flex-col items-center justify-between text-center relative">
                {/* Campus Vignettes */}
                <div className="grid grid-cols-2 gap-2.5 w-full">
                  <div className="relative rounded-xl overflow-hidden border border-blue-400/50 aspect-[4/3]">
                    <CardImage
                      src={CARD_BY_ID.site_labbe.image}
                      alt="Vignette Site Labbé"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-x-0 bottom-0 bg-blue-950/80 text-[10px] font-semibold text-blue-200 py-0.5">
                      Labbé
                    </div>
                  </div>
                  <div className="relative rounded-xl overflow-hidden border border-emerald-400/50 aspect-[4/3]">
                    <CardImage
                      src={CARD_BY_ID.site_marceau.image}
                      alt="Vignette Site Marceau"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-x-0 bottom-0 bg-emerald-950/80 text-[10px] font-semibold text-emerald-200 py-0.5">
                      Marceau
                    </div>
                  </div>
                </div>

                {/* Central Crest */}
                <div className="space-y-2 my-auto py-3">
                  <div className="w-16 h-16 mx-auto rounded-2xl border-2 border-[#e2bb6b]/80 bg-[#172a4f] flex items-center justify-center shadow-lg">
                    <span className="text-3xl text-[#e2bb6b]">◆</span>
                  </div>
                  <div className="font-display text-2xl font-bold text-white tracking-tight">
                    Wiki JH
                  </div>
                  <div className="text-xs text-[#e2bb6b] font-semibold tracking-wider uppercase">
                    Booster · 5 cartes
                  </div>
                </div>

                <div className="text-[11px] text-slate-300/80">
                  {player.packs > 0
                    ? 'Cliquez pour ouvrir ce paquet'
                    : 'En attente de régénération'}
                </div>
              </div>

              {/* Bottom Notched Gold Crimp */}
              <div
                className="h-6 w-full border-t border-amber-200/40"
                style={{
                  backgroundImage:
                    'repeating-linear-gradient(90deg, rgba(0,0,0,0.2) 0px, rgba(0,0,0,0.2) 3px, transparent 3px, transparent 8px), linear-gradient(90deg, #b8821f, #e2bb6b, #b8821f)',
                }}
              />
            </div>
          </div>

          <div className="mt-5 flex items-center gap-3">
            <button
              type="button"
              disabled={player.packs <= 0 || openingBusy}
              onClick={startOpening}
              className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-45 text-white font-semibold text-sm shadow-lg shadow-emerald-900/20 transition-colors cursor-pointer whitespace-nowrap"
            >
              {openingBusy
                ? 'Préparation…'
                : player.packs > 0
                ? `Ouvrir 1 paquet (${player.packs} restant${player.packs > 1 ? 's' : ''})`
                : 'Aucun paquet disponible'}
            </button>
          </div>
        </div>

        {/* Right: Regen Status, Buy Booster & Help */}
        <div className="lg:col-span-6 space-y-4">
          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 sm:p-6 space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h1 className="text-2xl sm:text-3xl font-display font-bold text-slate-900 dark:text-white">
                  Boosters Wiki JH
                </h1>
                <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
                  Collectionnez les 15 lieux et emblèmes du Lycée Jules Haag.
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  soundFx.playClick();
                  setHowItWorksOpen(true);
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/10 transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Comment ça marche ?</span>
              </button>
            </div>

            {/* Reserve & Countdown */}
            <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] p-4 space-y-2.5">
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium text-slate-700 dark:text-slate-200">
                  Réserve de paquets
                </span>
                <span className="font-mono-num font-bold text-slate-900 dark:text-white">
                  {player.packs} / {MAX_FREE_REGEN_PACKS} (gratuit)
                </span>
              </div>

              <div className="h-2.5 rounded-full bg-slate-200 dark:bg-black/40 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-500"
                  style={{ width: `${regenPct}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                <span>+1 paquet gratuit toutes les 10 minutes</span>
                <span className="font-mono-num font-semibold text-emerald-600 dark:text-emerald-400">
                  {isAtRegenCap ? 'Réserve pleine' : `Prochain dans ${formatCountdown(msRemaining)}`}
                </span>
              </div>
            </div>

            {/* Buy Additional Booster */}
            <div className="rounded-xl border border-[#c8952d]/35 bg-[#c8952d]/10 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="text-sm font-semibold text-slate-900 dark:text-white">
                  Acheter un booster supplémentaire
                </div>
                <div className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
                  1 paquet de 5 cartes (dont au moins 1 carte Rare ou supérieure)
                </div>
              </div>
              <button
                type="button"
                disabled={buying || player.coins < BOOSTER_PRICE}
                onClick={handleBuy}
                className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#c8952d] hover:bg-[#b58422] disabled:opacity-45 text-slate-950 font-bold text-xs font-mono-num transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>{buying ? 'Achat…' : `Acheter · ${BOOSTER_PRICE} ●`}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Confirmation Banner: Last 5 Saved Cards */}
      {player.lastPackPull && player.lastPackPull.length > 0 && (
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-display font-bold text-slate-900 dark:text-white">
              Dernier tirage sauvegardé (5 cartes)
            </h2>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Cliquez sur une carte pour l’inspecter en 3D
            </span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
            {player.lastPackPull.map((cid, idx) => (
              <CardVisual
                key={`${cid}-${idx}`}
                cardId={cid}
                compact
                showStats={false}
                onClick={() => setInspectCard(cid)}
              />
            ))}
          </div>
        </div>
      )}

      {/* How It Works Modal */}
      {howItWorksOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm"
          onClick={() => setHowItWorksOpen(false)}
        >
          <div
            className="w-full max-w-lg rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-6 shadow-2xl space-y-4 max-h-[85vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-display font-bold text-slate-900 dark:text-white">
                Comment fonctionne Wiki JH ?
              </h2>
              <button
                type="button"
                onClick={() => setHowItWorksOpen(false)}
                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-white/5 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-sm text-slate-600 dark:text-slate-300">
              <p>
                <strong className="text-slate-900 dark:text-white">Boosters :</strong>{' '}
                Vous démarrez avec 10 paquets et régénérez +1 paquet gratuit toutes les 10 minutes (jusqu’à 10 en réserve). Chaque booster contient 5 cartes, dont au moins une Rare ou mieux.
              </p>
              <p>
                <strong className="text-slate-900 dark:text-white">Collection & Défausse :</strong>{' '}
                Retrouvez les 15 cartes des sites Labbé, Marceau et Jules Haag. Vous pouvez défausser vos doublons pour +1 ● chacun.
              </p>
              <p>
                <strong className="text-slate-900 dark:text-white">Échanges & Marché :</strong>{' '}
                Échangez directement 1 à 5 cartes avec vos amis, ou mettez vos cartes aux enchères à l’hôtel des ventes en temps réel.
              </p>
              <p>
                <strong className="text-slate-900 dark:text-white">Batailles & Coupe Inter-Sites :</strong>{' '}
                Affrontez les joueurs en duels tactiques (Assaut / Défense / Contre) pour gagner des pièces ●, monter en ELO et faire triompher votre site !
              </p>
              <div className="pt-2 border-t border-slate-200 dark:border-white/10">
                <div className="text-xs font-semibold text-slate-900 dark:text-white mb-2">
                  Les 7 niveaux de rareté
                </div>
                <div className="grid grid-cols-2 gap-1.5 text-xs">
                  {RARITY_ORDER.map((r) => (
                    <div
                      key={r}
                      className="flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-slate-100 dark:bg-[#22262c]"
                    >
                      <span className="font-semibold" style={{ color: RARITY_META[r].color }}>
                        {r} · {RARITY_META[r].label}
                      </span>
                      <span className="font-mono-num text-slate-500 dark:text-slate-400">
                        {RARITY_META[r].dropWeight}%
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Fullscreen 4-Step Pack Opening Animation */}
      {openingStep !== 'idle' && (
        <div className="fixed inset-0 z-50 bg-[#0b0e13]/95 backdrop-blur-md flex flex-col items-center justify-center p-4 sm:p-6 overflow-y-auto">
          {/* Step 1: Interactive Tear */}
          {openingStep === 'tear' && (
            <div className="w-full max-w-md flex flex-col items-center space-y-6 text-center">
              <div className="space-y-1">
                <h2 className="text-2xl font-display font-bold text-white">
                  Déchirez le booster
                </h2>
                <p className="text-xs text-slate-400">
                  Glissez le curseur ou le doigt le long de la ligne pointillée
                </p>
              </div>

              <div className="relative w-64 h-[380px] rounded-2xl bg-gradient-to-b from-[#132240] to-[#0a1224] border-2 border-[#c8952d] shadow-2xl overflow-hidden flex flex-col justify-between">
                {/* Top Tear Strip */}
                <div
                  className="h-20 bg-gradient-to-b from-[#e2bb6b]/25 to-transparent flex flex-col justify-end pb-2 transition-transform duration-200"
                  style={{
                    transform: `translateY(${-tearProgress * 0.25}px) rotate(${
                      -tearProgress * 0.06
                    }deg)`,
                  }}
                >
                  <div
                    ref={tearTrackRef}
                    onPointerDown={(e) => {
                      setIsDraggingTear(true);
                      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
                    }}
                    onPointerMove={handleTearPointerMove}
                    onPointerUp={() => setIsDraggingTear(false)}
                    className="relative mx-2 h-10 flex items-center cursor-ew-resize touch-none"
                  >
                    <div className="w-full border-t-2 border-dashed border-[#e2bb6b]" />
                    <div
                      className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-9 h-9 rounded-full bg-[#e2bb6b] text-slate-950 flex items-center justify-center shadow-lg transition-transform"
                      style={{ left: `${Math.max(10, Math.min(90, tearProgress || 12))}%` }}
                    >
                      <Scissors className="w-4 h-4" />
                    </div>
                  </div>
                </div>

                <div className="flex-1 flex flex-col items-center justify-center px-6">
                  <span className="text-4xl text-[#e2bb6b]">◆</span>
                  <div className="font-display text-2xl font-bold text-white mt-2">Wiki JH</div>
                  <div className="text-xs text-amber-200/75 mt-1">5 cartes à révéler</div>
                </div>

                <div className="h-6 bg-gradient-to-r from-[#b8821f] via-[#e2bb6b] to-[#b8821f]" />
              </div>

              <button
                type="button"
                onClick={completeTear}
                className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm transition-colors cursor-pointer"
              >
                Déchirer le paquet
              </button>
            </div>
          )}

          {/* Step 2: Color Light Burst */}
          {openingStep === 'burst' && (
            <div className="relative flex items-center justify-center w-64 h-64">
              <div
                className="animate-burst w-40 h-40 rounded-full blur-xl"
                style={{ backgroundColor: bestPullMeta.color }}
              />
              <div className="relative z-10 text-center space-y-2">
                <Sparkles className="w-12 h-12 mx-auto text-white animate-pulse" />
                <div className="font-display text-xl font-bold text-white">
                  Tirage {bestPullMeta.label} !
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Card-by-Card 3D Reveal */}
          {openingStep === 'reveal' && (
            <div className="w-full max-w-md flex flex-col items-center space-y-5">
              <div className="flex items-center justify-between w-full">
                <span className="text-xs font-mono-num text-slate-300">
                  Carte {activeIndex + 1} / 5
                </span>
                <button
                  type="button"
                  onClick={revealAllCards}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold transition-colors cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Tout révéler</span>
                </button>
              </div>

              {/* Progress Dots */}
              <div className="flex items-center gap-2">
                {pulledCards.map((cid, idx) => {
                  const rev = revealedFlags[idx];
                  const m = RARITY_META[CARD_BY_ID[cid].rarity];
                  return (
                    <button
                      key={`${cid}-dot-${idx}`}
                      type="button"
                      onClick={() => setActiveIndex(idx)}
                      className={`h-2.5 rounded-full transition-all cursor-pointer ${
                        idx === activeIndex ? 'w-7' : 'w-2.5'
                      }`}
                      style={{
                        backgroundColor: rev ? m.color : 'rgba(255,255,255,0.25)',
                      }}
                    />
                  );
                })}
              </div>

              {/* Interactive Flip Card */}
              <div
                onClick={() => revealSingleCard(activeIndex)}
                className="perspective-1000 w-64 h-[360px] cursor-pointer"
              >
                <div
                  className="relative w-full h-full preserve-3d transition-transform duration-500"
                  style={{
                    transform: revealedFlags[activeIndex] ? 'rotateY(180deg)' : 'rotateY(0deg)',
                  }}
                >
                  {/* Front (Face Down Back) */}
                  <div className="absolute inset-0 backface-hidden">
                    <CardBack />
                  </div>
                  {/* Back (Face Up Card) */}
                  <div
                    className="absolute inset-0 backface-hidden rounded-2xl"
                    style={{
                      transform: 'rotateY(180deg)',
                      boxShadow: `0 0 36px ${
                        RARITY_META[CARD_BY_ID[pulledCards[activeIndex]].rarity].glowColor
                      }`,
                    }}
                  >
                    <CardVisual
                      cardId={pulledCards[activeIndex]}
                      isNew={newCards.includes(pulledCards[activeIndex])}
                      className="h-full"
                    />
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => revealSingleCard(activeIndex)}
                  className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold transition-colors cursor-pointer"
                >
                  <span>
                    {revealedFlags[activeIndex]
                      ? activeIndex < 4
                        ? 'Carte suivante'
                        : 'Voir le récapitulatif'
                      : 'Retourner la carte'}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* Step 4: Summary of 5 Cards */}
          {openingStep === 'summary' && (
            <div className="w-full max-w-5xl space-y-6 text-center">
              <div>
                <h2 className="text-2xl sm:text-3xl font-display font-bold text-white">
                  Récapitulatif du tirage
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Les 5 cartes ont été ajoutées à votre collection. Cliquez pour inspecter.
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 sm:gap-4">
                {pulledCards.map((cid, idx) => (
                  <CardVisual
                    key={`summary-${cid}-${idx}`}
                    cardId={cid}
                    isNew={newCards.includes(cid)}
                    onClick={() => setInspectCard(cid)}
                  />
                ))}
              </div>

              <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                {player.packs > 0 && (
                  <button
                    type="button"
                    onClick={startOpening}
                    className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold transition-colors cursor-pointer"
                  >
                    Ouvrir le paquet suivant ({player.packs})
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setOpeningStep('idle')}
                  className="px-6 py-3 rounded-xl border border-white/15 bg-white/10 hover:bg-white/15 text-white text-sm font-semibold transition-colors cursor-pointer"
                >
                  Fermer
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      <CardInspectModal
        cardId={inspectCard}
        ownedCount={inspectCard ? player.inventory[inspectCard] || 0 : 0}
        onClose={() => setInspectCard(null)}
        onDiscardOne={async (cid) => {
          await onDiscardOne(cid);
          setInspectCard(null);
        }}
      />
    </div>
  );
}
