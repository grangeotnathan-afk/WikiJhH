import React, { useState, useRef, useEffect } from 'react';
import {
  Bell,
  ChevronDown,
  User,
  Users,
  Swords,
  Award,
  Trophy,
  ShieldAlert,
  Settings,
  Package,
  Layers,
  Repeat,
  Gavel,
  MoreHorizontal,
  X,
} from 'lucide-react';
import type { AppNotification, NavTab, ProfileSubTab } from '../types/game';
import { soundFx } from '../utils/sound';

interface NavbarProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onSelectProfileSubTab: (subTab: ProfileSubTab) => void;
  coins: number;
  pendingTradesCount: number;
  pendingFriendsCount: number;
  notifications: AppNotification[];
  isAdmin: boolean;
}

export function Navbar({
  activeTab,
  onSelectTab,
  onSelectProfileSubTab,
  coins,
  pendingTradesCount,
  pendingFriendsCount,
  notifications,
  isAdmin,
}: NavbarProps) {
  const [moreOpen, setMoreOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [currencyModalOpen, setCurrencyModalOpen] = useState(false);
  const moreRef = useRef<HTMLDivElement>(null);
  const mobileMoreRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      const target = e.target as Node;
      const inDesktopMore = moreRef.current?.contains(target) ?? false;
      const inMobileMore = mobileMoreRef.current?.contains(target) ?? false;
      if (!inDesktopMore && !inMobileMore) {
        setMoreOpen(false);
      }
      if (notifRef.current && !notifRef.current.contains(target)) {
        setNotifOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  const navigate = (tab: NavTab, profileSubTab?: ProfileSubTab) => {
    soundFx.playClick();
    if (profileSubTab) {
      onSelectProfileSubTab(profileSubTab);
    }
    onSelectTab(tab);
    setMoreOpen(false);
    setNotifOpen(false);
  };

  const moreItems: {
    key: string;
    tab: NavTab;
    profileSubTab?: ProfileSubTab;
    label: string;
    icon: React.ReactNode;
    badge?: number;
  }[] = [
    {
      key: 'profil',
      tab: 'profil',
      profileSubTab: 'personnalisation',
      label: 'Profil',
      icon: <User className="w-4 h-4" />,
    },
    {
      key: 'amis',
      tab: 'amis',
      label: 'Amis',
      icon: <Users className="w-4 h-4" />,
      badge: pendingFriendsCount,
    },
    {
      key: 'bataille',
      tab: 'bataille',
      label: 'Bataille',
      icon: <Swords className="w-4 h-4" />,
    },
    {
      key: 'succes',
      tab: 'profil',
      profileSubTab: 'succes',
      label: 'Succès',
      icon: <Award className="w-4 h-4" />,
    },
    {
      key: 'classement',
      tab: 'classement',
      label: 'Classement',
      icon: <Trophy className="w-4 h-4" />,
    },
    ...(isAdmin
      ? [
          {
            key: 'admin',
            tab: 'admin' as NavTab,
            label: 'Admin',
            icon: <ShieldAlert className="w-4 h-4 text-amber-500" />,
          },
        ]
      : []),
    {
      key: 'parametres',
      tab: 'profil',
      profileSubTab: 'parametres',
      label: 'Paramètres',
      icon: <Settings className="w-4 h-4" />,
    },
  ];

  const isMoreActive = ['profil', 'amis', 'bataille', 'classement', 'admin'].includes(activeTab);

  return (
    <>
      {/* Top Sticky Bar */}
      <header className="sticky top-0 z-40 border-b border-slate-200 dark:border-white/10 bg-white/90 dark:bg-[#111315]/90 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4 sm:gap-8">
          {/* Zone 1: Brand Wordmark */}
          <button
            type="button"
            onClick={() => navigate('paquets')}
            className="flex items-center gap-2 text-lg font-display font-bold text-slate-900 dark:text-white whitespace-nowrap shrink-0 cursor-pointer"
          >
            <span className="text-[#c8952d] dark:text-[#e2bb6b]">◆</span>
            <span>Wiki JH</span>
          </button>

          {/* Zone 2: Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
            {(
              [
                { id: 'paquets', label: 'Paquets' },
                { id: 'collection', label: 'Collection' },
                { id: 'echanges', label: 'Échanges', badge: pendingTradesCount },
                { id: 'marche', label: 'Marché' },
              ] as { id: NavTab; label: string; badge?: number }[]
            ).map((item) => {
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => navigate(item.id)}
                  className={`relative py-1 whitespace-nowrap shrink-0 transition-colors cursor-pointer flex items-center gap-1.5 ${
                    active
                      ? 'text-slate-900 dark:text-white font-semibold'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <span>{item.label}</span>
                  {item.badge && item.badge > 0 ? (
                    <span className="px-1.5 py-0.2 rounded-full text-[11px] font-mono-num font-bold bg-emerald-600 text-white">
                      {item.badge}
                    </span>
                  ) : null}
                  {active && (
                    <span className="absolute -bottom-[15px] left-0 right-0 h-0.5 bg-emerald-500 rounded-full" />
                  )}
                </button>
              );
            })}

            {/* Plus Dropdown */}
            <div className="relative" ref={moreRef}>
              <button
                type="button"
                onClick={() => setMoreOpen((v) => !v)}
                className={`relative py-1 whitespace-nowrap shrink-0 transition-colors cursor-pointer flex items-center gap-1 ${
                  isMoreActive
                    ? 'text-slate-900 dark:text-white font-semibold'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <span>Plus</span>
                <ChevronDown className={`w-3.5 h-3.5 transition-transform ${moreOpen ? 'rotate-180' : ''}`} />
                {isMoreActive && (
                  <span className="absolute -bottom-[15px] left-0 right-0 h-0.5 bg-emerald-500 rounded-full" />
                )}
              </button>

              {moreOpen && (
                <div className="absolute right-0 mt-3 w-52 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] shadow-xl py-1.5 z-50">
                  {moreItems.map((m) => (
                    <button
                      key={m.key}
                      type="button"
                      onClick={() => navigate(m.tab, m.profileSubTab)}
                      className="w-full px-4 py-2.5 text-left text-sm flex items-center justify-between text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/5 transition-colors cursor-pointer"
                    >
                      <span className="flex items-center gap-2.5">
                        {m.icon}
                        <span>{m.label}</span>
                      </span>
                      {m.badge && m.badge > 0 ? (
                        <span className="px-1.5 py-0.5 rounded-full text-[11px] font-mono-num font-bold bg-emerald-600 text-white">
                          {m.badge}
                        </span>
                      ) : null}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </nav>

          {/* Zone 3: Currency & Notifications */}
          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => {
                soundFx.playClick();
                setCurrencyModalOpen(true);
              }}
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl border border-[#c8952d]/40 bg-[#c8952d]/10 hover:bg-[#c8952d]/20 text-slate-900 dark:text-[#e2bb6b] text-xs font-mono-num font-bold transition-colors cursor-pointer whitespace-nowrap"
              title="Informations sur la monnaie virtuelle"
            >
              <span className="text-[#c8952d] dark:text-[#e2bb6b]">W</span>
              <span>{coins.toLocaleString('fr-FR')} ●</span>
            </button>

            <div className="relative" ref={notifRef}>
              <button
                type="button"
                aria-label="Notifications"
                onClick={() => {
                  soundFx.playClick();
                  setNotifOpen((v) => !v);
                }}
                className="relative p-2 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#181b1f] text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-[#22262c] transition-colors cursor-pointer"
              >
                <Bell className="w-4 h-4" />
                {notifications.length > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-emerald-500" />
                )}
              </button>

              {notifOpen && (
                <div className="absolute right-0 mt-2 w-80 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] shadow-2xl p-3 z-50 space-y-2">
                  <div className="flex items-center justify-between px-1 pb-1 border-b border-slate-200 dark:border-white/10">
                    <span className="text-xs font-semibold text-slate-900 dark:text-white">
                      Notifications ({notifications.length})
                    </span>
                  </div>
                  {notifications.length === 0 ? (
                    <div className="py-6 text-center text-xs text-slate-500 dark:text-slate-400">
                      Aucune notification en attente.
                    </div>
                  ) : (
                    <div className="max-h-72 overflow-y-auto space-y-1.5">
                      {notifications.map((n) => (
                        <button
                          key={n.id}
                          type="button"
                          onClick={() =>
                            navigate(n.targetTab, n.kind === 'achievement' ? 'succes' : undefined)
                          }
                          className="w-full text-left p-2.5 rounded-xl bg-slate-50 dark:bg-[#22262c] hover:bg-slate-100 dark:hover:bg-white/10 transition-colors cursor-pointer"
                        >
                          <div className="text-xs font-semibold text-slate-900 dark:text-white">
                            {n.title}
                          </div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                            {n.detail}
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Floating Bottom Navigation */}
      <div className="md:hidden fixed bottom-3 left-3 right-3 z-40" ref={mobileMoreRef}>
        {moreOpen && (
          <div className="mb-2 rounded-2xl border border-slate-200 dark:border-white/10 bg-white/95 dark:bg-[#181b1f]/95 backdrop-blur-md shadow-2xl p-2 grid grid-cols-3 gap-1.5">
            {moreItems.map((m) => (
              <button
                key={m.key}
                type="button"
                onClick={() => navigate(m.tab, m.profileSubTab)}
                className="relative flex flex-col items-center justify-center gap-1 py-2.5 px-2 rounded-xl text-[11px] font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/5 cursor-pointer"
              >
                {m.icon}
                <span className="truncate max-w-full">{m.label}</span>
                {m.badge && m.badge > 0 ? (
                  <span className="absolute top-1.5 right-2 px-1.5 rounded-full text-[10px] font-mono-num font-bold bg-emerald-600 text-white">
                    {m.badge}
                  </span>
                ) : null}
              </button>
            ))}
          </div>
        )}

        <nav className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white/95 dark:bg-[#181b1f]/95 backdrop-blur-md shadow-2xl px-2 py-1.5 flex items-center justify-around">
          {(
            [
              { id: 'paquets', label: 'Paquets', icon: <Package className="w-4 h-4" /> },
              { id: 'collection', label: 'Collection', icon: <Layers className="w-4 h-4" /> },
              {
                id: 'echanges',
                label: 'Échanges',
                icon: <Repeat className="w-4 h-4" />,
                badge: pendingTradesCount,
              },
              { id: 'marche', label: 'Marché', icon: <Gavel className="w-4 h-4" /> },
            ] as { id: NavTab; label: string; icon: React.ReactNode; badge?: number }[]
          ).map((item) => {
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => navigate(item.id)}
                className={`relative flex flex-col items-center justify-center py-1 px-2.5 rounded-xl text-[11px] font-medium transition-colors cursor-pointer ${
                  active
                    ? 'text-emerald-600 dark:text-emerald-400 font-semibold'
                    : 'text-slate-500 dark:text-slate-400'
                }`}
              >
                {item.icon}
                <span className="mt-0.5">{item.label}</span>
                {item.badge && item.badge > 0 ? (
                  <span className="absolute -top-0.5 right-1 px-1.5 rounded-full text-[9px] font-mono-num font-bold bg-emerald-600 text-white">
                    {item.badge}
                  </span>
                ) : null}
              </button>
            );
          })}

          <button
            type="button"
            onClick={() => setMoreOpen((v) => !v)}
            className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl text-[11px] font-medium transition-colors cursor-pointer ${
              isMoreActive || moreOpen
                ? 'text-emerald-600 dark:text-emerald-400 font-semibold'
                : 'text-slate-500 dark:text-slate-400'
            }`}
          >
            <MoreHorizontal className="w-4 h-4" />
            <span className="mt-0.5">Plus</span>
          </button>
        </nav>
      </div>

      {/* Virtual Currency Explanation Modal */}
      {currencyModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm"
          onClick={() => setCurrencyModalOpen(false)}
        >
          <div
            className="w-full max-w-md rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-6 shadow-2xl space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-display font-bold text-slate-900 dark:text-white">
                Monnaie virtuelle ●
              </h2>
              <button
                type="button"
                onClick={() => setCurrencyModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-white/5 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="rounded-xl border border-[#c8952d]/35 bg-[#c8952d]/10 p-4 flex items-center justify-between">
              <span className="text-sm font-medium text-slate-700 dark:text-slate-200">
                Solde actuel
              </span>
              <span className="text-2xl font-mono-num font-bold text-[#c8952d] dark:text-[#e2bb6b]">
                {coins.toLocaleString('fr-FR')} ●
              </span>
            </div>

            <div className="space-y-3 text-sm text-slate-600 dark:text-slate-300">
              <div>
                <h3 className="font-semibold text-slate-900 dark:text-white">
                  Comment en gagner ?
                </h3>
                <ul className="mt-1 space-y-1 text-xs list-disc pl-4">
                  <li>Duels PvP : +65 ● par victoire, +20 ● par défaite.</li>
                  <li>Entraînement Solo : +15 ● par victoire contre l’automate.</li>
                  <li>Défausse de doublons : +1 ● par carte défaussée.</li>
                  <li>Ventes aux enchères et réclamation des 11 Succès.</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-slate-900 dark:text-white">
                  À quoi sert-elle ?
                </h3>
                <ul className="mt-1 space-y-1 text-xs list-disc pl-4">
                  <li>Acheter des boosters supplémentaires (120 ●).</li>
                  <li>Enchérir et acheter des cartes au Marché.</li>
                  <li>Débloquer emblèmes, cadres et bannières dans la Boutique.</li>
                </ul>
              </div>
              <p className="text-xs rounded-xl bg-slate-100 dark:bg-[#22262c] p-3 text-slate-700 dark:text-slate-300">
                Jeu 100 % virtuel et gratuit : aucune transaction ni aucun argent réel n’est utilisé dans Wiki JH.
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
