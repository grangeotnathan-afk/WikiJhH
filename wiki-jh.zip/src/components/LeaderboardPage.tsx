import React, { useState, useMemo } from 'react';
import { Search, Trophy, X } from 'lucide-react';
import type { Campus, PlayerProfile } from '../types/game';
import { getTotalOwnedCards, getUniqueOwnedCards } from '../data/cards';
import { COSMETIC_BY_ID } from '../data/cosmeticsAndAchievements';
import { CardVisual } from './CardVisual';

interface LeaderboardPageProps {
  allPlayers: PlayerProfile[];
  currentUid: string;
}

export function PlayerProfileModal({
  player,
  onClose,
}: {
  player: PlayerProfile | null;
  onClose: () => void;
}) {
  if (!player) return null;

  const bannerCls =
    COSMETIC_BY_ID[player.equippedBanner]?.previewClass ||
    'bg-gradient-to-r from-slate-800 via-slate-900 to-slate-800';
  const frameCls =
    COSMETIC_BY_ID[player.equippedFrame]?.previewClass || 'ring-2 ring-slate-400/50';
  const emblem = COSMETIC_BY_ID[player.equippedEmblem]?.symbol || '◆';
  const titleName = COSMETIC_BY_ID[player.equippedTitle]?.name || 'Élève de Jules Haag';

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] overflow-hidden shadow-2xl max-h-[88vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Banner */}
        <div className={`h-28 relative ${bannerCls}`}>
          <button
            type="button"
            onClick={onClose}
            className="absolute top-3 right-3 p-2 rounded-xl bg-black/40 text-white hover:bg-black/60 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="px-6 pb-6 -mt-10 space-y-5">
          {/* Avatar + Identity */}
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div className="flex items-end gap-4">
              <div
                className={`w-20 h-20 rounded-2xl bg-[#181b1f] text-3xl text-[#e2bb6b] flex items-center justify-center shadow-xl ${frameCls}`}
              >
                {emblem}
              </div>
              <div className="pb-1">
                <div className="text-xs font-semibold text-[#c8952d] dark:text-[#e2bb6b]">
                  {titleName}
                </div>
                <h2 className="text-2xl font-display font-bold text-slate-900 dark:text-white">
                  {player.pseudo}
                </h2>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  Site {player.campus} · {player.classe}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 font-mono-num text-xs">
              <div className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-[#22262c] text-center">
                <div className="text-[10px] text-slate-500">ELO</div>
                <div className="font-bold text-sm text-[#c8952d] dark:text-[#e2bb6b]">
                  {player.elo}
                </div>
              </div>
              <div className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-[#22262c] text-center">
                <div className="text-[10px] text-slate-500">V / D</div>
                <div className="font-bold text-sm">
                  {player.wins}/{player.losses}
                </div>
              </div>
              <div className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-[#22262c] text-center">
                <div className="text-[10px] text-slate-500">Cartes</div>
                <div className="font-bold text-sm">
                  {getUniqueOwnedCards(player.inventory)}/15 ({getTotalOwnedCards(player.inventory)})
                </div>
              </div>
            </div>
          </div>

          {player.bio && (
            <p className="text-sm text-slate-600 dark:text-slate-300 rounded-xl bg-slate-50 dark:bg-[#22262c] p-3.5">
              {player.bio}
            </p>
          )}

          {/* Showcase */}
          <div className="space-y-2.5">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
              Vitrine ({player.showcase?.length || 0}/3)
            </h3>
            {!player.showcase || player.showcase.length === 0 ? (
              <div className="py-6 text-center text-xs text-slate-500 dark:text-slate-400 rounded-xl border border-dashed border-slate-200 dark:border-white/10">
                Aucune carte épinglée en vitrine.
              </div>
            ) : (
              <div className="grid grid-cols-3 gap-3">
                {player.showcase.map((cid) => (
                  <CardVisual key={cid} cardId={cid} compact showStats={false} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export function LeaderboardPage({ allPlayers, currentUid }: LeaderboardPageProps) {
  const [sortBy, setSortBy] = useState<'elo' | 'collection' | 'victoires'>('elo');
  const [campusFilter, setCampusFilter] = useState<'Tous' | Campus>('Tous');
  const [search, setSearch] = useState('');
  const [inspected, setInspected] = useState<PlayerProfile | null>(null);

  const cupStats = useMemo(() => {
    const calc = (campus: Campus) => {
      const members = allPlayers.filter((p) => p.campus === campus);
      const wins = members.reduce((s, p) => s + (p.wins || 0), 0);
      const points = members.reduce(
        (s, p) => s + Math.max(0, p.elo - 900) + p.wins * 15 + getUniqueOwnedCards(p.inventory) * 10,
        0
      );
      return { students: members.length, wins, points };
    };
    const labbe = calc('Labbé');
    const marceau = calc('Marceau');
    const total = Math.max(1, labbe.points + marceau.points);
    return {
      labbe,
      marceau,
      labbePct: Math.round((labbe.points / total) * 100),
      marceauPct: Math.round((marceau.points / total) * 100),
    };
  }, [allPlayers]);

  const ranked = useMemo(() => {
    const q = search.trim().toLowerCase();
    return allPlayers
      .filter((p) => {
        if (campusFilter !== 'Tous' && p.campus !== campusFilter) return false;
        if (q && !`${p.pseudo} ${p.classe} ${p.campus}`.toLowerCase().includes(q)) return false;
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'elo') return b.elo - a.elo;
        if (sortBy === 'victoires') return b.wins - a.wins;
        const uDiff = getUniqueOwnedCards(b.inventory) - getUniqueOwnedCards(a.inventory);
        if (uDiff !== 0) return uDiff;
        return getTotalOwnedCards(b.inventory) - getTotalOwnedCards(a.inventory);
      });
  }, [allPlayers, sortBy, campusFilter, search]);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 space-y-6 pb-24 md:pb-10">
      {/* Coupe Inter-Sites */}
      <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 sm:p-6 space-y-4">
        <div className="flex items-center justify-between gap-3">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#c8952d] dark:text-[#e2bb6b]">
              <Trophy className="w-4 h-4" />
              <span>Coupe Inter-Sites en temps réel</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-display font-bold text-slate-900 dark:text-white mt-0.5">
              Site Labbé vs Site Marceau
            </h1>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="rounded-xl border border-blue-500/25 bg-blue-500/5 p-4">
            <div className="text-xs font-semibold text-blue-600 dark:text-blue-400">Site Labbé</div>
            <div className="font-mono-num text-2xl font-bold text-slate-900 dark:text-white mt-1">
              {cupStats.labbe.points.toLocaleString('fr-FR')} pts
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-mono-num">
              {cupStats.labbe.students} élèves · {cupStats.labbe.wins} victoires
            </div>
          </div>

          <div className="rounded-xl border border-emerald-500/25 bg-emerald-500/5 p-4 text-right">
            <div className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
              Site Marceau
            </div>
            <div className="font-mono-num text-2xl font-bold text-slate-900 dark:text-white mt-1">
              {cupStats.marceau.points.toLocaleString('fr-FR')} pts
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-mono-num">
              {cupStats.marceau.students} élèves · {cupStats.marceau.wins} victoires
            </div>
          </div>
        </div>

        {/* Bicolour Progress Bar */}
        <div className="h-3.5 rounded-full overflow-hidden flex bg-slate-200 dark:bg-[#22262c]">
          <div
            className="bg-blue-600 transition-all duration-500"
            style={{ width: `${cupStats.labbePct}%` }}
          />
          <div
            className="bg-emerald-600 transition-all duration-500"
            style={{ width: `${cupStats.marceauPct}%` }}
          />
        </div>
      </div>

      {/* Player Leaderboard */}
      <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <h2 className="text-lg font-display font-bold text-slate-900 dark:text-white">
            Classement des joueurs ({ranked.length})
          </h2>

          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Rechercher un joueur…"
                className="pl-9 pr-3 py-1.5 rounded-xl text-xs border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] text-slate-900 dark:text-white"
              />
            </div>

            <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-100 dark:bg-[#22262c]">
              {(['Tous', 'Labbé', 'Marceau'] as const).map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setCampusFilter(c)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer ${
                    campusFilter === c
                      ? 'bg-white dark:bg-[#181b1f] text-slate-900 dark:text-white shadow-sm'
                      : 'text-slate-500'
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-100 dark:bg-[#22262c]">
              {(
                [
                  { id: 'elo', label: 'ELO' },
                  { id: 'collection', label: 'Collection' },
                  { id: 'victoires', label: 'Victoires' },
                ] as const
              ).map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setSortBy(s.id)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer ${
                    sortBy === s.id
                      ? 'bg-white dark:bg-[#181b1f] text-slate-900 dark:text-white shadow-sm'
                      : 'text-slate-500'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="divide-y divide-slate-200 dark:divide-white/10">
          {ranked.map((p, idx) => {
            const isMe = p.uid === currentUid;
            const emblem = COSMETIC_BY_ID[p.equippedEmblem]?.symbol || '◆';
            return (
              <button
                key={p.uid}
                type="button"
                onClick={() => setInspected(p)}
                className={`w-full py-3 px-3 flex items-center justify-between gap-3 text-left hover:bg-slate-50 dark:hover:bg-white/5 transition-colors cursor-pointer rounded-xl ${
                  isMe ? 'bg-emerald-500/5' : ''
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <span className="font-mono-num text-sm font-bold w-7 text-slate-400">
                    #{idx + 1}
                  </span>
                  <span className="text-lg text-[#c8952d] dark:text-[#e2bb6b] shrink-0">
                    {emblem}
                  </span>
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                      {p.pseudo} {isMe && '(Vous)'}
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                      <span
                        className={p.campus === 'Labbé' ? 'text-blue-500' : 'text-emerald-500'}
                      >
                        {p.campus}
                      </span>{' '}
                      · {p.classe}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4 font-mono-num text-xs shrink-0">
                  <div className="text-right">
                    <div className="font-bold text-[#c8952d] dark:text-[#e2bb6b]">{p.elo} ELO</div>
                    <div className="text-slate-500 dark:text-slate-400">
                      {getUniqueOwnedCards(p.inventory)}/15 · {p.wins}V
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      <PlayerProfileModal player={inspected} onClose={() => setInspected(null)} />
    </div>
  );
}
