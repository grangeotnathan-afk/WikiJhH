import React, { useState } from 'react';
import { Check, X, Ban, Download, Plus, Minus, ArrowLeftRight } from 'lucide-react';
import type { CardId, PlayerProfile, TradeOffer } from '../types/game';
import { CARDS, CARD_BY_ID, RARITY_META } from '../data/cards';

interface TradesPageProps {
  player: PlayerProfile;
  friends: PlayerProfile[];
  trades: TradeOffer[];
  preselectedFriendUid?: string | null;
  onCreateTrade: (
    recipient: PlayerProfile,
    offered: CardId[],
    requested: CardId[]
  ) => Promise<void>;
  onAcceptTrade: (trade: TradeOffer) => Promise<void>;
  onRejectTrade: (trade: TradeOffer) => Promise<void>;
  onCancelTrade: (trade: TradeOffer) => Promise<void>;
  onClaimTrade: (trade: TradeOffer) => Promise<void>;
}

export function TradesPage({
  player,
  friends,
  trades,
  preselectedFriendUid,
  onCreateTrade,
  onAcceptTrade,
  onRejectTrade,
  onCancelTrade,
  onClaimTrade,
}: TradesPageProps) {
  const [subTab, setSubTab] = useState<'recues' | 'envoyees' | 'nouvelle'>(
    preselectedFriendUid ? 'nouvelle' : 'recues'
  );
  const [selectedFriendUid, setSelectedFriendUid] = useState<string>(
    preselectedFriendUid || friends[0]?.uid || ''
  );
  const [offeredCounts, setOfferedCounts] = useState<Partial<Record<CardId, number>>>({});
  const [requestedCounts, setRequestedCounts] = useState<Partial<Record<CardId, number>>>({});
  const [busyId, setBusyId] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);

  const incomingTrades = trades.filter((t) => t.recipientId === player.uid);
  const outgoingTrades = trades.filter((t) => t.senderId === player.uid);
  const selectedFriend = friends.find((f) => f.uid === selectedFriendUid) || friends[0] || null;

  const expandMapToList = (map: Partial<Record<CardId, number>>): CardId[] => {
    const out: CardId[] = [];
    for (const [cid, qty] of Object.entries(map)) {
      for (let i = 0; i < (qty || 0); i++) {
        out.push(cid as CardId);
      }
    }
    return out;
  };

  const offeredList = expandMapToList(offeredCounts);
  const requestedList = expandMapToList(requestedCounts);

  const adjustCount = (
    setter: React.Dispatch<React.SetStateAction<Partial<Record<CardId, number>>>>,
    currentMap: Partial<Record<CardId, number>>,
    cardId: CardId,
    maxOwned: number,
    delta: number
  ) => {
    const totalNow = Object.values(currentMap).reduce((s, n) => s + (n || 0), 0);
    const cur = currentMap[cardId] || 0;
    if (delta > 0 && (totalNow >= 5 || cur >= maxOwned)) return;
    if (delta < 0 && cur <= 0) return;
    setter({ ...currentMap, [cardId]: cur + delta });
  };

  const handleSend = async () => {
    if (!selectedFriend || offeredList.length === 0 || requestedList.length === 0 || creating) {
      return;
    }
    setCreating(true);
    try {
      await onCreateTrade(selectedFriend, offeredList, requestedList);
      setOfferedCounts({});
      setRequestedCounts({});
      setSubTab('envoyees');
    } finally {
      setCreating(false);
    }
  };

  const renderCardBadges = (cardIds: CardId[]) => {
    const counts: Partial<Record<CardId, number>> = {};
    for (const id of cardIds) counts[id] = (counts[id] || 0) + 1;
    return (
      <div className="flex flex-wrap gap-1.5">
        {Object.entries(counts).map(([cid, qty]) => {
          const card = CARD_BY_ID[cid as CardId];
          const meta = RARITY_META[card.rarity];
          return (
            <span
              key={cid}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] text-slate-800 dark:text-slate-100"
            >
              <span className="font-mono-num font-bold text-[10px]" style={{ color: meta.color }}>
                {card.rarity}
              </span>
              <span>{card.name}</span>
              {(qty || 1) > 1 && <strong className="font-mono-num">×{qty}</strong>}
            </span>
          );
        })}
      </div>
    );
  };

  const statusLabel: Record<TradeOffer['status'], { text: string; cls: string }> = {
    pending: { text: 'En attente', cls: 'text-amber-600 dark:text-amber-400' },
    accepted: { text: 'Acceptée', cls: 'text-emerald-600 dark:text-emerald-400' },
    rejected: { text: 'Refusée', cls: 'text-rose-600 dark:text-rose-400' },
    cancelled: { text: 'Annulée', cls: 'text-slate-500 dark:text-slate-400' },
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 space-y-6 pb-24 md:pb-10">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-display font-bold text-slate-900 dark:text-white">
            Échanges entre amis
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Proposez des échanges de 1 à 5 cartes avec vos amis. Les cartes proposées sont mises sous séquestre à l’envoi.
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-200/70 dark:bg-[#181b1f] border border-slate-200 dark:border-white/10">
          {(
            [
              {
                id: 'recues',
                label: `Reçues (${incomingTrades.filter((t) => t.status === 'pending').length})`,
              },
              { id: 'envoyees', label: `Envoyées (${outgoingTrades.length})` },
              { id: 'nouvelle', label: 'Nouvelle offre' },
            ] as const
          ).map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setSubTab(t.id)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                subTab === t.id
                  ? 'bg-white dark:bg-[#22262c] text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Incoming Offers */}
      {subTab === 'recues' && (
        <div className="space-y-3">
          {incomingTrades.length === 0 ? (
            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-10 text-center text-sm text-slate-500 dark:text-slate-400">
              Aucune proposition d’échange reçue pour le moment.
            </div>
          ) : (
            incomingTrades.map((trade) => (
              <div
                key={trade.id}
                className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 space-y-4"
              >
                <div className="flex items-center justify-between gap-3">
                  <div className="text-sm font-semibold text-slate-900 dark:text-white">
                    Offre de {trade.senderPseudo}
                  </div>
                  <span className={`text-xs font-semibold ${statusLabel[trade.status].cls}`}>
                    {statusLabel[trade.status].text}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <div className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                      Vous recevez ({trade.offeredCards.length})
                    </div>
                    {renderCardBadges(trade.offeredCards)}
                  </div>
                  <div className="space-y-1.5">
                    <div className="text-xs font-semibold text-rose-600 dark:text-rose-400">
                      Vous donnez ({trade.requestedCards.length})
                    </div>
                    {renderCardBadges(trade.requestedCards)}
                  </div>
                </div>

                {trade.status === 'pending' && (
                  <div className="flex flex-wrap items-center justify-end gap-2 pt-2 border-t border-slate-200 dark:border-white/10">
                    <button
                      type="button"
                      disabled={busyId === trade.id}
                      onClick={async () => {
                        setBusyId(trade.id);
                        try {
                          await onRejectTrade(trade);
                        } finally {
                          setBusyId(null);
                        }
                      }}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl border border-rose-500/30 bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 text-xs font-semibold cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                      <span>Refuser</span>
                    </button>
                    <button
                      type="button"
                      disabled={busyId === trade.id}
                      onClick={async () => {
                        setBusyId(trade.id);
                        try {
                          await onAcceptTrade(trade);
                        } finally {
                          setBusyId(null);
                        }
                      }}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold cursor-pointer"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Accepter l’échange</span>
                    </button>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      )}

      {/* Outgoing Offers */}
      {subTab === 'envoyees' && (
        <div className="space-y-3">
          {outgoingTrades.length === 0 ? (
            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-10 text-center text-sm text-slate-500 dark:text-slate-400">
              Vous n’avez envoyé aucune offre d’échange.
            </div>
          ) : (
            outgoingTrades.map((trade) => {
              const canClaim =
                (trade.status === 'accepted' || trade.status === 'rejected') &&
                !trade.senderClaimed;
              return (
                <div
                  key={trade.id}
                  className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 space-y-4"
                >
                  <div className="flex items-center justify-between gap-3">
                    <div className="text-sm font-semibold text-slate-900 dark:text-white">
                      Offre envoyée à {trade.recipientPseudo}
                    </div>
                    <span className={`text-xs font-semibold ${statusLabel[trade.status].cls}`}>
                      {statusLabel[trade.status].text}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                        Cartes proposées ({trade.offeredCards.length})
                      </div>
                      {renderCardBadges(trade.offeredCards)}
                    </div>
                    <div className="space-y-1.5">
                      <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                        Cartes demandées ({trade.requestedCards.length})
                      </div>
                      {renderCardBadges(trade.requestedCards)}
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200 dark:border-white/10">
                    {trade.status === 'pending' && (
                      <button
                        type="button"
                        disabled={busyId === trade.id}
                        onClick={async () => {
                          setBusyId(trade.id);
                          try {
                            await onCancelTrade(trade);
                          } finally {
                            setBusyId(null);
                          }
                        }}
                        className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl border border-slate-300 dark:border-white/15 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/5 cursor-pointer"
                      >
                        <Ban className="w-3.5 h-3.5" />
                        <span>Annuler et récupérer mes cartes</span>
                      </button>
                    )}

                    {canClaim && (
                      <button
                        type="button"
                        disabled={busyId === trade.id}
                        onClick={async () => {
                          setBusyId(trade.id);
                          try {
                            await onClaimTrade(trade);
                          } finally {
                            setBusyId(null);
                          }
                        }}
                        className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>
                          {trade.status === 'accepted'
                            ? 'Récupérer les cartes obtenues'
                            : 'Récupérer mes cartes restituées'}
                        </span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* New Trade Offer */}
      {subTab === 'nouvelle' && (
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 sm:p-6 space-y-6">
          {friends.length === 0 ? (
            <div className="py-8 text-center text-sm text-slate-500 dark:text-slate-400">
              Vous devez d’abord ajouter au moins un ami dans l’onglet Amis pour pouvoir échanger des cartes.
            </div>
          ) : (
            <>
              <div className="space-y-1.5 max-w-sm">
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300">
                  Choisir un ami
                </label>
                <select
                  value={selectedFriend?.uid || ''}
                  onChange={(e) => {
                    setSelectedFriendUid(e.target.value);
                    setRequestedCounts({});
                  }}
                  className="w-full px-3.5 py-2.5 rounded-xl text-sm border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] text-slate-900 dark:text-white"
                >
                  {friends.map((f) => (
                    <option key={f.uid} value={f.uid}>
                      {f.pseudo} ({f.campus} · {f.classe})
                    </option>
                  ))}
                </select>
              </div>

              {selectedFriend && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* My Offered Cards */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
                        1. Vos cartes à donner
                      </h2>
                      <span className="font-mono-num text-xs text-slate-500 dark:text-slate-400">
                        {offeredList.length} / 5
                      </span>
                    </div>
                    <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                      {CARDS.filter((c) => (player.inventory[c.id] || 0) > 0).map((c) => {
                        const owned = player.inventory[c.id] || 0;
                        const picked = offeredCounts[c.id] || 0;
                        return (
                          <div
                            key={c.id}
                            className="flex items-center justify-between px-3 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c]"
                          >
                            <div className="min-w-0">
                              <div className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                                {c.name}{' '}
                                <span
                                  className="font-mono-num ml-1"
                                  style={{ color: RARITY_META[c.rarity].color }}
                                >
                                  {c.rarity}
                                </span>
                              </div>
                              <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono-num">
                                Dispo : ×{owned}
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <button
                                type="button"
                                onClick={() =>
                                  adjustCount(setOfferedCounts, offeredCounts, c.id, owned, -1)
                                }
                                className="p-1.5 rounded-lg bg-white dark:bg-[#181b1f] border border-slate-200 dark:border-white/10 cursor-pointer"
                              >
                                <Minus className="w-3.5 h-3.5" />
                              </button>
                              <span className="font-mono-num text-xs font-bold w-5 text-center">
                                {picked}
                              </span>
                              <button
                                type="button"
                                onClick={() =>
                                  adjustCount(setOfferedCounts, offeredCounts, c.id, owned, 1)
                                }
                                className="p-1.5 rounded-lg bg-white dark:bg-[#181b1f] border border-slate-200 dark:border-white/10 cursor-pointer"
                              >
                                <Plus className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Friend's Inventory */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
                        2. Cartes demandées à {selectedFriend.pseudo}
                      </h2>
                      <span className="font-mono-num text-xs text-slate-500 dark:text-slate-400">
                        {requestedList.length} / 5
                      </span>
                    </div>
                    <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                      {CARDS.filter((c) => (selectedFriend.inventory[c.id] || 0) > 0).length ===
                      0 ? (
                        <div className="py-6 text-center text-xs text-slate-500">
                          Cet ami ne possède aucune carte disponible.
                        </div>
                      ) : (
                        CARDS.filter((c) => (selectedFriend.inventory[c.id] || 0) > 0).map((c) => {
                          const owned = selectedFriend.inventory[c.id] || 0;
                          const picked = requestedCounts[c.id] || 0;
                          return (
                            <div
                              key={c.id}
                              className="flex items-center justify-between px-3 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c]"
                            >
                              <div className="min-w-0">
                                <div className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                                  {c.name}{' '}
                                  <span
                                    className="font-mono-num ml-1"
                                    style={{ color: RARITY_META[c.rarity].color }}
                                  >
                                    {c.rarity}
                                  </span>
                                </div>
                                <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono-num">
                                  Inventaire : ×{owned}
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                <button
                                  type="button"
                                  onClick={() =>
                                    adjustCount(
                                      setRequestedCounts,
                                      requestedCounts,
                                      c.id,
                                      owned,
                                      -1
                                    )
                                  }
                                  className="p-1.5 rounded-lg bg-white dark:bg-[#181b1f] border border-slate-200 dark:border-white/10 cursor-pointer"
                                >
                                  <Minus className="w-3.5 h-3.5" />
                                </button>
                                <span className="font-mono-num text-xs font-bold w-5 text-center">
                                  {picked}
                                </span>
                                <button
                                  type="button"
                                  onClick={() =>
                                    adjustCount(
                                      setRequestedCounts,
                                      requestedCounts,
                                      c.id,
                                      owned,
                                      1
                                    )
                                  }
                                  className="p-1.5 rounded-lg bg-white dark:bg-[#181b1f] border border-slate-200 dark:border-white/10 cursor-pointer"
                                >
                                  <Plus className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>
                </div>
              )}

              <div className="flex items-center justify-end pt-3 border-t border-slate-200 dark:border-white/10">
                <button
                  type="button"
                  disabled={
                    creating ||
                    !selectedFriend ||
                    offeredList.length === 0 ||
                    requestedList.length === 0
                  }
                  onClick={handleSend}
                  className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-45 text-white text-sm font-semibold transition-colors cursor-pointer"
                >
                  <ArrowLeftRight className="w-4 h-4" />
                  <span>{creating ? 'Envoi…' : 'Envoyer l’offre d’échange'}</span>
                </button>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
