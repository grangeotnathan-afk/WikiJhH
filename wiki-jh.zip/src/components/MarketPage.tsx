import React, { useState, useEffect } from 'react';
import { Gavel, Clock, Zap, Download, Plus, Ban, History } from 'lucide-react';
import type { AuctionListing, CardId, PlayerProfile, Rarity } from '../types/game';
import { CARDS, CARD_BY_ID, RARITY_META, RARITY_ORDER } from '../data/cards';
import { CardVisual } from './CardVisual';

interface MarketPageProps {
  player: PlayerProfile;
  auctions: AuctionListing[];
  onCreateAuction: (params: {
    cardId: CardId;
    startingPrice: number;
    buyoutPrice: number;
    durationMinutes: number;
  }) => Promise<void>;
  onPlaceBid: (auction: AuctionListing, amount: number) => Promise<void>;
  onBuyout: (auction: AuctionListing) => Promise<void>;
  onCancelAuction: (auction: AuctionListing) => Promise<void>;
  onFinalizeAuction: (auction: AuctionListing) => Promise<void>;
  onClaimSeller: (auction: AuctionListing) => Promise<void>;
  onClaimWinner: (auction: AuctionListing) => Promise<void>;
  onClaimRefund: (auction: AuctionListing) => Promise<void>;
}

const DURATIONS = [
  { label: '30 min', minutes: 30 },
  { label: '1 h', minutes: 60 },
  { label: '6 h', minutes: 360 },
  { label: '12 h', minutes: 720 },
  { label: '24 h', minutes: 1440 },
];

export function MarketPage({
  player,
  auctions,
  onCreateAuction,
  onPlaceBid,
  onBuyout,
  onCancelAuction,
  onFinalizeAuction,
  onClaimSeller,
  onClaimWinner,
  onClaimRefund,
}: MarketPageProps) {
  const [tab, setTab] = useState<'enchères' | 'ventes'>('enchères');
  const [rarityFilter, setRarityFilter] = useState<'Toutes' | Rarity>('Toutes');
  const [nowMs, setNowMs] = useState(Date.now());
  const [bidInputs, setBidInputs] = useState<Record<string, string>>({});
  const [busyId, setBusyId] = useState<string | null>(null);

  // Create auction form state
  const ownedCardIds = CARDS.filter((c) => (player.inventory[c.id] || 0) > 0).map((c) => c.id);
  const [selectedCard, setSelectedCard] = useState<CardId | ''>(ownedCardIds[0] || '');
  const [startingPrice, setStartingPrice] = useState<string>(
    ownedCardIds[0] ? String(CARD_BY_ID[ownedCardIds[0]].suggestedPrice) : '15'
  );
  const [buyoutPrice, setBuyoutPrice] = useState<string>('');
  const [durationMinutes, setDurationMinutes] = useState<number>(60);
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    const id = setInterval(() => setNowMs(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    if (!selectedCard && ownedCardIds.length > 0) {
      const first = ownedCardIds[0];
      setSelectedCard(first);
      setStartingPrice(String(CARD_BY_ID[first].suggestedPrice));
    }
  }, [ownedCardIds.length]);

  const myActiveListings = auctions.filter(
    (a) => a.sellerId === player.uid && a.status === 'active'
  );

  const activeListings = auctions
    .filter((a) => {
      if (a.status !== 'active') return false;
      if (rarityFilter !== 'Toutes' && CARD_BY_ID[a.cardId].rarity !== rarityFilter) {
        return false;
      }
      return true;
    })
    .sort((a, b) => (a.endsAt?.toMillis?.() || 0) - (b.endsAt?.toMillis?.() || 0));

  const myRelatedListings = auctions
    .filter(
      (a) =>
        a.sellerId === player.uid ||
        a.highestBidderId === player.uid ||
        (a.pendingRefunds?.[player.uid] || 0) > 0
    )
    .sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));

  const unrecoveredClaims = auctions.filter((a) => {
    const refund = a.pendingRefunds?.[player.uid] || 0;
    const sellerPending =
      (a.status === 'sold' || a.status === 'ended') &&
      a.sellerId === player.uid &&
      !a.sellerClaimed;
    const winnerPending =
      a.status === 'ended' && a.highestBidderId === player.uid && !a.winnerClaimed;
    return refund > 0 || sellerPending || winnerPending;
  });

  const formatRemaining = (endsMs: number) => {
    const diff = endsMs - nowMs;
    if (diff <= 0) return 'Expirée';
    const totalSec = Math.floor(diff / 1000);
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;
    if (h > 0) return `${h}h ${String(m).padStart(2, '0')}m`;
    return `${String(m).padStart(2, '0')}m ${String(s).padStart(2, '0')}s`;
  };

  const handleSelectCardChange = (cid: CardId) => {
    setSelectedCard(cid);
    setStartingPrice(String(CARD_BY_ID[cid].suggestedPrice));
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCard || creating || myActiveListings.length >= 5) return;
    const startVal = Math.max(1, Math.floor(Number(startingPrice) || 1));
    const buyVal = buyoutPrice.trim() ? Math.max(startVal + 1, Math.floor(Number(buyoutPrice))) : 0;
    setCreating(true);
    try {
      await onCreateAuction({
        cardId: selectedCard,
        startingPrice: startVal,
        buyoutPrice: buyVal,
        durationMinutes,
      });
      setBuyoutPrice('');
    } finally {
      setCreating(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6 pb-24 md:pb-10">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-display font-bold text-slate-900 dark:text-white">
            Hôtel des ventes
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Enchères en temps réel avec règle anti-snipe (+1 min dans les 30 dernières secondes) et achat immédiat.
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-200/70 dark:bg-[#181b1f] border border-slate-200 dark:border-white/10">
          <button
            type="button"
            onClick={() => setTab('enchères')}
            className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              tab === 'enchères'
                ? 'bg-white dark:bg-[#22262c] text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Enchères en cours ({activeListings.length})
          </button>
          <button
            type="button"
            onClick={() => setTab('ventes')}
            className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              tab === 'ventes'
                ? 'bg-white dark:bg-[#22262c] text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Mes ventes ({myActiveListings.length}/5)
          </button>
        </div>
      </div>

      {/* Emergency Manual Recovery Banner */}
      {unrecoveredClaims.length > 0 && (
        <div className="rounded-2xl border border-[#c8952d]/45 bg-[#c8952d]/10 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="text-xs sm:text-sm text-slate-900 dark:text-slate-100">
            <strong>Récupération disponible :</strong> Vous avez{' '}
            <span className="font-mono-num font-bold">{unrecoveredClaims.length}</span>{' '}
            lot(s) ou remboursement(s) en attente de transfert.
          </div>
          <div className="flex flex-wrap gap-2">
            {unrecoveredClaims.map((a) => {
              const refund = a.pendingRefunds?.[player.uid] || 0;
              const isSeller =
                (a.status === 'sold' || a.status === 'ended') &&
                a.sellerId === player.uid &&
                !a.sellerClaimed;
              const isWinner =
                a.status === 'ended' && a.highestBidderId === player.uid && !a.winnerClaimed;
              return (
                <button
                  key={`claim-${a.id}`}
                  type="button"
                  onClick={() => {
                    if (refund > 0) onClaimRefund(a);
                    else if (isSeller) onClaimSeller(a);
                    else if (isWinner) onClaimWinner(a);
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#c8952d] text-slate-950 text-xs font-bold cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>
                    {refund > 0
                      ? `Remboursement +${refund} ●`
                      : isSeller && a.highestBidderId === ''
                      ? `Reprendre ${CARD_BY_ID[a.cardId].name}`
                      : isSeller
                      ? `Encaisser +${a.currentBid} ●`
                      : `Récupérer ${CARD_BY_ID[a.cardId].name}`}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 1: Active Auctions */}
      {tab === 'enchères' && (
        <div className="space-y-4">
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              type="button"
              onClick={() => setRarityFilter('Toutes')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                rarityFilter === 'Toutes'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-white dark:bg-[#181b1f] border border-slate-200 dark:border-white/10 text-slate-600 dark:text-slate-300'
              }`}
            >
              Toutes
            </button>
            {RARITY_ORDER.map((r) => (
              <button
                key={r}
                type="button"
                onClick={() => setRarityFilter(r)}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono-num font-bold cursor-pointer ${
                  rarityFilter === r
                    ? 'bg-emerald-600 text-white'
                    : 'bg-white dark:bg-[#181b1f] border border-slate-200 dark:border-white/10 text-slate-600 dark:text-slate-300'
                }`}
              >
                {r}
              </button>
            ))}
          </div>

          {activeListings.length === 0 ? (
            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-12 text-center text-sm text-slate-500 dark:text-slate-400">
              Aucune enchère active ne correspond à ce filtre.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {activeListings.map((auction) => {
                const endsMs = auction.endsAt?.toMillis?.() || 0;
                const expired = endsMs <= nowMs;
                const minNextBid =
                  auction.currentBid === 0 ? auction.startingPrice : auction.currentBid + 1;
                const bidVal = bidInputs[auction.id] ?? String(minNextBid);
                const isMine = auction.sellerId === player.uid;
                const isHighest = auction.highestBidderId === player.uid;

                return (
                  <div
                    key={auction.id}
                    className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-4 flex flex-col justify-between gap-4"
                  >
                    <div className="flex gap-3.5 items-start">
                      <div className="w-28 shrink-0">
                        <CardVisual cardId={auction.cardId} compact showStats={false} />
                      </div>
                      <div className="flex-1 min-w-0 space-y-2">
                        <div className="flex items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
                          <span className="truncate">Vendeur : {auction.sellerPseudo}</span>
                          <span
                            className={`inline-flex items-center gap-1 font-mono-num font-semibold shrink-0 ${
                              expired
                                ? 'text-rose-500'
                                : endsMs - nowMs <= 30000
                                ? 'text-amber-500'
                                : 'text-emerald-600 dark:text-emerald-400'
                            }`}
                          >
                            <Clock className="w-3 h-3" />
                            <span>{formatRemaining(endsMs)}</span>
                          </span>
                        </div>

                        <div className="rounded-xl bg-slate-50 dark:bg-[#22262c] p-2.5 space-y-1">
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-slate-500 dark:text-slate-400">
                              {auction.currentBid > 0 ? 'Enchère actuelle' : 'Prix de départ'}
                            </span>
                            <span className="font-mono-num font-bold text-sm text-[#c8952d] dark:text-[#e2bb6b]">
                              {auction.currentBid > 0 ? auction.currentBid : auction.startingPrice}{' '}
                              ●
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                            {auction.highestBidderId
                              ? `Meneur : ${auction.highestBidderPseudo}${
                                  isHighest ? ' (Vous)' : ''
                                }`
                              : 'Aucune offre pour l’instant'}
                          </div>
                        </div>

                        {auction.bidHistory.length > 0 && (
                          <div className="text-[11px] text-slate-500 dark:text-slate-400 space-y-0.5 max-h-16 overflow-y-auto">
                            <div className="flex items-center gap-1 font-semibold text-slate-600 dark:text-slate-300">
                              <History className="w-3 h-3" />
                              <span>Historique récent</span>
                            </div>
                            {auction.bidHistory
                              .slice(-3)
                              .reverse()
                              .map((b, idx) => (
                                <div key={`${b.uid}-${idx}`} className="flex justify-between">
                                  <span className="truncate">{b.pseudo}</span>
                                  <span className="font-mono-num">{b.amount} ●</span>
                                </div>
                              ))}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Controls */}
                    {expired ? (
                      <button
                        type="button"
                        disabled={busyId === auction.id}
                        onClick={async () => {
                          setBusyId(auction.id);
                          try {
                            await onFinalizeAuction(auction);
                          } finally {
                            setBusyId(null);
                          }
                        }}
                        className="w-full py-2 rounded-xl bg-slate-800 dark:bg-white/10 hover:bg-slate-700 text-white text-xs font-semibold cursor-pointer"
                      >
                        Clôturer l’enchère expirée
                      </button>
                    ) : !isMine ? (
                      <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-white/10">
                        <div className="flex items-center gap-2">
                          <input
                            type="number"
                            min={minNextBid}
                            value={bidVal}
                            onChange={(e) =>
                              setBidInputs({ ...bidInputs, [auction.id]: e.target.value })
                            }
                            className="w-24 px-2.5 py-2 rounded-xl text-xs font-mono-num font-bold border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] text-slate-900 dark:text-white"
                          />
                          <button
                            type="button"
                            disabled={
                              busyId === auction.id ||
                              isHighest ||
                              Number(bidVal) < minNextBid ||
                              player.coins < Number(bidVal)
                            }
                            onClick={async () => {
                              setBusyId(auction.id);
                              try {
                                await onPlaceBid(auction, Math.floor(Number(bidVal)));
                              } finally {
                                setBusyId(null);
                              }
                            }}
                            className="flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-45 text-white text-xs font-semibold cursor-pointer"
                          >
                            <Gavel className="w-3.5 h-3.5" />
                            <span>
                              {isHighest
                                ? 'Vous menez'
                                : auction.currentBid > 0
                                ? 'Surenchérir'
                                : 'Enchérir'}
                            </span>
                          </button>
                        </div>

                        {auction.buyoutPrice > 0 && (
                          <button
                            type="button"
                            disabled={
                              busyId === auction.id || player.coins < auction.buyoutPrice
                            }
                            onClick={async () => {
                              setBusyId(auction.id);
                              try {
                                await onBuyout(auction);
                              } finally {
                                setBusyId(null);
                              }
                            }}
                            className="w-full inline-flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl border border-[#c8952d]/50 bg-[#c8952d]/15 hover:bg-[#c8952d]/25 disabled:opacity-45 text-slate-900 dark:text-[#e2bb6b] text-xs font-bold font-mono-num cursor-pointer"
                          >
                            <Zap className="w-3.5 h-3.5" />
                            <span>Achat immédiat · {auction.buyoutPrice} ●</span>
                          </button>
                        )}
                      </div>
                    ) : (
                      <div className="text-center text-xs text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-200 dark:border-white/10">
                        Votre annonce en cours
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Tab 2: My Listings & Create Listing */}
      {tab === 'ventes' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Create Form */}
          <form
            onSubmit={handleCreate}
            className="lg:col-span-5 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-display font-bold text-slate-900 dark:text-white">
                Mettre une carte en vente
              </h2>
              <span className="font-mono-num text-xs text-slate-500 dark:text-slate-400">
                {myActiveListings.length}/5 actives
              </span>
            </div>

            {ownedCardIds.length === 0 ? (
              <div className="py-6 text-center text-xs text-slate-500 dark:text-slate-400">
                Vous ne possédez aucune carte à mettre en vente.
              </div>
            ) : (
              <>
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Carte possédée
                  </label>
                  <select
                    value={selectedCard}
                    onChange={(e) => handleSelectCardChange(e.target.value as CardId)}
                    className="w-full px-3.5 py-2.5 rounded-xl text-sm border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] text-slate-900 dark:text-white"
                  >
                    {ownedCardIds.map((cid) => (
                      <option key={cid} value={cid}>
                        {CARD_BY_ID[cid].name} ({CARD_BY_ID[cid].rarity}) · ×
                        {player.inventory[cid]}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                      Prix de départ (min 1 ●)
                    </label>
                    <input
                      type="number"
                      min={1}
                      value={startingPrice}
                      onChange={(e) => setStartingPrice(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl text-sm font-mono-num border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] text-slate-900 dark:text-white"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                      Achat immédiat (optionnel)
                    </label>
                    <input
                      type="number"
                      min={2}
                      placeholder="Aucun"
                      value={buyoutPrice}
                      onChange={(e) => setBuyoutPrice(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl text-sm font-mono-num border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] text-slate-900 dark:text-white"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Durée de l’enchère
                  </label>
                  <div className="grid grid-cols-5 gap-1.5">
                    {DURATIONS.map((d) => (
                      <button
                        key={d.minutes}
                        type="button"
                        onClick={() => setDurationMinutes(d.minutes)}
                        className={`py-2 rounded-xl text-xs font-mono-num font-semibold border transition-colors cursor-pointer ${
                          durationMinutes === d.minutes
                            ? 'border-emerald-500 bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
                            : 'border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        {d.label}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={creating || myActiveListings.length >= 5 || !selectedCard}
                  className="w-full inline-flex items-center justify-center gap-2 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-45 text-white text-sm font-semibold cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>
                    {myActiveListings.length >= 5
                      ? 'Limite de 5 annonces atteinte'
                      : creating
                      ? 'Publication…'
                      : 'Publier l’enchère'}
                  </span>
                </button>
              </>
            )}
          </form>

          {/* My Sales & History */}
          <div className="lg:col-span-7 space-y-3">
            {myRelatedListings.length === 0 ? (
              <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-10 text-center text-sm text-slate-500 dark:text-slate-400">
                Vous n’avez aucune vente ni enchère suivie.
              </div>
            ) : (
              myRelatedListings.map((a) => {
                const endsMs = a.endsAt?.toMillis?.() || 0;
                const expired = a.status === 'active' && endsMs <= nowMs;
                const card = CARD_BY_ID[a.cardId];
                const meta = RARITY_META[card.rarity];
                return (
                  <div
                    key={a.id}
                    className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
                        <span className="font-mono-num text-xs" style={{ color: meta.color }}>
                          {card.rarity}
                        </span>
                        <span>{card.name}</span>
                        <span className="text-xs font-normal text-slate-500 dark:text-slate-400">
                          · {a.status === 'active' ? formatRemaining(endsMs) : a.status}
                        </span>
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-mono-num">
                        {a.currentBid > 0
                          ? `Offre : ${a.currentBid} ● (${a.highestBidderPseudo})`
                          : `Départ : ${a.startingPrice} ● · Aucune enchère`}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {a.status === 'active' &&
                        !expired &&
                        a.sellerId === player.uid &&
                        a.highestBidderId === '' && (
                          <button
                            type="button"
                            onClick={() => onCancelAuction(a)}
                            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl border border-slate-300 dark:border-white/15 text-xs font-semibold text-slate-700 dark:text-slate-200 cursor-pointer"
                          >
                            <Ban className="w-3.5 h-3.5" />
                            <span>Annuler</span>
                          </button>
                        )}
                      {expired && (
                        <button
                          type="button"
                          onClick={() => onFinalizeAuction(a)}
                          className="px-3 py-1.5 rounded-xl bg-slate-800 text-white text-xs font-semibold cursor-pointer"
                        >
                          Clôturer
                        </button>
                      )}
                      {(a.status === 'sold' || a.status === 'ended') &&
                        a.sellerId === player.uid &&
                        !a.sellerClaimed && (
                          <button
                            type="button"
                            onClick={() => onClaimSeller(a)}
                            className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-semibold cursor-pointer"
                          >
                            {a.highestBidderId ? `Encaisser +${a.currentBid} ●` : 'Reprendre carte'}
                          </button>
                        )}
                      {a.status === 'ended' &&
                        a.highestBidderId === player.uid &&
                        !a.winnerClaimed && (
                          <button
                            type="button"
                            onClick={() => onClaimWinner(a)}
                            className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-semibold cursor-pointer"
                          >
                            Récupérer la carte
                          </button>
                        )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
}
