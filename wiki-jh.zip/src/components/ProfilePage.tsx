import React, { useState, useEffect } from 'react';
import {
  Volume2,
  VolumeX,
  LogOut,
  Sun,
  Moon,
  Award,
  ShoppingBag,
  Settings,
  Palette,
  Check,
  ChevronRight,
} from 'lucide-react';
import type { Campus, CardId, PlayerProfile, ProfileSubTab } from '../types/game';
import { CARDS, getUniqueOwnedCards } from '../data/cards';
import {
  ACHIEVEMENTS,
  COSMETICS,
  COSMETIC_BY_ID,
} from '../data/cosmeticsAndAchievements';
import { ClassSelectorModal } from './AuthAndOnboarding';
import { CardVisual } from './CardVisual';

interface ProfilePageProps {
  player: PlayerProfile;
  friendsCount: number;
  subTab: ProfileSubTab;
  onChangeSubTab: (subTab: ProfileSubTab) => void;
  darkMode: boolean;
  muted: boolean;
  onToggleTheme: () => void;
  onToggleMute: () => void;
  onSignOut: () => void;
  onUpdateProfile: (updates: {
    pseudo: string;
    campus: Campus;
    classe: string;
    bio: string;
    equippedEmblem: string;
    equippedFrame: string;
    equippedBanner: string;
    equippedTitle: string;
    showcase: CardId[];
  }) => Promise<void>;
  onClaimAchievement: (achId: string) => Promise<void>;
  onBuyCosmetic: (cosmeticId: string) => Promise<void>;
}

export function ProfilePage({
  player,
  friendsCount,
  subTab,
  onChangeSubTab,
  darkMode,
  muted,
  onToggleTheme,
  onToggleMute,
  onSignOut,
  onUpdateProfile,
  onClaimAchievement,
  onBuyCosmetic,
}: ProfilePageProps) {

  // Editable fields for live preview
  const [pseudo, setPseudo] = useState(player.pseudo);
  const [campus, setCampus] = useState<Campus>(player.campus);
  const [classe, setClasse] = useState(player.classe);
  const [bio, setBio] = useState(player.bio || '');
  const [equippedEmblem, setEquippedEmblem] = useState(player.equippedEmblem);
  const [equippedFrame, setEquippedFrame] = useState(player.equippedFrame);
  const [equippedBanner, setEquippedBanner] = useState(player.equippedBanner);
  const [equippedTitle, setEquippedTitle] = useState(player.equippedTitle);
  const [showcase, setShowcase] = useState<CardId[]>(player.showcase || []);
  const [classModalOpen, setClassModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);

  useEffect(() => {
    setPseudo(player.pseudo);
    setCampus(player.campus);
    setClasse(player.classe);
    setBio(player.bio || '');
    setEquippedEmblem(player.equippedEmblem);
    setEquippedFrame(player.equippedFrame);
    setEquippedBanner(player.equippedBanner);
    setEquippedTitle(player.equippedTitle);
    setShowcase(player.showcase || []);
  }, [player]);

  const bannerCls =
    COSMETIC_BY_ID[equippedBanner]?.previewClass ||
    'bg-gradient-to-r from-slate-800 via-slate-900 to-slate-800';
  const frameCls =
    COSMETIC_BY_ID[equippedFrame]?.previewClass || 'ring-2 ring-slate-400/50';
  const emblemSymbol = COSMETIC_BY_ID[equippedEmblem]?.symbol || '◆';
  const titleLabel = COSMETIC_BY_ID[equippedTitle]?.name || 'Élève de Jules Haag';

  const unlockedSet = new Set(player.unlockedCosmetics || []);

  const toggleShowcaseCard = (cid: CardId) => {
    setShowcase((prev) => {
      if (prev.includes(cid)) return prev.filter((id) => id !== cid);
      if (prev.length >= 3) return [...prev.slice(1), cid];
      return [...prev, cid];
    });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = pseudo.trim();
    if (trimmed.length < 2 || trimmed.length > 32) return;
    setSaving(true);
    try {
      await onUpdateProfile({
        pseudo: trimmed,
        campus,
        classe,
        bio: bio.slice(0, 200),
        equippedEmblem,
        equippedFrame,
        equippedBanner,
        equippedTitle,
        showcase,
      });
    } finally {
      setSaving(false);
    }
  };

  const ownedCards = CARDS.filter((c) => (player.inventory[c.id] || 0) > 0);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 space-y-6 pb-24 md:pb-10">
      {/* Dynamic Profile Header */}
      <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] overflow-hidden shadow-lg">
        <div className={`h-32 sm:h-36 relative ${bannerCls}`}>
          <div className="absolute top-3 right-3 flex items-center gap-2">
            <button
              type="button"
              onClick={onToggleMute}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-black/45 hover:bg-black/65 text-white text-xs font-semibold backdrop-blur-sm cursor-pointer"
            >
              {muted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
              <span>{muted ? 'Son coupé' : 'Son activé'}</span>
            </button>
            <button
              type="button"
              onClick={onSignOut}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-black/45 hover:bg-rose-600/80 text-white text-xs font-semibold backdrop-blur-sm cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Déconnexion</span>
            </button>
          </div>
        </div>

        <div className="px-5 sm:px-6 pb-6 -mt-12 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div className="flex items-end gap-4">
              <div
                className={`w-24 h-24 rounded-2xl bg-[#181b1f] text-4xl text-[#e2bb6b] flex items-center justify-center shadow-xl shrink-0 ${frameCls}`}
              >
                {emblemSymbol}
              </div>
              <div className="pb-1">
                <div className="text-xs font-semibold text-[#c8952d] dark:text-[#e2bb6b]">
                  {titleLabel}
                </div>
                <h1 className="text-2xl sm:text-3xl font-display font-bold text-slate-900 dark:text-white">
                  {pseudo || player.pseudo}
                </h1>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  Site {campus} · {classe}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 font-mono-num text-xs">
              <div className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-[#22262c] text-center">
                <div className="text-[10px] text-slate-500">ELO</div>
                <div className="font-bold text-sm text-[#c8952d] dark:text-[#e2bb6b]">
                  {player.elo}
                </div>
              </div>
              <div className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-[#22262c] text-center">
                <div className="text-[10px] text-slate-500">V / D</div>
                <div className="font-bold text-sm">
                  {player.wins}/{player.losses}
                </div>
              </div>
              <div className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-[#22262c] text-center">
                <div className="text-[10px] text-slate-500">Index</div>
                <div className="font-bold text-sm">
                  {getUniqueOwnedCards(player.inventory)}/15
                </div>
              </div>
            </div>
          </div>

          {bio && (
            <p className="text-sm text-slate-600 dark:text-slate-300 italic">« {bio} »</p>
          )}

          {/* Showcase (up to 3 cards) */}
          <div className="space-y-2">
            <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Vitrine publique ({showcase.length}/3 cartes épinglées)
            </div>
            {showcase.length === 0 ? (
              <div className="py-5 text-center text-xs text-slate-500 rounded-xl border border-dashed border-slate-200 dark:border-white/10">
                Épinglez jusqu’à 3 cartes ci-dessous dans l’onglet Personnalisation.
              </div>
            ) : (
              <div className="grid grid-cols-3 gap-3 max-w-xl">
                {showcase.map((cid) => (
                  <CardVisual key={`vitrine-${cid}`} cardId={cid} compact showStats={false} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 4 Sub-tabs */}
      <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-200/70 dark:bg-[#181b1f] border border-slate-200 dark:border-white/10 overflow-x-auto">
        {(
          [
            { id: 'personnalisation', label: 'Personnalisation', icon: <Palette className="w-3.5 h-3.5" /> },
            { id: 'succes', label: 'Succès (11)', icon: <Award className="w-3.5 h-3.5" /> },
            { id: 'boutique', label: 'Boutique', icon: <ShoppingBag className="w-3.5 h-3.5" /> },
            { id: 'parametres', label: 'Paramètres', icon: <Settings className="w-3.5 h-3.5" /> },
          ] as const
        ).map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => onChangeSubTab(t.id)}
            className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              subTab === t.id
                ? 'bg-white dark:bg-[#22262c] text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {t.icon}
            <span>{t.label}</span>
          </button>
        ))}
      </div>

      {/* Sub-tab 1: Personnalisation */}
      {subTab === 'personnalisation' && (
        <form
          onSubmit={handleSave}
          className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 sm:p-6 space-y-6"
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Pseudo joueur
              </label>
              <input
                type="text"
                maxLength={32}
                value={pseudo}
                onChange={(e) => setPseudo(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl text-sm border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] text-slate-900 dark:text-white"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Campus
              </label>
              <div className="grid grid-cols-2 gap-2">
                {(['Labbé', 'Marceau'] as const).map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setCampus(c)}
                    className={`py-2 rounded-xl text-xs font-semibold border cursor-pointer ${
                      campus === c
                        ? c === 'Labbé'
                          ? 'border-blue-500 bg-blue-500/15 text-blue-500'
                          : 'border-emerald-500 bg-emerald-500/15 text-emerald-500'
                        : 'border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    Site {c}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Classe / Filière
              </label>
              <button
                type="button"
                onClick={() => setClassModalOpen(true)}
                className="w-full flex items-center justify-between px-3.5 py-2 rounded-xl text-sm border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] text-slate-900 dark:text-white cursor-pointer"
              >
                <span className="truncate">{classe}</span>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Devise / Bio ({bio.length}/200)
            </label>
            <textarea
              maxLength={200}
              rows={2}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Votre devise de joueur au Lycée Jules Haag…"
              className="w-full px-3.5 py-2 rounded-xl text-sm border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] text-slate-900 dark:text-white"
            />
          </div>

          {/* Unlocked Cosmetics Equippers */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {(
              [
                { label: 'Emblème', kind: 'emblem', value: equippedEmblem, setter: setEquippedEmblem },
                { label: 'Cadre', kind: 'frame', value: equippedFrame, setter: setEquippedFrame },
                { label: 'Bannière', kind: 'banner', value: equippedBanner, setter: setEquippedBanner },
                { label: 'Titre', kind: 'title', value: equippedTitle, setter: setEquippedTitle },
              ] as const
            ).map((grp) => {
              const options = COSMETICS.filter(
                (c) => c.kind === grp.kind && (c.price === 0 && !c.exclusive || unlockedSet.has(c.id))
              );
              return (
                <div key={grp.kind} className="space-y-1.5">
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                    {grp.label}
                  </label>
                  <select
                    value={grp.value}
                    onChange={(e) => grp.setter(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl text-xs border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] text-slate-900 dark:text-white"
                  >
                    {options.map((opt) => (
                      <option key={opt.id} value={opt.id}>
                        {opt.symbol ? `${opt.symbol} ` : ''}
                        {opt.name}
                      </option>
                    ))}
                  </select>
                </div>
              );
            })}
          </div>

          {/* Showcase Picker */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              Cartes en Vitrine (max 3)
            </label>
            <div className="flex flex-wrap gap-2">
              {ownedCards.map((c) => {
                const pinned = showcase.includes(c.id);
                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => toggleShowcaseCard(c.id)}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border cursor-pointer ${
                      pinned
                        ? 'border-emerald-500 bg-emerald-500/15 text-emerald-600 dark:text-emerald-300'
                        : 'border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {pinned && <Check className="w-3.5 h-3.5" />}
                    <span>{c.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-sm font-semibold cursor-pointer"
            >
              {saving ? 'Enregistrement…' : 'Enregistrer le profil'}
            </button>
          </div>
        </form>
      )}

      {/* Sub-tab 2: 11 Succès */}
      {subTab === 'succes' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {ACHIEVEMENTS.map((ach) => {
            const prog = Math.min(ach.target, ach.getProgress(player, friendsCount));
            const pct = Math.round((prog / ach.target) * 100);
            const claimed = player.claimedAchievements.includes(ach.id);
            const ready = !claimed && prog >= ach.target;
            const bonusCosmetic = ach.rewardCosmeticId
              ? COSMETIC_BY_ID[ach.rewardCosmeticId]?.name
              : null;

            return (
              <div
                key={ach.id}
                className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-4 space-y-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400">
                      {ach.category}
                    </div>
                    <h3 className="text-sm font-display font-bold text-slate-900 dark:text-white">
                      {ach.title}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      {ach.description}
                    </p>
                  </div>
                  <div className="text-right font-mono-num text-xs shrink-0">
                    <div className="font-bold text-[#c8952d] dark:text-[#e2bb6b]">
                      +{ach.rewardCoins} ●
                    </div>
                    {bonusCosmetic && (
                      <div className="text-[10px] text-slate-500 dark:text-slate-400 font-sans">
                        + {bonusCosmetic}
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="h-2 rounded-full bg-slate-200 dark:bg-[#22262c] overflow-hidden">
                    <div
                      className="h-full bg-emerald-500 transition-all duration-300"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <div className="flex items-center justify-between text-[11px] font-mono-num text-slate-500 dark:text-slate-400">
                    <span>
                      {prog} / {ach.target}
                    </span>
                    {claimed ? (
                      <span className="text-emerald-500 font-sans font-semibold">Réclamé</span>
                    ) : ready ? (
                      <button
                        type="button"
                        disabled={busyId === ach.id}
                        onClick={async () => {
                          setBusyId(ach.id);
                          try {
                            await onClaimAchievement(ach.id);
                          } finally {
                            setBusyId(null);
                          }
                        }}
                        className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-sans font-semibold cursor-pointer"
                      >
                        Réclamer
                      </button>
                    ) : (
                      <span>{pct}%</span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Sub-tab 3: Boutique */}
      {subTab === 'boutique' && (
        <div className="space-y-6">
          {(
            [
              { title: 'Emblèmes (120–320 ●)', kind: 'emblem' },
              { title: 'Cadres (140–650 ●)', kind: 'frame' },
              { title: 'Bannières (180–420 ●)', kind: 'banner' },
            ] as const
          ).map((section) => (
            <div key={section.kind} className="space-y-3">
              <h2 className="text-base font-display font-bold text-slate-900 dark:text-white">
                {section.title}
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {COSMETICS.filter((c) => c.kind === section.kind && c.price > 0).map((item) => {
                  const owned = unlockedSet.has(item.id);
                  const isEquipped =
                    (item.kind === 'emblem' && player.equippedEmblem === item.id) ||
                    (item.kind === 'frame' && player.equippedFrame === item.id) ||
                    (item.kind === 'banner' && player.equippedBanner === item.id);

                  return (
                    <div
                      key={item.id}
                      className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-4 flex flex-col justify-between gap-3"
                    >
                      <div className="space-y-2">
                        {item.kind === 'banner' && (
                          <div className={`h-10 rounded-xl ${item.previewClass}`} />
                        )}
                        {item.kind === 'frame' && (
                          <div
                            className={`w-10 h-10 rounded-full bg-slate-800 ${item.previewClass}`}
                          />
                        )}
                        {item.kind === 'emblem' && (
                          <div className="text-2xl text-[#c8952d] dark:text-[#e2bb6b]">
                            {item.symbol}
                          </div>
                        )}
                        <div>
                          <div className="text-sm font-semibold text-slate-900 dark:text-white">
                            {item.name}
                          </div>
                          <div className="text-xs text-slate-500 dark:text-slate-400">
                            {item.description}
                          </div>
                        </div>
                      </div>

                      {owned ? (
                        <button
                          type="button"
                          disabled={isEquipped || busyId === item.id}
                          onClick={async () => {
                            setBusyId(item.id);
                            try {
                              await onUpdateProfile({
                                pseudo: player.pseudo,
                                campus: player.campus,
                                classe: player.classe,
                                bio: player.bio,
                                equippedEmblem:
                                  item.kind === 'emblem' ? item.id : player.equippedEmblem,
                                equippedFrame:
                                  item.kind === 'frame' ? item.id : player.equippedFrame,
                                equippedBanner:
                                  item.kind === 'banner' ? item.id : player.equippedBanner,
                                equippedTitle: player.equippedTitle,
                                showcase: player.showcase,
                              });
                            } finally {
                              setBusyId(null);
                            }
                          }}
                          className={`w-full py-2 rounded-xl text-xs font-semibold cursor-pointer ${
                            isEquipped
                              ? 'bg-emerald-500/15 text-emerald-500'
                              : 'bg-slate-100 dark:bg-[#22262c] text-slate-800 dark:text-white hover:bg-slate-200 dark:hover:bg-white/10'
                          }`}
                        >
                          {isEquipped ? 'Équipé' : 'Équiper'}
                        </button>
                      ) : (
                        <button
                          type="button"
                          disabled={player.coins < item.price || busyId === item.id}
                          onClick={async () => {
                            setBusyId(item.id);
                            try {
                              await onBuyCosmetic(item.id);
                            } finally {
                              setBusyId(null);
                            }
                          }}
                          className="w-full py-2 rounded-xl bg-[#c8952d] hover:bg-[#b58422] disabled:opacity-45 text-slate-950 font-mono-num font-bold text-xs cursor-pointer"
                        >
                          Acheter · {item.price} ●
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Sub-tab 4: Paramètres */}
      {subTab === 'parametres' && (
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 sm:p-6 space-y-4 max-w-xl">
          <h2 className="text-lg font-display font-bold text-slate-900 dark:text-white">
            Paramètres de l’application
          </h2>

          <div className="flex items-center justify-between p-4 rounded-xl bg-slate-50 dark:bg-[#22262c]">
            <div>
              <div className="text-sm font-semibold text-slate-900 dark:text-white">
                Apparence (Clair / Sombre)
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">
                Bascule instantanée entre le mode sombre et le mode clair.
              </div>
            </div>
            <button
              type="button"
              onClick={onToggleTheme}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] text-xs font-semibold cursor-pointer"
            >
              {darkMode ? <Moon className="w-4 h-4 text-blue-400" /> : <Sun className="w-4 h-4 text-amber-500" />}
              <span>{darkMode ? 'Mode sombre' : 'Mode clair'}</span>
            </button>
          </div>

          <div className="flex items-center justify-between p-4 rounded-xl bg-slate-50 dark:bg-[#22262c]">
            <div>
              <div className="text-sm font-semibold text-slate-900 dark:text-white">
                Effets sonores synthétisés
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400">
                Sons d’ouverture de paquets, tirages rares, duels et pièces.
              </div>
            </div>
            <button
              type="button"
              onClick={onToggleMute}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] text-xs font-semibold cursor-pointer"
            >
              {muted ? <VolumeX className="w-4 h-4 text-rose-500" /> : <Volume2 className="w-4 h-4 text-emerald-500" />}
              <span>{muted ? 'Désactivés' : 'Activés'}</span>
            </button>
          </div>

          <div className="pt-2 border-t border-slate-200 dark:border-white/10 flex justify-end">
            <button
              type="button"
              onClick={onSignOut}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>Se déconnecter</span>
            </button>
          </div>
        </div>
      )}

      <ClassSelectorModal
        open={classModalOpen}
        initialCampus={campus}
        selectedClass={classe}
        onSelect={(newClasse, newCampus) => {
          setClasse(newClasse);
          if (newCampus) setCampus(newCampus);
        }}
        onClose={() => setClassModalOpen(false)}
      />
    </div>
  );
}
