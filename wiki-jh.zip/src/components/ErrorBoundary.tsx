import React from 'react';

interface State {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  State
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error): State {
    return {
      hasError: true,
      message: error?.message || 'Une erreur inattendue est survenue.',
    };
  }

  render() {
    if (this.state.hasError) {
      let parsedMsg = this.state.message;
      try {
        const obj = JSON.parse(this.state.message);
        if (obj?.error) parsedMsg = obj.error;
      } catch {
        // plain error string
      }

      return (
        <div className="min-h-screen flex items-center justify-center p-6 bg-[#f6f8fa] dark:bg-[#111315] text-[#0f172a] dark:text-[#f1f5f9]">
          <div className="max-w-md w-full rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-6 shadow-xl space-y-4">
            <h1 className="text-xl font-bold font-display">
              Interruption momentanée
            </h1>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              Une opération réseau ou de synchronisation a rencontré une erreur :{' '}
              <span className="font-mono-num text-xs break-all text-rose-500 dark:text-rose-400">
                {parsedMsg}
              </span>
            </p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold transition-colors cursor-pointer"
            >
              Recharger l’application
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
