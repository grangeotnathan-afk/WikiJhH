import React, { useState } from 'react';
import { UserPlus, Check, X, Repeat, Trash2, Search, Clock } from 'lucide-react';
import type { Friendship, PlayerProfile } from '../types/game';
import { COSMETIC_BY_ID } from '../data/cosmeticsAndAchievements';

interface FriendsPageProps {
  player: PlayerProfile;
  allPlayers: PlayerProfile[];
  friendships: Friendship[];
  onSendRequest: (target: PlayerProfile) => Promise<void>;
  onAcceptRequest: (friendship: Friendship) => Promise<void>;
  onRemoveFriendship: (friendship: Friendship) => Promise<void>;
  onStartTradeWith: (friendUid: string) => void;
  onInspectPlayer: (target: PlayerProfile) => void;
}

export function FriendsPage({
  player,
  allPlayers,
  friendships,
  onSendRequest,
  onAcceptRequest,
  onRemoveFriendship,
  onStartTradeWith,
  onInspectPlayer,
}: FriendsPageProps) {
  const [search, setSearch] = useState('');
  const [busyId, setBusyId] = useState<string | null>(null);

  const playerMap: Record<string, PlayerProfile> = {};
  for (const p of allPlayers) playerMap[p.uid] = p;

  const receivedRequests = friendships.filter(
    (f) => f.status === 'pending' && f.recipientId === player.uid
  );
  const sentRequests = friendships.filter(
    (f) => f.status === 'pending' && f.requesterId === player.uid
  );
  const acceptedFriendships = friendships.filter((f) => f.status === 'accepted');

  const connectedUids = new Set(
    friendships.flatMap((f) => f.users)
  );
  connectedUids.add(player.uid);

  const searchResults = allPlayers
    .filter((p) => {
      if (connectedUids.has(p.uid)) return false;
      const q = search.trim().toLowerCase();
      if (!q) return true;
      return `${p.pseudo} ${p.campus} ${p.classe}`.toLowerCase().includes(q);
    })
    .slice(0, 12);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 space-y-6 pb-24 md:pb-10">
      <div>
        <h1 className="text-2xl sm:text-3xl font-display font-bold text-slate-900 dark:text-white">
          Amis
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Retrouvez vos camarades des sites Labbé et Marceau pour échanger des cartes et consulter leurs vitrines.
        </p>
      </div>

      {/* Received Requests */}
      {receivedRequests.length > 0 && (
        <div className="rounded-2xl border border-emerald-500/30 bg-emerald-500/5 p-5 space-y-3">
          <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
            Demandes reçues ({receivedRequests.length})
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {receivedRequests.map((req) => {
              const sender = playerMap[req.requesterId];
              if (!sender) return null;
              return (
                <div
                  key={req.id}
                  className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-3.5 flex items-center justify-between gap-3"
                >
                  <div>
                    <div className="text-sm font-semibold text-slate-900 dark:text-white">
                      {sender.pseudo}
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      {sender.campus} · {sender.classe}
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      disabled={busyId === req.id}
                      onClick={async () => {
                        setBusyId(req.id);
                        try {
                          await onAcceptRequest(req);
                        } finally {
                          setBusyId(null);
                        }
                      }}
                      className="p-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer"
                      title="Accepter"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      disabled={busyId === req.id}
                      onClick={async () => {
                        setBusyId(req.id);
                        try {
                          await onRemoveFriendship(req);
                        } finally {
                          setBusyId(null);
                        }
                      }}
                      className="p-2 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-500 cursor-pointer"
                      title="Refuser"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* My Friends */}
      <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 space-y-4">
        <h2 className="text-base font-display font-bold text-slate-900 dark:text-white">
          Mes amis ({acceptedFriendships.length})
        </h2>

        {acceptedFriendships.length === 0 ? (
          <div className="py-6 text-center text-sm text-slate-500 dark:text-slate-400">
            Vous n’avez pas encore d’amis. Recherchez un joueur ci-dessous !
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {acceptedFriendships.map((f) => {
              const otherUid = f.users.find((u) => u !== player.uid) || '';
              const friend = playerMap[otherUid];
              if (!friend) return null;
              const emblem = COSMETIC_BY_ID[friend.equippedEmblem]?.symbol || '◆';
              const frameCls =
                COSMETIC_BY_ID[friend.equippedFrame]?.previewClass || 'ring-2 ring-slate-400/40';
              return (
                <div
                  key={f.id}
                  className="rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] p-3.5 flex items-center justify-between gap-3"
                >
                  <button
                    type="button"
                    onClick={() => onInspectPlayer(friend)}
                    className="flex items-center gap-3 text-left min-w-0 cursor-pointer"
                  >
                    <div
                      className={`w-10 h-10 rounded-full bg-slate-800 text-[#e2bb6b] flex items-center justify-center font-bold shrink-0 ${frameCls}`}
                    >
                      {emblem}
                    </div>
                    <div className="min-w-0">
                      <div className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                        {friend.pseudo}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                        {friend.campus} · <span className="font-mono-num">{friend.elo} ELO</span>
                      </div>
                    </div>
                  </button>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => onStartTradeWith(friend.uid)}
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold cursor-pointer"
                    >
                      <Repeat className="w-3.5 h-3.5" />
                      <span>Échanger</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onRemoveFriendship(f)}
                      className="p-2 rounded-xl border border-slate-200 dark:border-white/10 text-slate-500 hover:text-rose-500 cursor-pointer"
                      title="Retirer cet ami"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Sent Invitations */}
      {sentRequests.length > 0 && (
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 space-y-3">
          <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
            Invitations envoyées ({sentRequests.length})
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {sentRequests.map((req) => {
              const target = playerMap[req.recipientId];
              if (!target) return null;
              return (
                <div
                  key={req.id}
                  className="rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] p-3 flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-200">
                    <Clock className="w-3.5 h-3.5 text-amber-500" />
                    <span className="font-semibold">{target.pseudo}</span>
                    <span className="text-slate-400">· {target.campus}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => onRemoveFriendship(req)}
                    className="text-xs text-rose-500 hover:underline cursor-pointer"
                  >
                    Annuler
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Add a Friend */}
      <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <h2 className="text-base font-display font-bold text-slate-900 dark:text-white">
            Ajouter un ami
          </h2>
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Pseudo, site ou classe…"
              className="w-full pl-9 pr-3 py-2 rounded-xl text-sm border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] text-slate-900 dark:text-white"
            />
          </div>
        </div>

        {searchResults.length === 0 ? (
          <div className="py-6 text-center text-xs text-slate-500 dark:text-slate-400">
            Aucun joueur trouvé.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {searchResults.map((target) => (
              <div
                key={target.uid}
                className="rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] p-3.5 flex items-center justify-between gap-2"
              >
                <button
                  type="button"
                  onClick={() => onInspectPlayer(target)}
                  className="text-left min-w-0 cursor-pointer"
                >
                  <div className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                    {target.pseudo}
                  </div>
                  <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                    {target.campus} · {target.classe}
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => onSendRequest(target)}
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shrink-0 cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Inviter</span>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
