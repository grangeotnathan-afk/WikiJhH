import React, { useState } from 'react';
import { Search, Check, X, ChevronRight } from 'lucide-react';
import type { Campus } from '../types/game';
import { CARD_BY_ID, CLASSES_BY_CAMPUS } from '../data/cards';
import { CardImage } from './CardVisual';

interface ClassSelectorModalProps {
  open: boolean;
  initialCampus?: Campus;
  selectedClass: string;
  onSelect: (classe: string, campus?: Campus) => void;
  onClose: () => void;
}

export function ClassSelectorModal({
  open,
  initialCampus,
  selectedClass,
  onSelect,
  onClose,
}: ClassSelectorModalProps) {
  const [campusFilter, setCampusFilter] = useState<'Tous' | Campus>(initialCampus || 'Tous');
  const [query, setQuery] = useState('');

  if (!open) return null;

  const groups = CLASSES_BY_CAMPUS.filter(
    (g) => campusFilter === 'Tous' || g.campus === campusFilter
  )
    .map((g) => ({
      ...g,
      items: g.items.filter((item) =>
        item.toLowerCase().includes(query.trim().toLowerCase())
      ),
    }))
    .filter((g) => g.items.length > 0);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-xl rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 shadow-2xl space-y-4 max-h-[85vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-display font-bold text-slate-900 dark:text-white">
              Sélecteur de Classe & Filière
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Choisissez votre formation ou équipe au Lycée Jules Haag
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-white/5 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Campus Filter */}
        <div className="flex flex-col sm:flex-row gap-2.5">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Rechercher STI2D, BTS CIEL, Horlogerie..."
              className="w-full pl-9 pr-3 py-2 rounded-xl text-sm border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
          <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-100 dark:bg-[#22262c] shrink-0">
            {(['Tous', 'Labbé', 'Marceau'] as const).map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setCampusFilter(c)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                  campusFilter === c
                    ? 'bg-white dark:bg-[#181b1f] text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        {/* List */}
        <div className="overflow-y-auto space-y-4 pr-1">
          {groups.length === 0 ? (
            <div className="py-8 text-center text-sm text-slate-500 dark:text-slate-400">
              Aucune classe ne correspond à votre recherche.
            </div>
          ) : (
            groups.map((group) => (
              <div key={`${group.campus}-${group.label}`} className="space-y-2">
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 dark:text-slate-400">
                  <span
                    className={
                      group.campus === 'Labbé'
                        ? 'text-blue-600 dark:text-blue-400'
                        : 'text-emerald-600 dark:text-emerald-400'
                    }
                  >
                    Site {group.campus}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>{group.label}</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {group.items.map((item) => {
                    const active = selectedClass === item;
                    return (
                      <button
                        key={`${group.campus}-${item}`}
                        type="button"
                        onClick={() => {
                          onSelect(item, group.campus);
                          onClose();
                        }}
                        className={`flex items-center justify-between px-3 py-2.5 rounded-xl border text-left text-sm font-medium transition-colors cursor-pointer ${
                          active
                            ? 'border-emerald-500 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
                            : 'border-slate-200 dark:border-white/10 bg-slate-50/70 dark:bg-[#22262c]/70 text-slate-800 dark:text-slate-200 hover:border-slate-300 dark:hover:border-white/25'
                        }`}
                      >
                        <span className="truncate">{item}</span>
                        {active && <Check className="w-4 h-4 text-emerald-500 shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

interface WelcomeScreenProps {
  onSignIn: () => void;
  loading: boolean;
  authError: string | null;
}

export function WelcomeScreen({ onSignIn, loading, authError }: WelcomeScreenProps) {
  return (
    <div className="min-h-screen flex items-center justify-center p-4 sm:p-8 bg-[#f6f8fa] dark:bg-[#111315]">
      <div className="w-full max-w-5xl rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] shadow-2xl overflow-hidden grid grid-cols-1 lg:grid-cols-2 items-stretch">
        {/* Left: Editorial Copy & Google Sign-In */}
        <div className="p-7 sm:p-10 lg:p-12 flex flex-col justify-between space-y-8">
          <div className="space-y-5">
            <div className="inline-flex items-center gap-2 text-sm font-semibold text-[#c8952d] dark:text-[#e2bb6b]">
              <span>◆</span>
              <span>Wiki JH · Besançon</span>
            </div>

            <h1 className="text-3xl sm:text-4xl font-display font-bold text-slate-900 dark:text-white leading-tight [text-wrap:balance]">
              L’arène des cartes du Lycée Jules Haag
            </h1>

            <p className="text-base text-slate-600 dark:text-slate-300 leading-relaxed">
              Ouvrez vos boosters gratuits, collectionnez les 15 cartes emblématiques des sites Labbé et Marceau, négociez au marché des élèves et défiez vos camarades en duel tactique.
            </p>

            <div className="grid grid-cols-2 gap-3 pt-2 text-xs text-slate-600 dark:text-slate-400">
              <div className="rounded-xl border border-blue-500/20 bg-blue-500/5 p-3">
                <div className="font-semibold text-blue-600 dark:text-blue-400">Site Labbé</div>
                <div className="mt-0.5">Générale · STI2D · BTS · CPGE</div>
              </div>
              <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/5 p-3">
                <div className="font-semibold text-emerald-600 dark:text-emerald-400">Site Marceau</div>
                <div className="mt-0.5">CAP · Bac Pro · BMA</div>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            {authError && (
              <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-2.5 text-xs text-rose-600 dark:text-rose-400">
                {authError}
              </div>
            )}

            <button
              type="button"
              disabled={loading}
              onClick={onSignIn}
              className="w-full flex items-center justify-center gap-3 px-6 py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-60 text-white font-semibold text-sm shadow-lg shadow-emerald-900/20 transition-all cursor-pointer"
            >
              <svg className="w-5 h-5 bg-white rounded-full p-0.5" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17Z"
                />
                <path
                  fill="#34A853"
                  d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.11-6.72-4.96H1.29v3.14C3.26 21.3 7.37 24 12 24Z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.28 14.24c-.24-.72-.38-1.49-.38-2.24s.14-1.52.38-2.24V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.99-3.14Z"
                />
                <path
                  fill="#EA4335"
                  d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.37 0 3.26 2.7 1.29 6.62l3.99 3.14c.95-2.85 3.6-4.96 6.72-4.96Z"
                />
              </svg>
              <span>{loading ? 'Connexion en cours…' : 'Se connecter avec Google'}</span>
            </button>

            <p className="text-xs text-center text-slate-500 dark:text-slate-400">
              100 % gratuit et virtuel · Démarrage immédiat avec 10 paquets offerts
            </p>
          </div>
        </div>

        {/* Right: Dual Facade Showcase */}
        <div className="grid grid-rows-2 bg-slate-900 min-h-[340px]">
          <div className="relative overflow-hidden">
            <CardImage
              src={CARD_BY_ID.site_labbe.image}
              alt="Façade du Site Labbé — Lycée Jules Haag"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-transparent" />
            <div className="absolute bottom-3 left-4 right-4 flex items-end justify-between text-white">
              <div>
                <div className="text-xs font-semibold text-blue-400">Campus Labbé</div>
                <div className="text-sm font-display font-bold">Voie Générale, STI2D, BTS & CPGE</div>
              </div>
            </div>
          </div>
          <div className="relative overflow-hidden border-t border-white/10">
            <CardImage
              src={CARD_BY_ID.site_marceau.image}
              alt="Façade du Site Marceau — Lycée Jules Haag"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-transparent" />
            <div className="absolute bottom-3 left-4 right-4 flex items-end justify-between text-white">
              <div>
                <div className="text-xs font-semibold text-emerald-400">Campus Marceau</div>
                <div className="text-sm font-display font-bold">Lycée Professionnel (CAP, Bac Pro, BMA)</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

interface OnboardingScreenProps {
  defaultPseudo: string;
  onComplete: (data: { pseudo: string; campus: Campus; classe: string }) => Promise<void>;
  onSignOut: () => void;
}

export function OnboardingScreen({
  defaultPseudo,
  onComplete,
  onSignOut,
}: OnboardingScreenProps) {
  const [campus, setCampus] = useState<Campus>('Labbé');
  const [pseudo, setPseudo] = useState(defaultPseudo.slice(0, 32));
  const [classe, setClasse] = useState('Term. STI2D');
  const [classModalOpen, setClassModalOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = pseudo.trim();
    if (trimmed.length < 2 || trimmed.length > 32) {
      setError('Votre pseudo doit contenir entre 2 et 32 caractères.');
      return;
    }
    if (!classe.trim()) {
      setError('Veuillez sélectionner votre classe ou filière.');
      return;
    }
    setError(null);
    setSubmitting(true);
    try {
      await onComplete({ pseudo: trimmed, campus, classe: classe.trim() });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erreur lors de la création du profil.');
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 sm:p-8 bg-[#f6f8fa] dark:bg-[#111315]">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-2xl rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-6 sm:p-8 shadow-2xl space-y-6"
      >
        <div className="flex items-start justify-between gap-4">
          <div>
            <span className="text-xs font-semibold text-[#c8952d] dark:text-[#e2bb6b]">
              ◆ Bienvenue sur Wiki JH
            </span>
            <h1 className="text-2xl sm:text-3xl font-display font-bold text-slate-900 dark:text-white mt-1">
              Créez votre profil de joueur
            </h1>
            <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
              Démarrez avec 10 paquets gratuits, 3 cartes de départ et 1000 ELO pour défendre votre site.
            </p>
          </div>
          <button
            type="button"
            onClick={onSignOut}
            className="text-xs text-slate-500 hover:text-slate-900 dark:hover:text-white underline cursor-pointer shrink-0"
          >
            Changer de compte
          </button>
        </div>

        {/* Visual Campus Selection */}
        <div className="space-y-2">
          <label className="block text-sm font-semibold text-slate-800 dark:text-slate-200">
            1. Choisissez votre campus
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {(
              [
                {
                  id: 'Labbé' as Campus,
                  img: CARD_BY_ID.site_labbe.image,
                  sub: 'Voie Générale, STI2D, BTS & CPGE',
                  accent: 'border-blue-500 ring-2 ring-blue-500/30',
                  badge: 'text-blue-400',
                },
                {
                  id: 'Marceau' as Campus,
                  img: CARD_BY_ID.site_marceau.image,
                  sub: 'CAP, Bac Pro, BMA',
                  accent: 'border-emerald-500 ring-2 ring-emerald-500/30',
                  badge: 'text-emerald-400',
                },
              ] as const
            ).map((opt) => {
              const active = campus === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => {
                    setCampus(opt.id);
                    setClasse(opt.id === 'Labbé' ? 'Term. STI2D' : 'Bac Pro CIEL');
                  }}
                  className={`relative rounded-2xl overflow-hidden border-2 text-left transition-all cursor-pointer ${
                    active
                      ? opt.accent
                      : 'border-slate-200 dark:border-white/10 opacity-80 hover:opacity-100'
                  }`}
                >
                  <div className="aspect-[16/9] relative">
                    <CardImage
                      src={opt.img}
                      alt={`Site ${opt.id}`}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent" />
                    <div className="absolute bottom-2.5 left-3 right-3 text-white">
                      <div className={`text-xs font-bold ${opt.badge}`}>Site {opt.id}</div>
                      <div className="text-xs text-slate-200 mt-0.5">{opt.sub}</div>
                    </div>
                    {active && (
                      <div className="absolute top-2.5 right-2.5 w-6 h-6 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center shadow">
                        <Check className="w-4 h-4" />
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Pseudo & Class */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label
              htmlFor="onboarding-pseudo"
              className="block text-sm font-semibold text-slate-800 dark:text-slate-200"
            >
              2. Pseudo joueur
            </label>
            <input
              id="onboarding-pseudo"
              type="text"
              maxLength={32}
              value={pseudo}
              onChange={(e) => setPseudo(e.target.value)}
              placeholder="Ex. Chronos25"
              className="w-full px-3.5 py-2.5 rounded-xl text-sm border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
            <div className="text-[11px] text-slate-500 dark:text-slate-400">
              {pseudo.trim().length}/32 caractères
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="block text-sm font-semibold text-slate-800 dark:text-slate-200">
              3. Classe & Filière
            </label>
            <button
              type="button"
              onClick={() => setClassModalOpen(true)}
              className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] text-slate-900 dark:text-white hover:border-emerald-500/60 transition-colors cursor-pointer"
            >
              <span className="truncate">{classe}</span>
              <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
            </button>
            <div className="text-[11px] text-slate-500 dark:text-slate-400">
              Filtrable par campus et recherche
            </div>
          </div>
        </div>

        {/* Starter Pack Info */}
        <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] p-3.5 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600 dark:text-slate-300">
          <span>Dotation de départ :</span>
          <div className="flex items-center gap-3 font-mono-num font-semibold text-slate-900 dark:text-white">
            <span>10 Paquets</span>
            <span aria-hidden="true">·</span>
            <span>0 ●</span>
            <span aria-hidden="true">·</span>
            <span>3 Cartes</span>
            <span aria-hidden="true">·</span>
            <span>1000 ELO</span>
          </div>
        </div>

        {error && (
          <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-2.5 text-xs text-rose-600 dark:text-rose-400">
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="w-full py-3.5 px-6 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold text-sm shadow-lg shadow-emerald-900/20 transition-colors cursor-pointer"
        >
          {submitting ? 'Initialisation du profil…' : 'Entrer dans l’arène Wiki JH'}
        </button>
      </form>

      <ClassSelectorModal
        open={classModalOpen}
        initialCampus={campus}
        selectedClass={classe}
        onSelect={(newClasse, newCampus) => {
          setClasse(newClasse);
          if (newCampus) setCampus(newCampus);
        }}
        onClose={() => setClassModalOpen(false)}
      />
    </div>
  );
}
