import React, { useState, useEffect } from 'react';
import { ShieldAlert, Search, Trash2, UserCheck, UserMinus, RefreshCw } from 'lucide-react';
import type { AdminRecord, Campus, CardId, PlayerProfile } from '../types/game';
import { CARDS, EMPTY_INVENTORY, ALL_CARD_IDS } from '../data/cards';
import { SUPER_ADMIN_EMAILS } from '../firebase';

interface AdminPageProps {
  currentUid: string;
  isSuperAdmin: boolean;
  allPlayers: PlayerProfile[];
  promotedAdmins: AdminRecord[];
  onAdminUpdatePlayer: (targetUid: string, patch: Partial<PlayerProfile>) => Promise<void>;
  onAdminDeletePlayer: (targetUid: string) => Promise<void>;
  onPromoteAdmin: (target: PlayerProfile) => Promise<void>;
  onRevokeAdmin: (targetUid: string) => Promise<void>;
}

export function AdminPage({
  currentUid,
  isSuperAdmin,
  allPlayers,
  promotedAdmins,
  onAdminUpdatePlayer,
  onAdminDeletePlayer,
  onPromoteAdmin,
  onRevokeAdmin,
}: AdminPageProps) {
  const [search, setSearch] = useState('');
  const [selectedUid, setSelectedUid] = useState<string>(allPlayers[0]?.uid || currentUid);
  const [exactCoins, setExactCoins] = useState('');
  const [exactPacks, setExactPacks] = useState('');
  const [busy, setBusy] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  const selected = allPlayers.find((p) => p.uid === selectedUid) || allPlayers[0] || null;

  const [editPseudo, setEditPseudo] = useState('');
  const [editCampus, setEditCampus] = useState<Campus>('Labbé');
  const [editClasse, setEditClasse] = useState('');
  const [editElo, setEditElo] = useState('1000');
  const [editCoins, setEditCoins] = useState('0');
  const [editPacks, setEditPacks] = useState('0');
  const [editWins, setEditWins] = useState('0');
  const [editLosses, setEditLosses] = useState('0');

  useEffect(() => {
    if (!selected) return;
    setEditPseudo(selected.pseudo);
    setEditCampus(selected.campus);
    setEditClasse(selected.classe);
    setEditElo(String(selected.elo));
    setEditCoins(String(selected.coins));
    setEditPacks(String(selected.packs));
    setEditWins(String(selected.wins));
    setEditLosses(String(selected.losses));
    setConfirmDelete(false);
  }, [selected?.uid, selected?.updatedAt]);

  const filteredPlayers = allPlayers.filter((p) =>
    `${p.pseudo} ${p.campus} ${p.classe} ${p.uid}`
      .toLowerCase()
      .includes(search.trim().toLowerCase())
  );

  const adminUidSet = new Set(promotedAdmins.map((a) => a.uid));

  const mutate = async (patch: Partial<PlayerProfile>) => {
    if (!selected || busy) return;
    setBusy(true);
    try {
      await onAdminUpdatePlayer(selected.uid, patch);
    } finally {
      setBusy(false);
    }
  };

  const adjustCard = async (cardId: CardId, delta: number) => {
    if (!selected || busy) return;
    const nextInv = { ...selected.inventory };
    nextInv[cardId] = Math.max(0, (nextInv[cardId] || 0) + delta);
    const nextDisc = new Set(selected.discoveredCards);
    if (nextInv[cardId] > 0) nextDisc.add(cardId);
    await mutate({
      inventory: nextInv,
      discoveredCards: Array.from(nextDisc),
      deck: selected.deck.filter((id) => (nextInv[id] || 0) > 0),
      showcase: selected.showcase.filter((id) => (nextInv[id] || 0) > 0),
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6 pb-24 md:pb-10">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-500 flex items-center justify-center">
          <ShieldAlert className="w-5 h-5" />
        </div>
        <div>
          <h1 className="text-2xl sm:text-3xl font-display font-bold text-slate-900 dark:text-white">
            Panneau d’Administration
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Gestion des joueurs, dotations gratuites, inventaires et registre des administrateurs.
          </p>
        </div>
      </div>

      {/* Admin Registry */}
      <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 space-y-3">
        <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
          Registre des administrateurs
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          <div className="rounded-xl bg-slate-50 dark:bg-[#22262c] p-3 space-y-1">
            <div className="font-semibold text-[#c8952d] dark:text-[#e2bb6b]">
              Super-Admins principaux
            </div>
            {SUPER_ADMIN_EMAILS.map((email) => (
              <div key={email} className="font-mono-num text-slate-700 dark:text-slate-200">
                {email}
              </div>
            ))}
          </div>
          <div className="rounded-xl bg-slate-50 dark:bg-[#22262c] p-3 space-y-1">
            <div className="font-semibold text-emerald-600 dark:text-emerald-400">
              Administrateurs promus ({promotedAdmins.length})
            </div>
            {promotedAdmins.length === 0 ? (
              <div className="text-slate-500">Aucun administrateur promu.</div>
            ) : (
              promotedAdmins.map((a) => (
                <div key={a.uid} className="flex items-center justify-between">
                  <span className="text-slate-700 dark:text-slate-200">{a.pseudo}</span>
                  {isSuperAdmin && (
                    <button
                      type="button"
                      onClick={() => onRevokeAdmin(a.uid)}
                      className="text-rose-500 hover:underline cursor-pointer"
                    >
                      Retirer
                    </button>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Player Selector */}
        <div className="lg:col-span-4 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-4 space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Chercher un joueur…"
              className="w-full pl-9 pr-3 py-2 rounded-xl text-xs border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c] text-slate-900 dark:text-white"
            />
          </div>

          <div className="max-h-[420px] overflow-y-auto space-y-1.5 pr-1">
            {filteredPlayers.map((p) => (
              <button
                key={p.uid}
                type="button"
                onClick={() => setSelectedUid(p.uid)}
                className={`w-full p-2.5 rounded-xl text-left text-xs transition-colors cursor-pointer ${
                  selected?.uid === p.uid
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-50 dark:bg-[#22262c] text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/10'
                }`}
              >
                <div className="font-semibold truncate">{p.pseudo}</div>
                <div className="opacity-75 font-mono-num truncate">
                  {p.campus} · {p.coins} ● · {p.packs} pq · {p.elo} ELO
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Selected Player Actions */}
        {selected && (
          <div className="lg:col-span-8 space-y-5">
            {/* Quick Coins & Packs */}
            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h2 className="text-base font-display font-bold text-slate-900 dark:text-white">
                  Actions sur {selected.pseudo}
                </h2>
                <div className="flex items-center gap-2">
                  {isSuperAdmin && selected.uid !== currentUid && (
                    adminUidSet.has(selected.uid) ? (
                      <button
                        type="button"
                        onClick={() => onRevokeAdmin(selected.uid)}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl border border-amber-500/30 text-amber-500 text-xs font-semibold cursor-pointer"
                      >
                        <UserMinus className="w-3.5 h-3.5" />
                        <span>Retirer Admin</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => onPromoteAdmin(selected)}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-500 text-xs font-semibold cursor-pointer"
                      >
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>Promouvoir Admin</span>
                      </button>
                    )
                  )}
                </div>
              </div>

              {/* Coins */}
              <div className="space-y-2">
                <div className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                  Pièces (actuel : <span className="font-mono-num">{selected.coins} ●</span>)
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  {[100, 1000, 10000, -100].map((delta) => (
                    <button
                      key={delta}
                      type="button"
                      disabled={busy}
                      onClick={() =>
                        mutate({ coins: Math.max(0, selected.coins + delta) })
                      }
                      className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-[#22262c] hover:bg-slate-200 dark:hover:bg-white/10 font-mono-num text-xs font-bold cursor-pointer"
                    >
                      {delta > 0 ? `+${delta}` : delta} ●
                    </button>
                  ))}
                  <input
                    type="number"
                    placeholder="Montant exact"
                    value={exactCoins}
                    onChange={(e) => setExactCoins(e.target.value)}
                    className="w-32 px-2.5 py-1.5 rounded-xl text-xs font-mono-num border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c]"
                  />
                  <button
                    type="button"
                    disabled={busy || exactCoins.trim() === ''}
                    onClick={() => {
                      mutate({
                        coins: Math.min(100000000, Math.max(0, Math.floor(Number(exactCoins) || 0))),
                      });
                      setExactCoins('');
                    }}
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-semibold cursor-pointer"
                  >
                    Définir
                  </button>
                </div>
              </div>

              {/* Packs */}
              <div className="space-y-2">
                <div className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                  Paquets (actuel : <span className="font-mono-num">{selected.packs}</span>)
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  {[1, 5, 10, 50].map((delta) => (
                    <button
                      key={delta}
                      type="button"
                      disabled={busy}
                      onClick={() =>
                        mutate({ packs: Math.min(100000, selected.packs + delta) })
                      }
                      className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-[#22262c] hover:bg-slate-200 dark:hover:bg-white/10 font-mono-num text-xs font-bold cursor-pointer"
                    >
                      +{delta} pq
                    </button>
                  ))}
                  <input
                    type="number"
                    placeholder="Nb exact"
                    value={exactPacks}
                    onChange={(e) => setExactPacks(e.target.value)}
                    className="w-28 px-2.5 py-1.5 rounded-xl text-xs font-mono-num border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c]"
                  />
                  <button
                    type="button"
                    disabled={busy || exactPacks.trim() === ''}
                    onClick={() => {
                      mutate({
                        packs: Math.min(100000, Math.max(0, Math.floor(Number(exactPacks) || 0))),
                      });
                      setExactPacks('');
                    }}
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-semibold cursor-pointer"
                  >
                    Définir
                  </button>
                </div>
              </div>
            </div>

            {/* 15 Cards Inventory Control */}
            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                  Inventaire des 15 cartes
                </h3>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => {
                      const fullInv = { ...selected.inventory };
                      for (const cid of ALL_CARD_IDS) {
                        fullInv[cid] = Math.max(1, fullInv[cid] || 0);
                      }
                      mutate({
                        inventory: fullInv,
                        discoveredCards: [...ALL_CARD_IDS],
                      });
                    }}
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-semibold cursor-pointer"
                  >
                    Toutes les cartes ×1
                  </button>
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() =>
                      mutate({
                        inventory: { ...EMPTY_INVENTORY },
                        deck: [],
                        showcase: [],
                      })
                    }
                    className="px-3 py-1.5 rounded-xl border border-rose-500/30 text-rose-500 text-xs font-semibold cursor-pointer"
                  >
                    Vider l’inventaire
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-72 overflow-y-auto pr-1">
                {CARDS.map((c) => {
                  const qty = selected.inventory[c.id] || 0;
                  return (
                    <div
                      key={c.id}
                      className="flex items-center justify-between px-3 py-2 rounded-xl bg-slate-50 dark:bg-[#22262c] text-xs"
                    >
                      <div className="min-w-0">
                        <span className="font-semibold truncate block">{c.name}</span>
                        <span className="font-mono-num text-slate-500">
                          {c.rarity} · ×{qty}
                        </span>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() => adjustCard(c.id, -1)}
                          className="px-2 py-1 rounded bg-white dark:bg-[#181b1f] font-mono-num cursor-pointer disabled:opacity-50"
                        >
                          -1
                        </button>
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() => adjustCard(c.id, 1)}
                          className="px-2 py-1 rounded bg-white dark:bg-[#181b1f] font-mono-num cursor-pointer disabled:opacity-50"
                        >
                          +1
                        </button>
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() => adjustCard(c.id, 5)}
                          className="px-2 py-1 rounded bg-white dark:bg-[#181b1f] font-mono-num cursor-pointer disabled:opacity-50"
                        >
                          +5
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Full Profile Edit & Delete */}
            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#181b1f] p-5 space-y-4">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Édition complète du profil
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div>
                  <label className="block mb-1 text-slate-500">Pseudo</label>
                  <input
                    type="text"
                    maxLength={32}
                    value={editPseudo}
                    onChange={(e) => setEditPseudo(e.target.value)}
                    className="w-full px-2.5 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c]"
                  />
                </div>
                <div>
                  <label className="block mb-1 text-slate-500">Site</label>
                  <select
                    value={editCampus}
                    onChange={(e) => setEditCampus(e.target.value as Campus)}
                    className="w-full px-2.5 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c]"
                  >
                    <option value="Labbé">Labbé</option>
                    <option value="Marceau">Marceau</option>
                  </select>
                </div>
                <div>
                  <label className="block mb-1 text-slate-500">Classe</label>
                  <input
                    type="text"
                    maxLength={48}
                    value={editClasse}
                    onChange={(e) => setEditClasse(e.target.value)}
                    className="w-full px-2.5 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c]"
                  />
                </div>
                <div>
                  <label className="block mb-1 text-slate-500">ELO</label>
                  <input
                    type="number"
                    value={editElo}
                    onChange={(e) => setEditElo(e.target.value)}
                    className="w-full px-2.5 py-2 rounded-xl font-mono-num border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c]"
                  />
                </div>
                <div>
                  <label className="block mb-1 text-slate-500">Pièces ●</label>
                  <input
                    type="number"
                    value={editCoins}
                    onChange={(e) => setEditCoins(e.target.value)}
                    className="w-full px-2.5 py-2 rounded-xl font-mono-num border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c]"
                  />
                </div>
                <div>
                  <label className="block mb-1 text-slate-500">Paquets</label>
                  <input
                    type="number"
                    value={editPacks}
                    onChange={(e) => setEditPacks(e.target.value)}
                    className="w-full px-2.5 py-2 rounded-xl font-mono-num border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c]"
                  />
                </div>
                <div>
                  <label className="block mb-1 text-slate-500">Victoires</label>
                  <input
                    type="number"
                    value={editWins}
                    onChange={(e) => setEditWins(e.target.value)}
                    className="w-full px-2.5 py-2 rounded-xl font-mono-num border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c]"
                  />
                </div>
                <div>
                  <label className="block mb-1 text-slate-500">Défaites</label>
                  <input
                    type="number"
                    value={editLosses}
                    onChange={(e) => setEditLosses(e.target.value)}
                    className="w-full px-2.5 py-2 rounded-xl font-mono-num border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#22262c]"
                  />
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-200 dark:border-white/10">
                {selected.uid !== currentUid ? (
                  confirmDelete ? (
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={async () => {
                          await onAdminDeletePlayer(selected.uid);
                          setConfirmDelete(false);
                        }}
                        className="px-3 py-2 rounded-xl bg-rose-600 text-white text-xs font-semibold cursor-pointer"
                      >
                        Confirmer suppression définitive
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmDelete(false)}
                        className="text-xs text-slate-500 cursor-pointer"
                      >
                        Annuler
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setConfirmDelete(true)}
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-rose-500/30 text-rose-500 text-xs font-semibold cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Supprimer le compte</span>
                    </button>
                  )
                ) : (
                  <div />
                )}

                <button
                  type="button"
                  disabled={busy}
                  onClick={() => {
                    const cleanPseudo = editPseudo.trim().slice(0, 32);
                    const cleanClasse = editClasse.trim().slice(0, 48);
                    mutate({
                      pseudo: cleanPseudo.length >= 2 ? cleanPseudo : selected.pseudo,
                      campus: editCampus,
                      classe: cleanClasse.length >= 2 ? cleanClasse : selected.classe,
                      elo: Math.min(10000, Math.max(0, Math.floor(Number(editElo) || 0))),
                      coins: Math.min(100000000, Math.max(0, Math.floor(Number(editCoins) || 0))),
                      packs: Math.min(100000, Math.max(0, Math.floor(Number(editPacks) || 0))),
                      wins: Math.min(100000, Math.max(0, Math.floor(Number(editWins) || 0))),
                      losses: Math.min(100000, Math.max(0, Math.floor(Number(editLosses) || 0))),
                    });
                  }}
                  className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Synchroniser la fiche</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
