# Security Specification — Wiki JH (Lycée Jules Haag TCG)

## 1. Data Invariants
1. A Player document at `/players/{uid}` can only be created by the verified authenticated user (`request.auth.uid == uid`), starting with `coins == 0`, `packs == 10`, `elo == 1000`, `wins == 0`, `losses == 0`, and zero PII fields (`email` is strictly isolated in `/playerPrivate/{uid}`).
2. A Player cannot mutate another player's `/players/{uid}` document or `/playerPrivate/{uid}` document unless they are a verified Super-Admin or promoted Admin in `/admins/{uid}`.
3. A Friendship document `/friendships/{friendshipId}` can only be read, updated, or deleted by one of the two UIDs in `users`, and its ID must match `{minUid}_{maxUid}`.
4. A Trade document `/trades/{tradeId}` can only be created if a friendship exists (`exists(/databases/$(database)/documents/friendships/...)` with `status == 'accepted'`) and `senderId == request.auth.uid`.
5. Once a Trade reaches terminal status (`accepted`, `rejected`, `cancelled`), its status and card lists are immutable; only `senderClaimed` / `recipientClaimed` may transition from `false` to `true` by the respective participant.
6. An Auction document `/auctions/{auctionId}` can only have bids placed (`status == 'active'`) that strictly exceed `currentBid` (or `>= startingPrice` for first bid), by a non-seller, and terminal states (`sold`, `ended`, `cancelled`) lock price/winner fields while allowing `sellerClaimed`/`winnerClaimed`/`pendingRefunds` settlement by the rightful owner.
7. A Duel document `/duels/{duelId}` locks terminal state (`finished`, `cancelled`) against score/winner tampering; only `hostClaimed` / `guestClaimed` may transition `false -> true` by the corresponding participant.
8. A DuelMove `/duels/{duelId}/moves/{moveId}` uses the Master Gate `get()` on `/duels/{duelId}` to verify `request.auth.uid in duel.participants` and `duel.status == 'active'`.
9. Admin privileges (`admins/{uid}`) can only be granted or revoked by a verified Super-Admin (`request.auth.token.email == 'grangeotnathan@gmail.com' && request.auth.token.email_verified == true`).

## 2. The "Dirty Dozen" Payloads (Must Return PERMISSION_DENIED)
1. **Identity Spoofing on Player Create**: Creating `/players/otherUid` while signed in as `attackerUid`.
2. **Self-Granted Starter Coins**: Creating `/players/attackerUid` with `coins: 999999` instead of `0`.
3. **PII Leak Attempt**: Reading `/playerPrivate/victimUid` as `attackerUid`.
4. **Ghost Field Shadow Update**: Updating `/players/attackerUid` with an unexpected field `{ isAdmin: true }`.
5. **Email Spoofing Admin Bypass**: Token with `email: 'grangeotnathan@gmail.com'` and `email_verified: false` attempting to write `/admins/attackerUid`.
6. **Self-Promotion to Admin**: Writing `/admins/attackerUid` as a regular verified user.
7. **ID Poisoning**: Creating `/trades/<200-char-invalid-chars>` violating `isValidId()`.
8. **Trade Without Friendship**: Creating `/trades/t1` between two users who do not have an accepted `/friendships/...` document.
9. **Auction Self-Bid / Underbid**: Updating `/auctions/a1` as the seller or with `currentBid <= existing().currentBid`.
10. **Terminal Auction Tampering**: Modifying `winnerId` or `currentBid` on an auction where `status == 'sold'`.
11. **Duel Move Non-Participant**: Creating `/duels/d1/moves/1_attacker` when `attacker` is not in `duel.participants`.
12. **Blanket Query Scraping**: Listing `/friendships` or `/trades` without filtering to `request.auth.uid in resource.data.users` / `participants`.
